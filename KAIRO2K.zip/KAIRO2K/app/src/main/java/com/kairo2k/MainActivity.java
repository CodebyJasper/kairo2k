package com.kairo2k;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/** KAIRO 2K - 2K14 CyberFace -> 2K20 port.  Pick the 2K14 IFF, tap PORT. */
public class MainActivity extends Activity {

    // ---- palette: red + black
    static final int BG = Color.parseColor("#0A0A0B");
    static final int CARD = Color.parseColor("#151517");
    static final int CARD_EDGE = Color.parseColor("#2A2A2E");
    static final int RED = Color.parseColor("#E10600");
    static final int RED_DARK = Color.parseColor("#8E0400");
    static final int TEXT = Color.parseColor("#F4F4F5");
    static final int MUTED = Color.parseColor("#8E8E96");
    static final int GREEN = Color.parseColor("#2FD16B");

    static final int REQ_PICK = 1;

    private final List<File> picked = new ArrayList<File>();
    private int outputMode = 2;      // 1 x2 | 2 x4 | 3 native | 4 2048 | 5 4096
    private int skinMode = 3;        // 1 native | 2 tint | 3 tone match
    private boolean running = false;

    private TextView tvFiles, tvPct, tvStage, tvResult, tvHint;
    private View barFill, barTrack;
    private TextView btnPick, btnGo;
    private final List<TextView> outChips = new ArrayList<TextView>();
    private final List<TextView> skinChips = new ArrayList<TextView>();

    // ------------------------------------------------------------------ lifecycle
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(BG);
            getWindow().setNavigationBarColor(BG);
        }
        buildUi();
        selectChip(outChips, 1);
        selectChip(skinChips, 2);
    }

    // ------------------------------------------------------------------ UI helpers
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable box(int fill, int stroke, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackgroundDrawable(box(CARD, CARD_EDGE, 14));
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        c.setLayoutParams(lp);
        return c;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 11, RED, true);
        t.setLetterSpacing(0.15f);
        t.setPadding(0, 0, 0, dp(8));
        return t;
    }

    private TextView chip(String s) {
        TextView t = text(s, 13, TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(10), dp(12), dp(10));
        return t;
    }

    private LinearLayout chipRow(String[] labels, final List<TextView> store, final boolean isOutput) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        LinearLayout cur = null;
        for (int i = 0; i < labels.length; i++) {
            if (i % 2 == 0) {
                cur = new LinearLayout(this);
                cur.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
                rp.topMargin = dp(i == 0 ? 0 : 8);
                row.addView(cur, rp);
            }
            final TextView c = chip(labels[i]);
            final int idx = i;
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
            cp.rightMargin = dp(i % 2 == 0 ? 8 : 0);
            cur.addView(c, cp);
            store.add(c);
            c.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (running) return;
                    selectChip(store, idx);
                    if (isOutput) outputMode = idx + 1; else skinMode = idx + 1;
                }
            });
        }
        return row;
    }

    private void selectChip(List<TextView> chips, int sel) {
        for (int i = 0; i < chips.size(); i++) {
            TextView c = chips.get(i);
            if (i == sel) {
                c.setBackgroundDrawable(box(RED, RED, 10));
                c.setTextColor(Color.WHITE);
            } else {
                c.setBackgroundDrawable(box(Color.parseColor("#1D1D20"), CARD_EDGE, 10));
                c.setTextColor(MUTED);
            }
        }
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(24));
        sv.addView(root, new ViewGroup.LayoutParams(-1, -2));

        // header
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setBackgroundDrawable(box(Color.parseColor("#120202"), RED_DARK, 16));
        head.setPadding(dp(18), dp(18), dp(18), dp(18));
        TextView brand = text("KAIRO 2K", 30, TEXT, true);
        brand.setLetterSpacing(0.12f);
        TextView sub = text("CYBERFACE PORT  •  2K14 → 2K20", 11, RED, true);
        sub.setLetterSpacing(0.18f);
        head.addView(brand);
        head.addView(sub);
        View rule = new View(this);
        rule.setBackgroundColor(RED);
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(dp(56), dp(3));
        rl.topMargin = dp(12);
        head.addView(rule, rl);
        root.addView(head, new LinearLayout.LayoutParams(-1, -2));

        // 1  file
        LinearLayout c1 = card();
        c1.addView(sectionTitle("1  •  2K14 IFF"));
        btnPick = chip("SELECT 2K14 IFF");
        btnPick.setBackgroundDrawable(box(Color.parseColor("#1D1D20"), RED, 10));
        btnPick.setTextColor(TEXT);
        c1.addView(btnPick, new LinearLayout.LayoutParams(-1, -2));
        tvFiles = text("No file selected", 13, MUTED, false);
        tvFiles.setPadding(0, dp(10), 0, 0);
        c1.addView(tvFiles);
        root.addView(c1);
        btnPick.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (!running) pick(); }
        });

        // 2  output
        LinearLayout c2 = card();
        c2.addView(sectionTitle("2  •  OUTPUT"));
        c2.addView(chipRow(new String[]{"SD + HD x2", "SD + HD x4", "SD + HD Native", "HD 2048", "HD 4096"}, outChips, true));
        root.addView(c2);

        // 3  skin
        LinearLayout c3 = card();
        c3.addView(sectionTitle("3  •  SKIN"));
        c3.addView(chipRow(new String[]{"Native", "Tint Match", "Tone Match"}, skinChips, false));
        tvHint = text("Tone Match: face and body end on one skin tone, pulled toward the 2K20 base tones.", 12, MUTED, false);
        tvHint.setPadding(0, dp(10), 0, 0);
        c3.addView(tvHint);
        root.addView(c3);

        // go
        btnGo = text("PORT", 18, Color.WHITE, true);
        btnGo.setLetterSpacing(0.2f);
        btnGo.setGravity(Gravity.CENTER);
        btnGo.setBackgroundDrawable(box(RED, 0, 14));
        btnGo.setPadding(0, dp(16), 0, dp(16));
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-1, -2);
        gl.topMargin = dp(16);
        root.addView(btnGo, gl);
        btnGo.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (running) cancel(); else start(); }
        });

        // progress
        LinearLayout c4 = card();
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        tvStage = text("Ready", 13, MUTED, false);
        tvPct = text("0%", 22, TEXT, true);
        top.addView(tvStage, new LinearLayout.LayoutParams(0, -2, 1f));
        top.addView(tvPct);
        c4.addView(top);
        FrameLikeBar bar = new FrameLikeBar();
        c4.addView(bar.root, bar.params());
        tvResult = text("", 13, TEXT, false);
        tvResult.setPadding(0, dp(12), 0, 0);
        c4.addView(tvResult);
        root.addView(c4);

        TextView foot = text("Base 2K20 SD is built in.  Output: Downloads/KAIRO2K", 11, MUTED, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(16), 0, 0);
        root.addView(foot);

        setContentView(sv);
    }

    /** progress bar built from two Views (no AndroidX / no theme dependency) */
    private class FrameLikeBar {
        final LinearLayout root;
        FrameLikeBar() {
            root = new LinearLayout(MainActivity.this);
            root.setOrientation(LinearLayout.HORIZONTAL);
            root.setBackgroundDrawable(box(Color.parseColor("#232326"), 0, 6));
            barTrack = root;
            barFill = new View(MainActivity.this);
            barFill.setBackgroundDrawable(box(RED, 0, 6));
            root.addView(barFill, new LinearLayout.LayoutParams(0, -1));
        }
        LinearLayout.LayoutParams params() {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(10));
            p.topMargin = dp(10);
            return p;
        }
    }

    private void setProgress(int pct, String label) {
        tvPct.setText(pct + "%");
        tvStage.setText(label);
        int w = barTrack.getWidth();
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) barFill.getLayoutParams();
        lp.width = (int) (w * (pct / 100f));
        barFill.setLayoutParams(lp);
    }

    // ------------------------------------------------------------------ file picking
    private void pick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, REQ_PICK);
    }

    private String nameOf(Uri u) {
        Cursor c = null;
        try {
            c = getContentResolver().query(u, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int k = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (k >= 0) return c.getString(k);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return "file_" + System.currentTimeMillis() + ".iff";
    }

    private static void copy(InputStream in, OutputStream out) throws Exception {
        byte[] buf = new byte[1 << 16];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null) return;
        List<Uri> uris = new ArrayList<Uri>();
        if (data.getClipData() != null) {
            for (int k = 0; k < data.getClipData().getItemCount(); k++) uris.add(data.getClipData().getItemAt(k).getUri());
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        File dir = new File(getCacheDir(), "in");
        deleteTree(dir);
        dir.mkdirs();
        picked.clear();
        StringBuilder sb = new StringBuilder();
        for (Uri u : uris) {
            try {
                String name = nameOf(u).replaceAll("[^A-Za-z0-9._-]", "_");
                File f = new File(dir, name);
                InputStream in = getContentResolver().openInputStream(u);
                OutputStream out = new FileOutputStream(f);
                copy(in, out);
                in.close();
                out.close();
                picked.add(f);
                sb.append(name).append("  (").append(f.length() / 1024).append(" KB)\n");
            } catch (Exception e) {
                sb.append("Could not read a file: ").append(e.getMessage()).append("\n");
            }
        }
        tvFiles.setText(picked.isEmpty() ? "No file selected" : sb.toString().trim());
        tvFiles.setTextColor(picked.isEmpty() ? MUTED : TEXT);
    }

    private static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteTree(k);
        f.delete();
    }

    // ------------------------------------------------------------------ run
    /** the 2K20 base is shipped in assets/ and copied once */
    private File ensureBase() throws Exception {
        File base = new File(getFilesDir(), "BASE_SD.iff");
        if (!base.exists() || base.length() < 1000) {
            InputStream in = getAssets().open("BASE_SD.iff");
            OutputStream out = new FileOutputStream(base);
            copy(in, out);
            in.close();
            out.close();
        }
        return base;
    }

    private void cancel() {
        try { Python.getInstance().getModule("cfapp").callAttr("cancel"); } catch (Exception ignored) { }
        btnGo.setText("CANCELLING...");
    }

    private void setRunning(boolean r) {
        running = r;
        btnGo.setText(r ? "CANCEL" : "PORT");
        btnGo.setBackgroundDrawable(box(r ? Color.parseColor("#2A2A2E") : RED, r ? RED : 0, 14));
    }

    private void start() {
        if (picked.isEmpty()) {
            tvResult.setTextColor(RED);
            tvResult.setText("Select a 2K14 IFF first.");
            return;
        }
        final File outDir = new File(getFilesDir(), "out");
        deleteTree(outDir);
        outDir.mkdirs();
        tvResult.setTextColor(TEXT);
        tvResult.setText("");
        setRunning(true);
        setProgress(0, "Starting");
        final StringBuilder paths = new StringBuilder();
        for (File f : picked) paths.append(f.getAbsolutePath()).append("\n");
        final int out = outputMode, skin = skinMode;

        new Thread(new Runnable() {
            @Override public void run() {
                String result;
                try {
                    File base = ensureBase();
                    ProgressCb cb = new ProgressCb() {
                        @Override public void onProgress(final int pct, final String label) {
                            runOnUiThread(new Runnable() {
                                @Override public void run() { setProgress(pct, label); }
                            });
                        }
                    };
                    PyObject r = Python.getInstance().getModule("cfapp").callAttr(
                            "run", paths.toString(), base.getAbsolutePath(), outDir.getAbsolutePath(), out, skin, cb);
                    result = r.toString();
                } catch (Throwable t) {
                    result = "FAIL|" + t.getMessage();
                }
                final String fin = finish(result, outDir);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        setRunning(false);
                        boolean ok = fin.startsWith("DONE");
                        if (ok) setProgress(100, "Done");
                        else tvStage.setText("Stopped");
                        tvResult.setTextColor(ok ? GREEN : RED);
                        tvResult.setText(fin);
                    }
                });
            }
        }).start();
    }

    /** parse the bridge result, copy the IFFs + log to Downloads/KAIRO2K, build the message */
    private String finish(String result, File outDir) {
        List<String> ok = new ArrayList<String>(), fail = new ArrayList<String>(), warn = new ArrayList<String>();
        String log = null;
        for (String line : result.split("\n")) {
            int k = line.indexOf('|');
            if (k < 0) continue;
            String tag = line.substring(0, k), val = line.substring(k + 1);
            if (tag.equals("OK")) ok.add(val);
            else if (tag.equals("FAIL")) fail.add(val);
            else if (tag.equals("WARN")) warn.add(val);
            else if (tag.equals("LOG")) log = val;
        }
        StringBuilder sb = new StringBuilder();
        if (!ok.isEmpty()) {
            sb.append("DONE  •  saved to Downloads/KAIRO2K\n");
            for (String p : ok) {
                try { save(new File(p)); sb.append("  ✓ ").append(new File(p).getName()).append("\n"); }
                catch (Exception e) { sb.append("  ! ").append(new File(p).getName()).append(" : ").append(e.getMessage()).append("\n"); }
            }
        }
        if (log != null) { try { save(new File(log)); } catch (Exception ignored) { } }
        for (String f : fail) sb.append("FAILED: ").append(f).append("\n");
        for (String w : warn) sb.append("Warning: ").append(w).append("\n");
        if (ok.isEmpty() && fail.isEmpty()) sb.append("Nothing was written. See cf_port_log.txt in Downloads/KAIRO2K.");
        return sb.toString().trim();
    }

    /** copy a file to Downloads/KAIRO2K (MediaStore on Android 10+, plain file below) */
    private void save(File f) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put("_display_name", f.getName());
            v.put("mime_type", "application/octet-stream");
            v.put("relative_path", "Download/KAIRO2K");
            ContentResolver cr = getContentResolver();
            Uri u = cr.insert(Uri.parse("content://media/external/downloads"), v);
            if (u == null) throw new Exception("MediaStore refused");
            OutputStream out = cr.openOutputStream(u);
            InputStream in = new FileInputStream(f);
            copy(in, out);
            in.close();
            out.close();
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "KAIRO2K");
            dir.mkdirs();
            InputStream in = new FileInputStream(f);
            OutputStream out = new FileOutputStream(new File(dir, f.getName()));
            copy(in, out);
            in.close();
            out.close();
        }
    }
}
