package com.kairo2k;

/** Called from Python (cfapp.py) while the port is running. */
public interface ProgressCb {
    void onProgress(int pct, String label);
}
