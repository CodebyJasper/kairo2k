"""KAIRO 2K - bridge between the Android UI (Java) and cf_port.py (called through Chaquopy)."""
import os, sys, traceback
os.environ["CF_NO_ETCPAK"] = "1"          # no runtime pip on Android: the built-in ETC2 encoder is used
import cf_port

_BaseUi = cf_port._Ui          # original console UI class (cf_port._Ui gets replaced per run)
_cancel = [False]


class _Cancelled(BaseException):
    pass


def cancel():
    _cancel[0] = True


# output  : 1 = SD + HD x2 | 2 = SD + HD x4 | 3 = SD + HD native | 4 = HD 2048 | 5 = HD 4096
# skin    : 1 = native      | 2 = tint match | 3 = tone match (default)
def run(src_paths, base_path, out_dir, output, skin, callback):
    """src_paths: '\n'-joined 2K14 IFF paths.  callback.onProgress(int pct, String label).
    Returns lines:  OK|<iff path>   FAIL|<message>   WARN|<text>   LOG|<log path>"""
    _cancel[0] = False
    if isinstance(src_paths, str):
        src_paths = [x for x in src_paths.split("\n") if x.strip()]
    ui_box = []

    class Ui(_BaseUi):
        def __init__(self, orig):
            _BaseUi.__init__(self, orig); ui_box.append(self)

        def show(self, frac, label=""):
            if _cancel[0]:
                raise _Cancelled()
            pct = int(max(0, min(100, 100 * (self.fi + max(0.0, min(1.0, frac))) / max(self.n, 1))))
            pct = max(pct, self.last if self.last >= 0 else 0)
            if pct != self.last or label:
                self.last = pct
                try: callback.onProgress(pct, str(label))
                except Exception: pass

        def say(self, t):
            pass

    output = int(output); skin = int(skin); g = cf_port.__dict__
    g["OUT_MODE"] = output if output in (1, 2, 3) else 2
    g["HD_FACTOR"] = {1: 2, 2: 4, 3: 1}[g["OUT_MODE"]]
    g["HD_SIZE"] = {4: 2048, 5: 4096}.get(output, 0)
    g["NATIVE"] = (skin == 1)
    g["TONE_ON"] = skin not in (1, 2)
    g["MAKE_SD"] = True; g["MAKE_HD"] = True
    g["_Ui"] = Ui
    res = []
    lines = []
    try:
        res = cf_port.batch([str(p) for p in src_paths], str(out_dir), str(base_path)) or []
    except _Cancelled:
        lines.append("FAIL|Cancelled")
    except BaseException as e:                      # SystemExit included
        lines.append("FAIL|%s: %s" % (type(e).__name__, e))
        lines.append("WARN|" + traceback.format_exc()[-400:].replace("\n", " / "))
    finally:
        sys.stdout = sys.__stdout__
    for name, ok, m in res:
        if ok:
            for x in m: lines.append("OK|" + x)
        else:
            lines.append("FAIL|%s: %s" % (name, m))
    if ui_box:
        for w in list(dict.fromkeys(ui_box[0].warn))[:6]: lines.append("WARN|" + w)
    logp = os.path.join(str(out_dir), "cf_port_log.txt")
    if os.path.exists(logp): lines.append("LOG|" + logp)
    return "\n".join(lines)
