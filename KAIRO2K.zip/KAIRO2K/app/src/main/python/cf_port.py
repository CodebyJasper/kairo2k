#!/usr/bin/env python3
"""
cf_port-95.py  -  2K14 CF -> 2K20 CF  1:1 port  (SD + HD from ONE SD template)
  v96: SPEED - ETC2 + EAC encoders cut into strips and run in parallel threads (CF_THREADS), EAC search int16 + winner-only index pass (4x), T/H error by matmul.  Output identical (a few tie blocks differ by 1 bit-pattern, same error).
  v95: FACE = BODY IN GAME (brightness compensation back on; green off in tone mode, --face-green X turns it on).  v94 matched the face TEXTURE to the body and switched the modder's green / brightness tip off -> in game the face (game skin tint on the alpha mask, the body has none) came out darker / redder than the body, the neck too (same texture).  Now: face texture = body skin (TONE MATCH) + the modder's game compensation (dark skin: ~+9 L*, light skin: up to +20 L*).  Tune with --face-bright (2.6, 0 = off) / --face-green (0 in tone mode; modder's tip = 2.1); --face-target L,a,b = exact face texture colour
  v94: TONE MATCH - material_map (body) and face_diffuse now end on the EXACT SAME skin colour (L*a*b* median of the skin, tattoos / ink / lips / hair / shadows trimmed out), pulled towards the 2K20 base skin tones (the 6 base material maps are built in; --tone-ref DIR = your own set).  Shift is applied at the NATIVE resolution of the 2K14 map with a soft skin-likeness weight -> HD tattoos stay untouched, and the face no longer drifts away from the body (the old FACE_GREEN / FACE_BRIGHT were applied AFTER the face->body match).  --no-tone = v93 behaviour | --tone-k (colour pull, 0.6) --tone-l (brightness pull, 0)
       HD SIZE: --hd-size 1024 | 2048 | 4096 = HD file with face_diffuse + material_map slots of that size (other slots up to 1024 / native), menu options 4 / 5.  Bigger slots = bigger IFF + slower encoder; if your build renders them black use 1024 / 512 (see v80)
  v93: NORMAL heads (png1612, pngALVARADO ...): LOD1 (bench / far) now uses the SAME method as the big heads (v92): the template LOD1 topology / bones / draw records are kept and MOVED onto the head (pos / normal / tangent / UV taken from the head's own LOD0 vertex), own hair strips in the template hair slot.  The 2K14 LOD1 is a re-made mesh (only ~14% of its UVs exist in LOD0, packing fit off by ~0.14) = shredded mesh + wrong texture on the bench.  CF_LOD1_TPL=0 = old 2K14-LOD1 port\n  v92: BIG HEAD LOD1 face: template LOD1 topology moved onto the new head (v91 decimated face = shredded on the bench)\n  v91: BIG HEAD fitted to 2K20 head size + neck pinned (no more long neck)\n  v91: BIG HEAD LOD1 (bench / far): LOD1 bone idx + weights now from the template's LOD1 palette (LOD1 skinning differs from LOD0)\n  v90: BIG HEADS fix - per-vertex floats now come from the big stream in fitted-mesh order (v89 copied them from the small stream = wrong for all hair verts)\n  v89: BIG HEADS (pngYAXELV2: 17500-vert hair): right stream + index buffer + records found, ALL head parts verbatim, the head's OWN hair fitted into the 2K20 container (strip runs, evenly sampled) -> no template hair / no bald head; LOD1 rebuilt from the same parts (face clustered, hair sampled); CF_BIG=0 = old\n  v88: BIG 2K14 heads (e.g. pngYAXELV2: 6119 verts / 12000 idx > 2K20 slot 4375 / 9504) now port: correct head vertex stream is chosen by checking it against the index buffer; when the file holds extra LOD data after the LOD0 mesh only what the LOD0 draw table uses is copied | LOD1 table of a head whose LOD1 buffers could not be ported is left as the template's (no garbage far LOD)\n  v87: LOD1 HAIR + HEADBAND fix (rebuilt LOD1 parts whose hash is not in the template now go into the same slot they use in LOD0 / any free slot; small parts like a headband are no longer thinned out) | texture REPLACE prompt before saving (face diffuse / material map; --replace-face / --replace-material)\n  v80: FACE follows BODY skin (face_diffuse -> material_map tone, body/tattoos untouched) | HD tattoos (body map sharpened on the way down) | MAX texture 512 by default (1024 / native = black in game; --max-tex) | LOD1 hair rebuilt from the LOD0 hair when the 2K14 LOD1 has none\n  v76: body skin L*+chroma matched to face | body map (tattoos) never below the 2K14 panel, also in SD | output modes 1 x2 / 2 x4 / 3 native (--out-mode)\n  v79: raw (no ZLIB) 2K14 IFFs load | ETC2-ONLY encoder (planar/T/H, no ETC1 blocks; --allow-etc1 undoes) | LOD1 frame pinned | HD: normal+hair no longer skipped | LOD1 (far/bench) now ported for EVERY head (size check used padded index count) | extra 2K14 parts (headband) placed in free LOD slots\n  v75: TINT MATCH (face+body, chroma only, L* kept; --tint-k --tint-match --no-tint) | HD = SD x4 = 1024 (--hd-factor 2|4)\n  v74: ALL skin adjustments OFF by default (skin unify, chroma/red-cast fix) - textures are written exactly as decoded (decode bug fixed in v73).  Switches still exist: --skin-sd/--skin-hd chroma|match, --unify relative|face|base\n  v73: DXT3/DXT5 decode fix (colour block always 4-colour -> no more black/wrong skin blocks) | body skin = face skin + the base's own face->body offset (--unify relative, default)\n  v72: SKIN UNIFY - material_map (body) skin is shifted in Lab to the final face_diffuse skin tone (face processed first).  --unify face|base|off  --unify-k --unify-l
       writes skin_unify_check.png (3 swatches) + prints before/after numbers.
  v71: HD is made FROM THE SD TEMPLATE (no HD template needed): texture slots are enlarged x2 (descriptor w/h/mip field, header chunk table,
       data pointers, block sizes) exactly like the modder's HD.iff.  Texture memory plan fixed (3 LOD chunks for face/material/normal, 2 for detail/hair).
       1:1 mesh = 2K14 positions / normals / tangents copied VERBATIM (CF_EXACT, default on).  SD skin = modder-style chroma fix (strength 0.75, luminance kept);
       HD skin = untouched 2K14 colours (what the modder did).  Switches: --skin-sd --skin-hd --skin-k --no-exact --sd-only --hd-only
  v70: extra test IFF "_skin_alpha0" (face_diffuse alpha = 0 -> no game skin-tint on top of the baked 2K14 colour; colour untouched) + encoder round-trip on REAL 2K20 data
  v69: main IFF = textures exactly as extracted (face + material untouched).  Two EXTRA test IFFs with a face_diffuse-only skin fix (_skin_chroma, _skin_match).
  v68: textures are written AS EXTRACTED (no colour / skin / sharpen / hair edits); only resize + ETC2 encode.  Switches below if you ever want them.
  v67: red cast removed from the BODY skin (material_map) too | upscaler (sharp 2x steps) | texture layout verified on the base, not against header sizes
  v66: LOD1 (far / bench) mesh ported from 2K14 = its own index buffer + 36-byte vertex records with packed positions (found by analysing pngGRIMES + base_SD)
  v65: NEXT-GEN texture pass (clean / sharper / hair edge bleed) + nextgen_*.png previews in out/<name>/
  v64: skin cast removed by default (measured vs base) | no pip hang on Pydroid | HD base choice | cf_port_log.txt + [diag] structure dump
  v63: EVERY LOD group of the draw/LOD table is copied from 2K14 | every texture mip checked after writing | skin diagnostics
  v62b: etcpak ETC2 encoder (auto-install) | NO skin-tone editing | neck pinned to the 2K20 body | far-LOD template hair removed

Needs: python3, numpy, Pillow.   PC or Android (Termux / Pydroid3).
Run with no arguments for the interactive menu, or:
    python3 cf_port-59.py pngCALEB.iff pngMOREZ.iff -t base_SD.iff -o out

WHAT IT DOES (nothing else)
  MESH   the 2K14 mesh is copied as it is into the 2K20 container: every vertex (face, hair, beard, headband, goggles, accessories), the
         2K14 triangle strips, native UV, normals, tangents, bone indices / weights.  Position = 2K14 position fitted into the 2K20 frame;
         only the neck ring is blended to the 2K20 template so it meets the 2K20 body.
  LOD    the 2K20 file draws its LODs from a progressive-mesh table (per LOD: first N indices / first V vertices, one entry per hash).
         The 2K14 table is copied into it, so every LOD keeps the 2K14 hair / beard / headband.  (The template's own cutoffs are what made
         hair and beard disappear when the game switched LOD.)
  TEXT   face / material / normal / detail / hair textures are written untouched in the template's native formats (ETC2 RGB8 / RGBA8-EAC, raw
         formats stay raw).  Every mip level is a box-filter downsample of LOD0 (no tone, chroma, gamma, brightness or sharpen anywhere).
         2x2 and 1x1 mips are tiled exactly like the 2K20 base.
No hair filter, no projection, no smoothing, no per-head configuration.
"""
import argparse, os, struct, sys, zlib
ETC2_ONLY = os.environ.get("CF_ALLOW_ETC1", "0") != "1"   # v79: True = encoder writes ONLY real ETC2 block types (planar / T / H) - NO ETC1-style individual/differential blocks.  --allow-etc1 turns it off
import numpy as np
from PIL import Image, ImageFilter, ImageDraw

def _ensure_etcpak():
    """import etcpak if present.  One quiet pip attempt (60 s max); a marker file stops further attempts (Pydroid usually cannot build it)."""
    try:
        import etcpak; return etcpak
    except Exception: pass
    if os.environ.get("CF_NO_ETCPAK"): return None
    try: here = os.path.dirname(os.path.abspath(__file__))
    except NameError: here = os.getcwd()
    mark = os.path.join(here, ".no_etcpak")
    if os.path.exists(mark): return None
    import subprocess, importlib
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "etcpak"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=60)
        importlib.invalidate_caches(); import etcpak; print("etcpak installed OK"); return etcpak
    except Exception: pass
    try: open(mark, "w").write("etcpak not installable here - built-in ETC2 encoder is used")
    except Exception: pass
    print("(etcpak not available -> built-in ETC2 encoder, which is fine)")
    return None
_ETCPAK = None if ETC2_ONLY else _ensure_etcpak()
_ETCPAK_FAILED = [False]


# ---------------- v71 globals ----------------
EXACT = os.environ.get("CF_EXACT", "1") != "0"      # 1:1 = 2K14 vertex positions / normals / tangents verbatim (no fit, no neck blend)
SKIN_K = float(os.environ.get("CF_SKIN_K", "1")) # strength of the chroma (red cast) fix; 1.0 = full, measured on the modder's SD = ~0.75
SKIN_SD = "off"; SKIN_HD = "off"                 # modder: SD skin fixed, HD = raw 2K14 colours
MAKE_SD = True; MAKE_HD = True
PHYS_END = [None]       # physical end of the texture plan (HD block is zero-padded after it)
SKIN_REF = [None]; SKIN_REF_MAT = [None]       # decoded base (SD template) face LOD0 -> skin target, captured BEFORE the template is enlarged
ROLES_ONLY = [False]   # v76: write_textures_dd returns right after the slot roles were detected
ROLES = [None]          # slot roles detected on the SD template (HD template has empty textures -> cannot be detected there)

# --------------------------------------------------------------------------
# EDIT ME: slot name  ->  (2K20 size, 2K20 output file name)
# keys are the 2K14 record hashes (first 4 bytes of the record).
# --------------------------------------------------------------------------
SLOTS = {
    # size 0 = keep native resolution (HD extract); inject still matches template slot size
    "6a482dae": ("face_diffuse", 0, "1_FACE_DIFFUSE.png"),
    "27a62111": ("material_map", 0, "2_MATERIAL_MAP.png"),
    "7ec1fc55": ("normal_map",   0, "3_NORMAL_MAP.png"),
    "e53c961f": ("detail_mask",  0, "4_DETAIL_MASK.png"),
    "51c65d83": ("hair",         0, "5_HAIR_native.png"),
}

NEXTGEN = False        # v65: next-gen texture pass on face / hair (False = textures exactly as extracted)
NEXTGEN_SHARP = 0.6    # 0..1 sharpening strength of the face / hair colour (alpha never touched)
FACE_SKIN_MODE = "off"   # face_diffuse ONLY (material_map is never touched): "off" | "chroma" (remove red cast, keep brightness) | "match" (also match base skin brightness) | "alpha0" (colour untouched, alpha mask = 0 -> game cannot tint it again)
SKIN_VARIANTS = False    # also write two extra test IFFs (_skin_chroma, _skin_match) next to the untouched one
FACE_NEUTRAL = 0.0     # v64: 1.0 = remove the baked 2K14 skin CAST (red) so the skin matches the 2K20 base; 0 = off.  Luminance / detail / lips untouched.
CHECK_DIR = None     # set by port_iff: folder for the decoded-texture check PNGs
ENC_MODES = ("planar", "T", "H") if ETC2_ONLY else ("etc1", "planar", "T", "H")   # ETC2 block types ("etc1" = ETC2 individual/differential blocks); best one per 4x4 block
ENC_PASSES = 3       # encoder refinement passes (v64: 3 = cleaner blocks)
PATCH_ALL_LOD = "1"  # "1" = copy EVERY LOD group of the draw table from 2K14, "0" = LOD0 only
LOD_HAIR = "collapse"  # far-LOD streams that still hold the TEMPLATE hair: "collapse" (hide) | "off"
SHARPEN = {}         # (no sharpen / tone / chroma editing exists in v59)

# ======================================================================================
# v52  ETC2 CODEC  (embedded, isolated namespace -> _E2)
#   * full ETC2 RGB decoder : individual / differential / T / H / PLANAR (validated on the 2K20 base's own textures)
#   * full ETC2 RGB encoder : ETC1 ind/diff + PLANAR + T + H, best mode per 4x4 block, flatter error weights
# ======================================================================================
import types as _types
_E2_SRC = r'''"""Full ETC2 RGB8 decoder (individual / differential / T / H / planar) - numpy, vectorised."""
import numpy as np
TAB = np.array([[2,8],[5,17],[9,29],[13,42],[18,60],[24,80],[33,106],[47,183]], np.int32)
MT = np.stack([np.array([a,b,-a,-b]) for a,b in TAB]).astype(np.int32)       # selector -> modifier
DIST = np.array([3,6,11,16,23,32,41,64], np.int32)
def sx3(v): return v - 8*(v>=4)
def e4(v): return v*17
def e5(v): return (v<<3)|(v>>2)
def e6(v): return (v<<2)|(v>>4)
def e7(v): return (v<<1)|(v>>6)

def classify(b):
    """b (N,8) int -> mode array: 0 ind, 1 diff, 2 T, 3 H, 4 planar"""
    diff=(b[:,3]>>1)&1
    base=np.stack([b[:,i]>>3 for i in range(3)],1); dl=np.stack([sx3(b[:,i]&7) for i in range(3)],1)
    sec=base+dl; ovf=(sec<0)|(sec>31)
    mode=np.zeros(len(b),np.int32)
    mode[diff==1]=1
    mode[(diff==1)&ovf[:,0]]=2
    mode[(diff==1)&~ovf[:,0]&ovf[:,1]]=3
    mode[(diff==1)&~ovf[:,0]&~ovf[:,1]&ovf[:,2]]=4
    return mode

def decode_rgb(blk):
    """blk (N,8) uint8 -> px (N,4,4,3) [y,x], mode (N,)"""
    b=blk.astype(np.int32); N=len(b); mode=classify(b)
    bits=(b[:,4].astype(np.int64)<<24)|(b[:,5].astype(np.int64)<<16)|(b[:,6].astype(np.int64)<<8)|b[:,7]
    px=np.zeros((N,4,4,3),np.int32)
    sel=np.zeros((N,4,4),np.int32)       # (y,x) selector 0..3
    for x in range(4):
        for y in range(4):
            i=x*4+y; sel[:,y,x]=(((bits>>(i+16))&1)<<1)|((bits>>i)&1)
    # ---- ETC1 style (ind / diff)
    flip=b[:,3]&1; t1=(b[:,3]>>5)&7; t2=(b[:,3]>>2)&7
    ci1=np.stack([e4(b[:,i]>>4) for i in range(3)],1); ci2=np.stack([e4(b[:,i]&15) for i in range(3)],1)
    base=np.stack([b[:,i]>>3 for i in range(3)],1); dl=np.stack([sx3(b[:,i]&7) for i in range(3)],1)
    cd1=e5(base); cd2=e5(np.clip(base+dl,0,31))
    isd=(mode==1)[:,None]
    c1=np.where(isd,cd1,ci1); c2=np.where(isd,cd2,ci2)
    m=(mode<=1)
    if m.any():
        for x in range(4):
            for y in range(4):
                first=np.where(flip==0,x<2,y<2)
                col=np.where(first[:,None],c1,c2); tb=np.where(first,t1,t2)
                mod=MT[tb,sel[:,y,x]]
                v=np.clip(col+mod[:,None],0,255)
                px[m,y,x,:]=v[m]
    # ---- T
    mT=mode==2
    if mT.any():
        q=b[mT]
        r1=(((q[:,0]>>3)&3)<<2)|(q[:,0]&3); g1=q[:,1]>>4; b1=q[:,1]&15
        r2=q[:,2]>>4; g2=q[:,2]&15; b2=q[:,3]>>4
        di=(((q[:,3]>>2)&3)<<1)|(q[:,3]&1); d=DIST[di][:,None]
        c0=e4(np.stack([r1,g1,b1],1)); cc=e4(np.stack([r2,g2,b2],1))
        pal=np.stack([c0,np.clip(cc+d,0,255),cc,np.clip(cc-d,0,255)],1)        # (n,4,3)
        s=sel[mT]
        for y in range(4):
            for x in range(4):
                px[mT,y,x,:]=pal[np.arange(len(q)),s[:,y,x]]
    # ---- H
    mH=mode==3
    if mH.any():
        q=b[mH]
        r1=(q[:,0]>>3)&15
        g1=((q[:,0]&7)<<1)|((q[:,1]>>4)&1)
        b1=(q[:,1]&8)|((q[:,1]&3)<<1)|(q[:,2]>>7)
        r2=(q[:,2]>>3)&15
        g2=((q[:,2]&7)<<1)|(q[:,3]>>7)
        b2=(q[:,3]>>3)&15
        c1v=(r1<<8)|(g1<<4)|b1; c2v=(r2<<8)|(g2<<4)|b2
        di=(((q[:,3]>>2)&1)<<2)|((q[:,3]&1)<<1)|(c1v>=c2v).astype(np.int32); d=DIST[di][:,None]
        ca=e4(np.stack([r1,g1,b1],1)); cb=e4(np.stack([r2,g2,b2],1))
        pal=np.stack([np.clip(ca+d,0,255),np.clip(ca-d,0,255),np.clip(cb+d,0,255),np.clip(cb-d,0,255)],1)
        s=sel[mH]
        for y in range(4):
            for x in range(4):
                px[mH,y,x,:]=pal[np.arange(len(q)),s[:,y,x]]
    # ---- planar
    mP=mode==4
    if mP.any():
        q=b[mP].astype(np.int64)
        ro=(q[:,0]>>1)&63
        go=((q[:,0]&1)<<6)|((q[:,1]>>1)&63)
        bo=((q[:,1]&1)<<5)|(q[:,2]&0x18)|((q[:,2]&3)<<1)|(q[:,3]>>7)
        rh=(((q[:,3]>>2)&31)<<1)|(q[:,3]&1)
        gh=(q[:,4]>>1)&127
        bh=((q[:,4]&1)<<5)|((q[:,5]>>3)&31)
        rv=((q[:,5]&7)<<3)|((q[:,6]>>5)&7)
        gv=((q[:,6]&31)<<2)|((q[:,7]>>6)&3)
        bv=q[:,7]&63
        O=np.stack([e6(ro),e7(go),e6(bo)],1); H=np.stack([e6(rh),e7(gh),e6(bh)],1); V=np.stack([e6(rv),e7(gv),e6(bv)],1)
        for y in range(4):
            for x in range(4):
                px[mP,y,x,:]=np.clip((x*(H-O)+y*(V-O)+4*O+2)>>2,0,255)
    return px,mode

def decode_image(raw,off,w,alpha=False):
    bs=16 if alpha else 8; nb=(w//4)**2
    blk=np.frombuffer(bytes(raw[off:off+nb*bs]),np.uint8).reshape(nb,bs)
    px,mode=decode_rgb(blk[:,8:] if alpha else blk)
    img=px.reshape(w//4,w//4,4,4,3).transpose(0,2,1,3,4).reshape(w,w,3).astype(np.uint8)
    return img,mode.reshape(w//4,w//4)


# ======================================================================================
#                                   ENCODER  (v50)
# ======================================================================================
EACT = np.array([[-3,-6,-9,-15,2,5,8,14],[-3,-7,-10,-13,2,6,9,12],[-2,-5,-8,-13,1,4,7,12],[-2,-4,-6,-13,1,3,5,12],
 [-3,-6,-8,-12,2,5,7,11],[-3,-7,-9,-11,2,6,8,10],[-4,-7,-8,-11,3,6,7,10],[-3,-5,-8,-11,2,4,7,10],
 [-2,-6,-8,-10,1,5,7,9],[-2,-5,-8,-10,1,4,7,9],[-2,-4,-8,-10,1,3,7,9],[-2,-5,-7,-10,1,4,6,9],
 [-2,-4,-7,-10,1,3,6,9],[-1,-2,-3,-10,0,1,2,9],[-4,-6,-8,-9,3,5,7,8],[-3,-5,-7,-9,2,4,6,8]])

# error weights.  v49 used luma-heavy (0.9,1.76,0.34): chroma errors were almost free -> coloured specks ("static") on
# smooth skin and around the eyes.  v50 uses a flatter weighting so chroma counts too.
W_DEFAULT = np.array([0.55, 1.0, 0.45], np.float32)

def to_blocks(img):
    """img (H,W,3) -> flat (N,16,3) float32 with pixel p = x*4+y (ETC bit order), blocks in row-major order"""
    h,w=img.shape[:2]
    B=img.astype(np.float32).reshape(h//4,4,w//4,4,3).transpose(0,2,1,3,4).reshape(-1,4,4,3)   # [n][y][x]
    p=np.arange(16); return B[:,p%4,p//4,:]

def _pack_sel(sel):
    p=np.arange(16); msb=((sel>>1)<<p).sum(1); lsb=((sel&1)<<p).sum(1)
    return msb,lsb

def _perr(px,pal,W):
    """px (N,16,3), pal (N,K,3) -> sel (N,16), err (N,)"""
    df=px[:,:,None,:]-pal[:,None,:,:]
    d=(df*df)@W                                   # v96: matmul over the 3 channels (faster than **2, *W, sum)
    s=d.argmin(2); return s,d.min(2).sum(1)

# ------------------------------------------------------------------ ETC1 individual / differential
def _sub_best(px,base,W):
    N=len(px); best=np.full(N,1e18); bt=np.zeros(N,int); bs=np.zeros((N,px.shape[1]),int)
    for t in range(8):
        cand=np.clip(base[:,None,:]+MT[t][None,:,None],0,255)
        d=(((px[:,:,None,:]-cand[:,None,:,:])**2)*W).sum(3)
        s=d.argmin(2); e=d.min(2).sum(1); m=e<best
        best[m]=e[m]; bt[m]=t; bs[m]=s[m]
    return bt,bs,best

def _col(q,mode): return (q*17 if mode==0 else (q<<3)|(q>>2)).astype(np.float32)

def _refine(px,q,mode,qo,first,passes,W):
    qmax=15 if mode==0 else 31
    t,s,e=_sub_best(px,_col(q,mode),W)
    for _ in range(passes):
        for ch in range(3):
            for dl in (-1,1):
                q2=q.copy(); q2[:,ch]+=dl
                ok=(q2[:,ch]>=0)&(q2[:,ch]<=qmax)
                if mode==1:
                    df=(qo-q2) if first else (q2-qo)
                    ok&=np.all((df>=-4)&(df<=3),1)
                if not ok.any(): continue
                t2,s2,e2=_sub_best(px,_col(q2,mode),W)
                m=ok&(e2<e); q[m]=q2[m]; t[m]=t2[m]; s[m]=s2[m]; e[m]=e2[m]
    return q,t,s,e

def enc_etc1(flat,W,passes=2):
    N=len(flat); p=np.arange(16); X=p//4; Y=p%4
    res=[]
    for flip in (0,1):
        sub=(Y>=2) if flip else (X>=2); i1=np.where(~sub)[0]; i2=np.where(sub)[0]
        px1=flat[:,i1,:]; px2=flat[:,i2,:]; m1=px1.mean(1); m2=px2.mean(1)
        for mode in (0,1):
            if mode==0:
                q1=np.clip(np.round(m1/17),0,15).astype(int); q2=np.clip(np.round(m2/17),0,15).astype(int)
            else:
                q1=np.clip(np.round(m1/255*31),0,31).astype(int); q2=np.clip(np.round(m2/255*31),0,31).astype(int)
                q2=np.clip(q2,q1-4,q1+3)
            q1,t1,s1,e1=_refine(px1,q1,mode,q2,True,passes,W)
            q2,t2,s2,e2=_refine(px2,q2,mode,q1,False,passes,W)
            res.append((e1+e2,flip,mode,q1,q2,t1,t2,s1,s2,i1,i2))
    errs=np.stack([r[0] for r in res],1); pick=errs.argmin(1)
    out=np.zeros((N,8),np.uint8)
    for k,(e,flip,mode,q1,q2,t1,t2,s1,s2,i1,i2) in enumerate(res):
        sel=np.where(pick==k)[0]
        if not len(sel): continue
        S=np.zeros((len(sel),16),int); S[:,i1]=s1[sel]; S[:,i2]=s2[sel]
        msb,lsb=_pack_sel(S); a,b=q1[sel],q2[sel]
        if mode==0: c=np.stack([(a[:,i]<<4)|b[:,i] for i in range(3)],1); diff=0
        else: c=np.stack([(a[:,i]<<3)|((b[:,i]-a[:,i])&7) for i in range(3)],1); diff=1
        out[sel,0:3]=c; out[sel,3]=(t1[sel]<<5)|(t2[sel]<<2)|(diff<<1)|flip
        out[sel,4]=(msb>>8)&255; out[sel,5]=msb&255; out[sel,6]=(lsb>>8)&255; out[sel,7]=lsb&255
    return out,errs.min(1)

# ------------------------------------------------------------------ free-bit search (forces the intended ETC2 mode)
def _force_mode(blk,want,combos):
    """blk (n,8) uint8 with free bits zero. combos: list of (byte, mask) free-bit positions -> set bits until classify()==want"""
    n=len(blk); done=np.zeros(n,bool); out=blk.copy()
    free=[(b,m) for b,m in combos]
    for code in range(1<<len(free)):
        cand=blk.copy()
        for k,(b,m) in enumerate(free):
            if (code>>k)&1: cand[:,b]|=m
        ok=(classify(cand.astype(np.int32))==want)&~done
        out[ok]=cand[ok]; done|=ok
        if done.all(): break
    return out,done

# ------------------------------------------------------------------ planar
def _planar_px(q):
    """q (N,9) = [Ro,Go,Bo,Rh,Gh,Bh,Rv,Gv,Bv] -> (N,16,3) in bit order"""
    O=np.stack([e6(q[:,0]),e7(q[:,1]),e6(q[:,2])],1); H=np.stack([e6(q[:,3]),e7(q[:,4]),e6(q[:,5])],1); V=np.stack([e6(q[:,6]),e7(q[:,7]),e6(q[:,8])],1)
    p=np.arange(16); x=(p//4)[None,:,None]; y=(p%4)[None,:,None]
    return np.clip((x*(H-O)[:,None,:]+y*(V-O)[:,None,:]+4*O[:,None,:]+2)>>2,0,255).astype(np.float32)

def enc_planar(flat,W,passes=2):
    N=len(flat); p=np.arange(16); x=(p//4).astype(np.float64); y=(p%4).astype(np.float64)
    A=np.stack([(4-x-y)/4,x/4,y/4],1)                                  # (16,3)
    pinv=np.linalg.pinv(A)                                              # (3,16)
    sol=np.einsum('kp,npc->nkc',pinv,flat.astype(np.float64))           # (N,3,3): [O,H,V] x rgb
    mx=np.array([63,127,63])
    q=np.zeros((N,9),np.int32)
    for k in range(3):                                                  # O,H,V
        for c in range(3):
            q[:,k*3+c]=np.clip(np.round(sol[:,k,c]/255*mx[c]),0,mx[c])
    def err(qq): return (((_planar_px(qq)-flat)**2)*W).sum((1,2))
    e=err(q)
    for _ in range(passes):
        for j in range(9):
            for dl in (-1,1):
                q2=q.copy(); q2[:,j]+=dl; ok=(q2[:,j]>=0)&(q2[:,j]<=mx[j%3])
                e2=err(np.clip(q2,0,[63,127,63]*3)); m=ok&(e2<e); q[m]=q2[m]; e[m]=e2[m]
    ro,go,bo,rh,gh,bh,rv,gv,bv=[q[:,i].astype(np.int64) for i in range(9)]
    out=np.zeros((N,8),np.uint8)
    out[:,0]=(ro<<1)|(go>>6)
    out[:,1]=((go&63)<<1)|(bo>>5)
    out[:,2]=(bo&0x18)|(bo&6)>>1
    out[:,3]=((bo&1)<<7)|((rh>>1)<<2)|2|(rh&1)
    out[:,4]=((gh)<<1)|(bh>>5)
    out[:,5]=((bh&31)<<3)|(rv>>3)
    out[:,6]=((rv&7)<<5)|(gv>>2)
    out[:,7]=((gv&3)<<6)|bv
    out,ok=_force_mode(out,4,[(0,0x80),(1,0x80),(2,0x80),(2,0x40),(2,0x20),(2,0x04)])
    e=np.where(ok,e,1e18)
    return out,e

# ------------------------------------------------------------------ T / H
def _kmeans2(px,iters=3):
    N=len(px); mu=px.mean(1,keepdims=True); c=px-mu
    cov=np.einsum('npc,npd->ncd',c,c)
    v=np.tile(np.array([0.57,0.58,0.58]),(N,1))
    for _ in range(6):
        v=np.einsum('ncd,nd->nc',cov,v); v/=np.maximum(np.linalg.norm(v,axis=1,keepdims=True),1e-9)
    proj=np.einsum('npc,nc->np',c,v); thr=proj.mean(1,keepdims=True)
    lab=(proj>thr)
    for _ in range(iters):
        w1=lab[:,:,None].astype(np.float32); w0=1-w1
        m1=(px*w1).sum(1)/np.maximum(w1.sum(1),1e-6); m0=(px*w0).sum(1)/np.maximum(w0.sum(1),1e-6)
        m1=np.where(w1.sum(1)>0,m1,mu[:,0]); m0=np.where(w0.sum(1)>0,m0,mu[:,0])
        d1=((px-m1[:,None])**2).sum(2); d0=((px-m0[:,None])**2).sum(2); lab=d1<d0
    return m0,m1,lab

def _q4(c): return np.clip(np.round(c/17),0,15).astype(np.int32)

def enc_TH(flat,W,iters=2):
    """returns (blk_T,err_T,blk_H,err_H)"""
    N=len(flat); m0,m1,lab=_kmeans2(flat)
    ar=np.arange(N)
    # ---------------- T mode: palette [c0, c1+d, c1, c1-d]
    bestT=np.full(N,1e18); outT=np.zeros((N,8),np.uint8)
    for single,other in ((m0,m1),(m1,m0)):
        for di in range(8):
            d=float(DIST[di])
            q0=_q4(single); q1=_q4(other)
            for it in range(iters+1):
                c0=(q0*17).astype(np.float32); c1=(q1*17).astype(np.float32)
                pal=np.stack([c0,np.clip(c1+d,0,255),c1,np.clip(c1-d,0,255)],1)
                s,e=_perr(flat,pal,W)
                if it==iters: break
                # re-centre from the assignment
                off=np.array([0,d,0,-d],np.float32)
                a0=(s==0)[:,:,None]; n0=a0.sum(1)
                nc0=np.where(n0>0,(flat*a0).sum(1)/np.maximum(n0,1),c0)
                a1=(s>0)[:,:,None]; n1=a1.sum(1)
                shifted=flat-off[s][:,:,None]
                nc1=np.where(n1>0,(shifted*a1).sum(1)/np.maximum(n1,1),c1)
                q0=_q4(nc0); q1=_q4(nc1)
            m=e<bestT
            if m.any():
                bestT[m]=e[m]
                r1,g1,b1=q0[m,0],q0[m,1],q0[m,2]; r2,g2,b2=q1[m,0],q1[m,1],q1[m,2]
                msb,lsb=_pack_sel(s[m]); blk=np.zeros((m.sum(),8),np.int64)
                blk[:,0]=(((r1>>2)&3)<<3)|(r1&3)
                blk[:,1]=(g1<<4)|b1; blk[:,2]=(r2<<4)|g2
                blk[:,3]=(b2<<4)|(((di>>1)&3)<<2)|2|(di&1)
                blk[:,4]=(msb>>8)&255; blk[:,5]=msb&255; blk[:,6]=(lsb>>8)&255; blk[:,7]=lsb&255
                outT[m]=blk.astype(np.uint8)
    outT,okT=_force_mode(outT,2,[(0,0x80),(0,0x40),(0,0x20),(0,0x04)])
    bestT=np.where(okT,bestT,1e18)
    # ---------------- H mode: palette [a+d, a-d, b+d, b-d]
    bestH=np.full(N,1e18); outH=np.zeros((N,8),np.uint8)
    for di in range(8):
        d=float(DIST[di]); qa=_q4(m0); qb=_q4(m1)
        for it in range(iters+1):
            ca=(qa*17).astype(np.float32); cb=(qb*17).astype(np.float32)
            pal=np.stack([np.clip(ca+d,0,255),np.clip(ca-d,0,255),np.clip(cb+d,0,255),np.clip(cb-d,0,255)],1)
            s,e=_perr(flat,pal,W)
            if it==iters: break
            off=np.array([d,-d,d,-d],np.float32)[s]
            sh=flat-off[:,:,None]
            ga=(s<2)[:,:,None]; gb=~ga
            na=ga.sum(1); nb=gb.sum(1)
            qa=_q4(np.where(na>0,(sh*ga).sum(1)/np.maximum(na,1),ca)); qb=_q4(np.where(nb>0,(sh*gb).sum(1)/np.maximum(nb,1),cb))
        va=(qa[:,0]<<8)|(qa[:,1]<<4)|qa[:,2]; vb=(qb[:,0]<<8)|(qb[:,1]<<4)|qb[:,2]
        need=di&1; have=(va>=vb).astype(np.int32)
        swap=(have!=need)
        valid=~((va==vb)&(need==0))                                    # equal colours always read as ob=1
        qa2=np.where(swap[:,None],qb,qa); qb2=np.where(swap[:,None],qa,qb)
        s2=np.where(swap[:,None],s^2,s)
        e=np.where(valid,e,1e18)
        m=e<bestH
        if m.any():
            bestH[m]=e[m]
            r1,g1,b1=qa2[m,0],qa2[m,1],qa2[m,2]; r2,g2,b2=qb2[m,0],qb2[m,1],qb2[m,2]
            msb,lsb=_pack_sel(s2[m]); blk=np.zeros((m.sum(),8),np.int64)
            blk[:,0]=(r1<<3)|(g1>>1)
            blk[:,1]=((g1&1)<<4)|(b1&8)|((b1&6)>>1)
            blk[:,2]=((b1&1)<<7)|(r2<<3)|(g2>>1)
            blk[:,3]=((g2&1)<<7)|(b2<<3)|(((di>>2)&1)<<2)|2|((di>>1)&1)
            blk[:,4]=(msb>>8)&255; blk[:,5]=msb&255; blk[:,6]=(lsb>>8)&255; blk[:,7]=lsb&255
            outH[m]=blk.astype(np.uint8)
    outH,okH=_force_mode(outH,3,[(0,0x80),(1,0x80),(1,0x40),(1,0x20),(1,0x04)])
    bestH=np.where(okH,bestH,1e18)
    return outT,bestT,outH,bestH

# ------------------------------------------------------------------ top level
def encode_rgb(img,W=None,passes=2,modes=("etc1","planar","T","H")):
    """img (H,W,3) uint8 -> (bytes, info).  Picks the lowest weighted error per block."""
    W=W_DEFAULT if W is None else np.asarray(W,np.float32)
    flat=to_blocks(img); N=len(flat)
    cands=[];names=[]
    if "etc1" in modes: cands.append(enc_etc1(flat,W,passes)); names.append("etc1")
    if "planar" in modes: cands.append(enc_planar(flat,W)); names.append("planar")
    if "T" in modes or "H" in modes:
        oT,eT,oH,eH=enc_TH(flat,W)
        if "T" in modes: cands.append((oT,eT)); names.append("T")
        if "H" in modes: cands.append((oH,eH)); names.append("H")
    E=np.stack([c[1] for c in cands],1); pick=E.argmin(1)
    out=np.zeros((N,8),np.uint8)
    for k,(o,_) in enumerate(cands): out[pick==k]=o[pick==k]
    # exact round trip through the validated decoder
    px,mode=decode_rgb(out); dec=px.reshape(N,4,4,3).astype(np.float32)
    p=np.arange(16); decflat=dec[:,p%4,p//4,:]
    err_real=(((decflat-flat)**2)*W).sum((1,2))
    return out.tobytes(),dict(names=names,pick=np.bincount(pick,minlength=len(names)),err=err_real,mode=mode)
'''
_E2 = _types.ModuleType("cf_etc2"); exec(compile(_E2_SRC, "cf_etc2", "exec"), _E2.__dict__)


# ---------------- v55: independent scalar ETC2 RGB decoder (straight from the Khronos data-format spec) ----------------
# Used only to CHECK the encoder: every texture that is written is spot-checked block by block against this decoder.
_R_MOD = [[2,8],[5,17],[9,29],[13,42],[18,60],[24,80],[33,106],[47,183]]; _R_DIST = [3,6,11,16,23,32,41,64]
def _rb(v, hi, lo): return (v >> lo) & ((1 << (hi - lo + 1)) - 1)
def _rsx(v, n): return v - (1 << n) if v & (1 << (n - 1)) else v
def _rcl(x): return 0 if x < 0 else 255 if x > 255 else x
def _ref_block(blk):
    v = int.from_bytes(bytes(blk), "big"); out = [[None] * 4 for _ in range(4)]
    c4 = lambda x: (x << 4) | x; c5 = lambda x: (x << 3) | (x >> 2); c6 = lambda x: (x << 2) | (x >> 4); c7 = lambda x: (x << 1) | (x >> 6)
    sel = lambda x, y: (_rb(v, 16 + x * 4 + y, 16 + x * 4 + y) << 1) | _rb(v, x * 4 + y, x * 4 + y)
    R, G, B = _rb(v, 63, 59), _rb(v, 55, 51), _rb(v, 47, 43); dR, dG, dB = _rsx(_rb(v, 58, 56), 3), _rsx(_rb(v, 50, 48), 3), _rsx(_rb(v, 42, 40), 3)
    if _rb(v, 33, 33) == 0: mode = "e1"; c1 = [c4(_rb(v, 63, 60)), c4(_rb(v, 55, 52)), c4(_rb(v, 47, 44))]; c2 = [c4(_rb(v, 59, 56)), c4(_rb(v, 51, 48)), c4(_rb(v, 43, 40))]
    elif R + dR < 0 or R + dR > 31: mode = "T"
    elif G + dG < 0 or G + dG > 31: mode = "H"
    elif B + dB < 0 or B + dB > 31: mode = "P"
    else: mode = "e1"; c1 = [c5(R), c5(G), c5(B)]; c2 = [c5(R + dR), c5(G + dG), c5(B + dB)]
    if mode == "e1":
        t1, t2, fl = _rb(v, 39, 37), _rb(v, 36, 34), _rb(v, 32, 32)
        for x in range(4):
            for y in range(4):
                first = (x < 2) if fl == 0 else (y < 2); col = c1 if first else c2; tb = _R_MOD[t1 if first else t2]
                m = [tb[0], tb[1], -tb[0], -tb[1]][sel(x, y)]; out[y][x] = tuple(_rcl(c + m) for c in col)
    elif mode == "T":
        a = (c4((_rb(v, 60, 59) << 2) | _rb(v, 57, 56)), c4(_rb(v, 55, 52)), c4(_rb(v, 51, 48))); b = (c4(_rb(v, 47, 44)), c4(_rb(v, 43, 40)), c4(_rb(v, 39, 36)))
        d = _R_DIST[(_rb(v, 35, 34) << 1) | _rb(v, 32, 32)]; pal = [a, tuple(_rcl(c + d) for c in b), b, tuple(_rcl(c - d) for c in b)]
        for x in range(4):
            for y in range(4): out[y][x] = pal[sel(x, y)]
    elif mode == "H":
        R1, G1, B1 = _rb(v, 62, 59), (_rb(v, 58, 56) << 1) | _rb(v, 52, 52), (_rb(v, 51, 51) << 3) | _rb(v, 49, 47); R2, G2, B2 = _rb(v, 46, 43), _rb(v, 42, 39), _rb(v, 38, 35)
        d = _R_DIST[(_rb(v, 34, 34) << 2) | (_rb(v, 32, 32) << 1) | (1 if ((R1 << 8) | (G1 << 4) | B1) >= ((R2 << 8) | (G2 << 4) | B2) else 0)]
        a = (c4(R1), c4(G1), c4(B1)); b = (c4(R2), c4(G2), c4(B2))
        pal = [tuple(_rcl(c + d) for c in a), tuple(_rcl(c - d) for c in a), tuple(_rcl(c + d) for c in b), tuple(_rcl(c - d) for c in b)]
        for x in range(4):
            for y in range(4): out[y][x] = pal[sel(x, y)]
    else:
        RO, GO, BO = _rb(v, 62, 57), (_rb(v, 56, 56) << 6) | _rb(v, 54, 49), (_rb(v, 48, 48) << 5) | (_rb(v, 44, 43) << 3) | _rb(v, 41, 39)
        RH, GH, BH = (_rb(v, 38, 34) << 1) | _rb(v, 32, 32), _rb(v, 31, 25), _rb(v, 24, 19); RV, GV, BV = _rb(v, 18, 13), _rb(v, 12, 6), _rb(v, 5, 0)
        O = (c6(RO), c7(GO), c6(BO)); H = (c6(RH), c7(GH), c6(BH)); V = (c6(RV), c7(GV), c6(BV))
        for x in range(4):
            for y in range(4): out[y][x] = tuple(_rcl((x * (H[k] - O[k]) + y * (V[k] - O[k]) + 4 * O[k] + 2) >> 2) for k in range(3))
    return out
def _spec_check(rgb_blocks, nmax=600):
    """rgb_blocks (N,8) uint8 -> (checked, mismatching).  Compares the embedded vectorised decoder with the scalar spec decoder."""
    N = len(rgb_blocks); ids = np.arange(N) if N <= nmax else np.random.default_rng(3).choice(N, nmax, replace=False)
    px, _ = _E2.decode_rgb(rgb_blocks[ids]); bad = 0
    for k, i in enumerate(ids):
        if (np.array(_ref_block(rgb_blocks[i])) != px[k]).any(): bad += 1
    return len(ids), bad

# ------------------------------- DXT decode -------------------------------
def _c565(v):
    r = (v >> 11) & 31; g = (v >> 5) & 63; b = v & 31
    return np.stack([(r << 3) | (r >> 2), (g << 2) | (g >> 4), (b << 3) | (b >> 2)], -1).astype(np.int32)

def _bc1(blk, force4=False):
    c0 = blk[:, 0].astype(np.int32) | (blk[:, 1].astype(np.int32) << 8)
    c1 = blk[:, 2].astype(np.int32) | (blk[:, 3].astype(np.int32) << 8)
    a, b = _c565(c0), _c565(c1)
    pal = np.zeros((len(blk), 4, 4), np.int32); pal[..., 3] = 255
    pal[:, 0, :3] = a; pal[:, 1, :3] = b
    four = (c0 > c1)[:, None] | bool(force4)      # v73: DXT3/DXT5 colour blocks are ALWAYS 4-colour (D3D spec); c0<=c1 used to give black/transparent idx3 + wrong idx2
    pal[:, 2, :3] = np.where(four, (2 * a + b) // 3, (a + b) // 2)
    pal[:, 3, :3] = np.where(four, (a + 2 * b) // 3, 0)
    pal[:, 3, 3] = np.where(four[:, 0], 255, 0)
    bits = (blk[:, 4].astype(np.uint32) | (blk[:, 5].astype(np.uint32) << 8) |
            (blk[:, 6].astype(np.uint32) << 16) | (blk[:, 7].astype(np.uint32) << 24))
    idx = ((bits[:, None] >> (2 * np.arange(16))[None, :]) & 3).astype(np.int64)
    return np.take_along_axis(pal, idx[:, :, None].repeat(4, 2), 1)

def _bc3_alpha(blk):
    a0 = blk[:, 0].astype(np.int32); a1 = blk[:, 1].astype(np.int32)
    pal = np.zeros((len(blk), 8), np.int32); pal[:, 0] = a0; pal[:, 1] = a1
    gt = a0 > a1
    for i in range(1, 7):
        pal[:, i + 1] = np.where(gt, ((7 - i) * a0 + i * a1) // 7, 0)
    for i in range(1, 5):
        pal[:, i + 1] = np.where(gt, pal[:, i + 1], ((5 - i) * a0 + i * a1) // 5)
    pal[:, 6] = np.where(gt, pal[:, 6], 0); pal[:, 7] = np.where(gt, pal[:, 7], 255)
    bits = np.zeros(len(blk), np.uint64)
    for i in range(6):
        bits |= blk[:, 2 + i].astype(np.uint64) << np.uint64(8 * i)
    idx = ((bits[:, None] >> (3 * np.arange(16, dtype=np.uint64))[None, :]) & np.uint64(7)).astype(np.int64)
    return np.take_along_axis(pal, idx, 1)

def _bc2_alpha(blk):
    out = np.zeros((len(blk), 16), np.int32)
    for i in range(16):
        byte = blk[:, i // 2].astype(np.int32)
        n = (byte >> (4 * (i & 1))) & 15
        out[:, i] = n * 17
    return out

def dxt_decode(data, w, h, fmt):
    bs = 8 if fmt == "DXT1" else 16
    n = (w // 4) * (h // 4)
    blk = np.frombuffer(data[:n * bs], np.uint8).reshape(n, bs)
    if fmt == "DXT1":
        px = _bc1(blk)
    else:
        px = _bc1(blk[:, 8:], True)
        px[..., 3] = _bc3_alpha(blk[:, :8]) if fmt == "DXT5" else _bc2_alpha(blk[:, :8])
    img = px.reshape(h // 4, w // 4, 4, 4, 4).transpose(0, 2, 1, 3, 4).reshape(h, w, 4)
    return img.astype(np.uint8)

def raw_chain(w, bpp):
    tot = 0
    while True:
        tot += max(1, w) ** 2 * bpp
        if w <= 1: break
        w //= 2
    return tot

def chain_size(w, bs):
    tot = 0
    while True:
        tot += max(1, w // 4) ** 2 * bs
        if w <= 1: break
        w //= 2
    return tot

def single_mip_size(w, bs):
    return max(1, w // 4) ** 2 * bs

def match_dxt_size(span, prefer=None):
    """Match span to (fourcc, width). Tries full mip-chain then single-mip."""
    order = (("DXT5", 16), ("DXT1", 8))
    if prefer == "DXT1":
        order = (("DXT1", 8), ("DXT5", 16))
    for f4, bs in order:
        for ww in (4096, 2048, 1024, 512, 256, 128, 64, 32, 16):
            if abs(chain_size(ww, bs) - span) <= 96:
                return f4, ww
    for f4, bs in order:
        for ww in (4096, 2048, 1024, 512, 256, 128, 64, 32, 16):
            if abs(single_mip_size(ww, bs) - span) <= 96:
                return f4, ww
    return None, 0


# ---------------- v39: descriptor-driven decode (handles NPOT sizes) ----------------
def dxt_decode_wh(data, w, h, fmt):
    """DXT1/3/5 top mip for ANY w x h (block grid = ceil(w/4) x ceil(h/4), then crop)."""
    bs = 8 if fmt == "DXT1" else 16
    bw, bh = (w + 3) // 4, (h + 3) // 4
    n = bw * bh
    blk = np.frombuffer(data[:n * bs], np.uint8).reshape(n, bs)
    if fmt == "DXT1":
        px = _bc1(blk)
    else:
        px = _bc1(blk[:, 8:], True)
        px[..., 3] = _bc3_alpha(blk[:, :8]) if fmt == "DXT5" else _bc2_alpha(blk[:, :8])
    img = px.reshape(bh, bw, 4, 4, 4).transpose(0, 2, 1, 3, 4).reshape(bh * 4, bw * 4, 4)
    return img[:h, :w].astype(np.uint8)

def chain_bytes_wh(w, h, bs):
    """size of a full mip chain; every level uses ceil(w/4) x ceil(h/4) blocks, 1x1 still costs a block"""
    tot = 0
    while True:
        tot += max(1, (w + 3) // 4) * max(1, (h + 3) // 4) * bs
        if w <= 1 and h <= 1: break
        w, h = max(1, w // 2), max(1, h // 2)
    return tot

def raw_chain_wh(w, h, bpp):
    tot = 0
    while True:
        tot += w * h * bpp
        if w <= 1 and h <= 1: break
        w, h = max(1, w // 2), max(1, h // 2)
    return tot

# ------------------------------ IFF (2K14) --------------------------------
def _raw_iff_blocks(d, hs):
    """v79: UNCOMPRESSED IFF (no ZLIB wrapper; 2K14 'pngNAME.iff' exported by tools).  The header holds, per data block, the pattern
    [size, flag, file_offset, size]; the first block starts at hs and every next block follows directly.  -> [(raw_bytes, un)]"""
    hw = struct.unpack("<%dI" % (hs // 4), d[:hs // 4 * 4]); out = []; p = hs
    while p < len(d):
        sz = None
        for i in range(2, len(hw) - 1):
            if hw[i] == p and hw[i - 2] == hw[i + 1] and 0 < hw[i + 1] <= len(d) - p: sz = hw[i + 1]; break
        if sz is None: break
        out.append((d[p:p + sz], sz)); p += sz
    return out, p

def read_iff14(path):
    d = open(path, "rb").read()
    if len(d) < 32:
        sys.exit("file too small (%d bytes) – not a valid IFF" % len(d))
    # Common lock/encrypt signatures
    head4 = d[:4]
    if head4 in (b"RED\x00", b"LOCK", b"ENC\x00") or d[:3] == b"RED":
        sys.exit("IFF looks LOCKED/encrypted (header %r). Unlock with RedMC/unlock tool first." % d[:8])
    hs = struct.unpack("<I", d[4:8])[0]
    if hs <= 0 or hs >= len(d):
        sys.exit("bad header size %d (file %d bytes) – possibly locked or corrupt" % (hs, len(d)))
    if d[hs:hs + 4] != b"ZLIB" and _raw_iff_blocks(d, hs)[0]:
        rb, _p = _raw_iff_blocks(d, hs); blocks = [b for b, _u in rb]
        print("   (uncompressed IFF: %d raw data block(s))" % len(blocks))
        if len(blocks) < 2: blocks.append(b"")
        return _read14_recs(d, hs, blocks)
    if d[hs:hs + 4] != b"ZLIB":
        # Some locked packs still have size but garbage instead of ZLIB
        sys.exit(
            "not a readable 2K14-style IFF (no ZLIB at header end).\n"
            "  hs=%d bytes[hs:hs+8]=%r\n"
            "  If this is a locked/modded IFF, unlock it first then retry."
            % (hs, d[hs:hs + 8])
        )
    def _zlib_block(data, un):
        """Decompress one ZLIB payload; tolerate bad Adler32 (common on RED-edited IFFs)."""
        try:
            return zlib.decompress(data)
        except zlib.error:
            pass
        # Raw deflate after 2-byte zlib header – ignores checksum
        if len(data) >= 3:
            try:
                return zlib.decompress(data[2:], -15)
            except zlib.error:
                pass
            try:
                return zlib.decompress(data[2:-4] if len(data) > 6 else data[2:], -15)
            except zlib.error:
                pass
        # Multi-pass (split streams)
        q, buf = 0, b""
        while len(buf) < un and q < len(data):
            do = zlib.decompressobj()
            try:
                buf += do.decompress(data[q:q + 65536])
                q += 65536 - len(do.unused_data) if do.unused_data is not None else 65536
            except zlib.error:
                break
            if len(do.unused_data) >= 4 and do.unused_data[:4] == b"ZLIB":
                break
            if not do.unconsumed_tail and len(buf) >= un:
                break
            q = max(q, 1)
        if len(buf) >= un:
            return buf[:un]
        raise zlib.error("all decompress strategies failed")

    blocks, p = [], hs
    while p + 16 <= len(d) and d[p:p + 4] == b"ZLIB":
        un, co, _ = struct.unpack(">III", d[p + 4:p + 16])
        if co <= 16 or un <= 0:
            print("   warning: odd ZLIB header un=%d co=%d at %d" % (un, co, p))
            break
        payload = d[p + 16:p + co] if p + co <= len(d) else d[p + 16:]
        try:
            buf = _zlib_block(payload, un)
        except zlib.error as e:
            sys.exit("ZLIB decompress failed at offset %d (%s) – locked/corrupt?" % (p, e))
        if len(buf) < un:
            print("   warning: block at %d short (%d < %d)" % (p, len(buf), un))
        blocks.append(buf[:un] if len(buf) >= un else buf)
        p = p + co if p + co <= len(d) else len(d)
    if len(blocks) < 1:
        sys.exit("IFF has no decompressed data blocks – locked or not 2K14-style")
    if len(blocks) < 2:
        print("   warning: only %d data block(s) – textures may be missing" % len(blocks))
        # pad empty second block so callers expecting b1,b2 don't crash hard
        blocks.append(b"")
    return _read14_recs(d, hs, blocks)

def _read14_recs(d, hs, blocks):
    # records: 20 bytes each (hash8, type4, desc_off4, data_off4), last thing before the data
    recs = []
    # v39: 64-bit header variant (32-byte records: hash8, type Q, desc_off Q, data_off Q)
    best64 = 0
    for n in range(1, 64):
        st = hs - n * 32
        if st < 0: break
        if all(struct.unpack("<Q", d[st + 32 * i + 8:st + 32 * i + 16])[0] == 2 for i in range(n)): best64 = n
        else: break
    if best64 >= 4:
        st = hs - best64 * 32
        for i in range(best64):
            h = d[st + 32 * i:st + 32 * i + 8]
            t, do, so = struct.unpack("<QQQ", d[st + 32 * i + 8:st + 32 * i + 32])
            recs.append((h.hex(), do, so))
        return blocks[0], blocks[1], recs
    # v82: the record table is MIXED: 20-byte records (hash8, type=2, desc, data) and 16-byte records (hash8, type=1, desc).  Walk it backwards
    # record by record (the old fixed 20-byte stride stopped at the first 16-byte record -> material map + detail mask were never found).
    p = hs; rl = []
    while len(rl) < 96:
        if p - 20 >= 0 and struct.unpack("<I", d[p - 12:p - 8])[0] == 2:
            rl.append((d[p - 20:p - 12].hex(), ) + struct.unpack("<II", d[p - 8:p])); p -= 20
        elif p - 16 >= 0 and struct.unpack("<I", d[p - 8:p - 4])[0] == 1:
            rl.append((d[p - 16:p - 8].hex(), struct.unpack("<I", d[p - 4:p])[0], 0)); p -= 16
        else: break
    rl.reverse()
    while rl and rl[0][2] == 0 and rl[0][1] != 0: rl.pop(0)         # leading 16-byte junk (not between texture records)
    recs = rl
    return blocks[0], blocks[1], recs

def extract_textures_legacy(iff, outdir):
    b1, b2, recs = read_iff14(iff)
    os.makedirs(outdir, exist_ok=True)
    offs = sorted({so for _, do, so in recs if so} | {len(b2)})
    done = []; results = {}
    for h, do, so in recs:
        if not do or not so: continue
        if do + 0x20 > len(b1) or so >= len(b2):
            print("   skipped %s (bad offsets do=%d so=%d)" % (h[:8], do, so)); continue
        desc = b1[do:do + min(0xF0, len(b1) - do)]
        fourcc = desc[8:12].decode("latin1", errors="ignore") if len(desc) >= 12 else ""
        end = min(o for o in offs if o > so)
        span = end - so
        w = 0
        code = struct.unpack("<I", desc[8:12])[0] if len(desc) >= 12 else 0

        # ---- v39: trust the descriptor (real w x h, may be NOT power of two: 600, 800, 1200x600 ...) ----
        di = desc_info(desc)
        img = None
        if di:
            fmt_, dw, dh = di
            need = fmt_bytes(fmt_, dw, dh)
            if so + need <= len(b2):
                img = decode_any(memoryview(b2)[so:], dw, dh, fmt_)
                fourcc, w = fmt_, dw
                print("   desc %s: %s %dx%d%s" % (h[:8], fmt_, dw, dh, "" if dw == dh else "  (non-square)"))
            else:
                print("   desc %s says %s %dx%d but only %d bytes left -> falling back to size guess" % (h[:8], fmt_, dw, dh, len(b2) - so))
        elif h[:8] not in SLOTS:
            continue          # not a texture record (mesh/other data)
        if img is not None:
            key = h[:8]
            name, size, fname = SLOTS.get(key, ("extra_" + key, 0, "extra_%s.png" % key))
            base = {"face_diffuse": "1_FACE_DIFFUSE", "material_map": "2_MATERIAL_MAP", "normal_map": "3_NORMAL_MAP",
                    "detail_mask": "4_DETAIL_MASK", "hair": "5_HAIR"}.get(name, name)
            ih, iw = img.shape[:2]
            fname = "%s_%dx%d.png" % (base, iw, ih)
            im = Image.fromarray(img, "RGBA")
            if name == "normal_map":
                a = img.astype(np.float32)
                if fourcc != "DXT1" and a[..., 0].mean() < 40 and a[..., 3].std() > 1:   # DXT5nm: X=alpha, Y=green
                    x = a[..., 3] / 255 * 2 - 1; y = a[..., 1] / 255 * 2 - 1
                else:
                    x = a[..., 0] / 255 * 2 - 1; y = a[..., 1] / 255 * 2 - 1
                z = np.sqrt(np.clip(1 - x * x - y * y, 0, 1))
                im = Image.fromarray(np.dstack([(x * .5 + .5) * 255, (y * .5 + .5) * 255, (z * .5 + .5) * 255]).astype(np.uint8), "RGB")
            elif name in ("material_map", "detail_mask") or (name not in ("face_diffuse", "hair") and fourcc == "DXT1"):
                im = im.convert("RGB")
            im.save(os.path.join(outdir, fname)); results[name] = im.copy()
            done.append((name, fourcc, "%dx%d" % (iw, ih), "-> %s" % fname))
            continue

        if code == 0x15:
            # BGRA full mip chain, else DXT under code 0x15, else single-mip BGRA top level
            for ww in (4096, 2048, 1024, 512, 256, 128, 64, 32, 16):
                if abs(raw_chain(ww, 4) - span) <= 96:
                    w, fourcc = ww, "BGRA"; break
            if not w:
                fourcc, w = match_dxt_size(span)
            if not w:
                for ww in (4096, 2048, 1024, 512, 256, 128):
                    if abs(ww * ww * 4 - span) <= 96:  # single-level BGRA no mips
                        w, fourcc = ww, "BGRA"; break
            if not w:
                print("   skipped %s (code 0x15, %d bytes – size unknown)" % (h[:8], span)); continue
        elif fourcc in ("DXT1", "DXT3", "DXT5"):
            pref = fourcc if fourcc in ("DXT1", "DXT5") else "DXT5"
            f4, ww = match_dxt_size(span, prefer=pref)
            if ww:
                fourcc, w = f4, ww
            else:
                bs = 8 if fourcc == "DXT1" else 16
                w = 4096
                while w > 4 and chain_size(w, bs) > span + 16:
                    w //= 2
                # also try single-mip ladder
                if single_mip_size(w, bs) > span + 16 or abs(single_mip_size(w, bs) - span) > abs(chain_size(w, bs) - span):
                    w2 = 4096
                    while w2 > 4 and single_mip_size(w2, bs) > span + 16:
                        w2 //= 2
                    if abs(single_mip_size(w2, bs) - span) < abs(chain_size(w, bs) - span):
                        w = w2
        else:
            fourcc, w = match_dxt_size(span)
            if not w:
                # raw BGRA single level
                for ww in (4096, 2048, 1024, 512, 256, 128):
                    if abs(ww * ww * 4 - span) <= 96:
                        w, fourcc = ww, "BGRA"; break
            if not w:
                if span > 1000 and code != 0:
                    print("   skipped %s (code 0x%x, %d bytes) – unknown format" % (h[:8], code, span))
                continue

        try:
            if fourcc == "BGRA":
                need = w * w * 4
                if so + need > len(b2):
                    print("   skipped %s (BGRA %dx%d needs %d bytes, have %d)" % (h[:8], w, w, need, len(b2) - so)); continue
                img = np.frombuffer(b2[so:so + need], np.uint8).reshape(w, w, 4)[..., [2, 1, 0, 3]].copy()
            else:
                bs = 8 if fourcc == "DXT1" else 16
                need = single_mip_size(w, bs)  # at least top mip present
                if so + need > len(b2):
                    print("   skipped %s (%s %dx%d needs %d bytes)" % (h[:8], fourcc, w, w, need)); continue
                img = dxt_decode(b2[so:], w, w, fourcc)
        except Exception as e:
            print("   skipped %s (decode error: %s)" % (h[:8], e)); continue

        key = h[:8]
        name, size, fname = SLOTS.get(key, ("extra_" + key, 0, "extra_%s_%dx%d.png" % (key, w, w)))
        # Always name by actual resolution
        if size == 0:
            fname = "%s_%dx%d.png" % (
                {"face_diffuse": "1_FACE_DIFFUSE", "material_map": "2_MATERIAL_MAP",
                 "normal_map": "3_NORMAL_MAP", "detail_mask": "4_DETAIL_MASK",
                 "hair": "5_HAIR"}.get(name, name), w, w)
            if name == "face_diffuse":
                fname = "1_FACE_DIFFUSE_%d_rgba.png" % w
        im = Image.fromarray(img, "RGBA")
        if name == "normal_map":
            a = img.astype(np.float32)
            if fourcc != "DXT1" and a[..., 0].mean() < 40 and a[..., 3].std() > 1:   # DXT5nm: X=alpha, Y=green
                x = a[..., 3] / 255 * 2 - 1; y = a[..., 1] / 255 * 2 - 1
            else:
                x = a[..., 0] / 255 * 2 - 1; y = a[..., 1] / 255 * 2 - 1
            z = np.sqrt(np.clip(1 - x * x - y * y, 0, 1))
            im = Image.fromarray(np.dstack([(x * .5 + .5) * 255, (y * .5 + .5) * 255, (z * .5 + .5) * 255]).astype(np.uint8), "RGB")
        elif name in ("material_map", "detail_mask") or (name not in ("face_diffuse", "hair") and fourcc == "DXT1"):
            im = im.convert("RGB")
        if size and size != w:
            im = _resize(im, size)
        im.save(os.path.join(outdir, fname)); results[name] = im.copy()
        done.append((name, fourcc, "%dx%d" % (w, w), "-> %s %s" % (fname, im.size)))
    # If material_map missing, promote a large extra_* texture as material candidate
    if "material_map" not in results:
        for k, im in list(results.items()):
            if k.startswith("extra_") and im.size[0] >= 128:
                print("   promoting %s -> material_map (source had no material slot)" % k)
                results["material_map"] = im.convert("RGB")
                # also save under standard name
                fn = "2_MATERIAL_MAP_%dx%d.png" % im.size
                im2 = im.convert("RGB")
                im2.save(os.path.join(outdir, fn))
                done.append(("material_map", "promoted", "%dx%d" % im.size, "-> " + fn))
                break

    print("Textures from", os.path.basename(iff))
    for x in done: print("  ", *x)
    if not done: print("  no DXT textures found")
    # v39 guard: scrambled / locked texture data decodes to pure static. never port that silently.
    def _rough(im):
        a = np.asarray(im.convert("L"), np.float32)
        return float(np.abs(np.diff(a, axis=1)).mean() + np.abs(np.diff(a, axis=0)).mean())
    rf = {k: _rough(results[k]) for k in ("face_diffuse", "material_map", "detail_mask") if k in results}
    if rf and sum(v > 55 for v in rf.values()) >= 2:
        print("  !! NOISE: %s" % ", ".join("%s=%.0f" % kv for kv in rf.items()))
        sys.exit("\nTHE TEXTURE DATA OF %s IS SCRAMBLED (decodes to static, normal photos score 2-30, this scores 55+).\n"
                 "Sizes/offsets/format in the header are fine, so this is NOT a decoder size problem: the bytes themselves are\n"
                 "protected/locked or from a different texture layout. Unlock it / re-export it, then run again.\n"
                 "Nothing was ported (porting this would only put noise into the 2K20 IFF)." % os.path.basename(iff))
    if "face_diffuse" in results and "material_map" not in results:
        print("  note: no material_map in source – auto port will use neutral placeholder")
    return results


def _noise_guard(results, iff):
    """stop instead of porting static (scrambled/locked data)"""
    def _rough(im):
        a = np.asarray(im.convert("L"), np.float32)
        return float(np.abs(np.diff(a, axis=1)).mean() + np.abs(np.diff(a, axis=0)).mean())
    rf = {k: _rough(results[k]) for k in ("face_diffuse", "material_map", "detail_mask") if k in results}
    if rf and sum(v > 55 for v in rf.values()) >= 2:
        sys.exit("\nTHE TEXTURE DATA OF %s DECODES TO STATIC (%s).\nHeader sizes are fine, so the bytes themselves are protected/locked or use another layout. Nothing was ported."
                 % (os.path.basename(iff), ", ".join("%s=%.0f" % kv for kv in rf.items())))

# --------------------- descriptor-driven texture reader (v2) ---------------------
def _header_table(hdr):
    """(flag,size,virt_off) entries; value=(size<<10)|flag; flag 0x80..0x86 = LOD chunk, 0x9f = tail chunk."""
    vals = [struct.unpack("<I", hdr[i:i + 4])[0] for i in range(0, len(hdr) - 3, 4)]
    ents = []; i = 0
    while i < len(vals) - 1:
        v = vals[i]
        if (v & 0x3FF) in (0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x9F) and (v >> 10) > 0:
            ents.append((v & 0x3FF, v >> 10, vals[i + 1])); i += 2
        else: i += 1
    return ents

# ======================= v42: DEEP TEXTURE SCAN =======================
# More formats (BC4/BC5/L8/A8/A8L8/X8R8G8B8), LOD-table realignment, orphan chunk sweep,
# span sweep for unlisted records, and "look-based" slot guessing so the material map is
# found even when its record hash is not the one in SLOTS.
DEEP_SCAN = True
SLOT_REMAP = {}        # {"27a62111": "material_map"}  from --map
TEX_OVERRIDES = {}     # {"material_map": "my_material.png"}  from --material etc.
ALL_SLOTS = ("face_diffuse", "material_map", "normal_map", "detail_mask", "hair")
_SLOT_ALIAS = {"face": "face_diffuse", "diffuse": "face_diffuse", "material": "material_map", "mat": "material_map",
               "normal": "normal_map", "detail": "detail_mask", "mask": "detail_mask"}

_FOURCC = {b"DXT1": "DXT1", b"DXT2": "DXT3", b"DXT3": "DXT3", b"DXT4": "DXT5", b"DXT5": "DXT5",
           b"ATI1": "ATI1", b"BC4U": "ATI1", b"BC4S": "ATI1", b"ATI2": "ATI2", b"BC5U": "ATI2", b"BC5S": "ATI2"}
_D3D = {0x15: "BGRA", 0x16: "BGRA", 0x32: "L8", 0x1C: "A8", 0x33: "A8L8"}

def fmt_of(code4):
    f = _FOURCC.get(bytes(code4))
    return f or _D3D.get(struct.unpack("<I", bytes(code4))[0])

def desc_info(desc):
    """2K14 texture descriptor -> (fmt, w, h) or None.  fourcc @+0x08, size @+0x68 as <HH (w,h)."""
    if len(desc) < 0x6C: return None
    fmt = fmt_of(desc[8:12])
    w, h = struct.unpack("<HH", desc[0x68:0x6C])
    if not fmt or not (4 <= w <= 4096 and 4 <= h <= 4096): return None
    return fmt, w, h

def fmt_bytes(fmt, w, h):
    bw, bh = (w + 3) // 4, (h + 3) // 4
    if fmt in ("DXT1", "ATI1"): return bw * bh * 8
    if fmt in ("DXT3", "DXT5", "ATI2"): return bw * bh * 16
    if fmt == "BGRA": return w * h * 4
    if fmt in ("L8", "A8"): return w * h
    if fmt == "A8L8": return w * h * 2
    raise ValueError("unknown format %s" % fmt)

def _blk_img(px, w, h):
    bw, bh = (w + 3) // 4, (h + 3) // 4
    img = px.reshape(bh, bw, 4, 4, 4).transpose(0, 2, 1, 3, 4).reshape(bh * 4, bw * 4, 4)
    return img[:h, :w].astype(np.uint8)

def decode_any(data, w, h, fmt):
    need = fmt_bytes(fmt, w, h)
    if len(data) < need: raise ValueError("need %d bytes, have %d" % (need, len(data)))
    if fmt in ("DXT1", "DXT3", "DXT5"):
        return dxt_decode_wh(data, w, h, fmt)
    if fmt == "ATI1":                                     # BC4: one channel -> gray
        blk = np.frombuffer(data[:need], np.uint8).reshape(-1, 8)
        r = _bc3_alpha(blk); px = np.zeros((len(blk), 16, 4), np.int32)
        px[..., 0] = px[..., 1] = px[..., 2] = r; px[..., 3] = 255
        return _blk_img(px, w, h)
    if fmt == "ATI2":                                     # BC5: R,G (normal x,y)
        blk = np.frombuffer(data[:need], np.uint8).reshape(-1, 16)
        px = np.zeros((len(blk), 16, 4), np.int32)
        px[..., 0] = _bc3_alpha(blk[:, :8]); px[..., 1] = _bc3_alpha(blk[:, 8:]); px[..., 3] = 255
        return _blk_img(px, w, h)
    raw = np.frombuffer(data[:need], np.uint8)
    if fmt == "BGRA":
        img = raw.reshape(h, w, 4)[..., [2, 1, 0, 3]].copy()
        if img[..., 3].max() == 0: img[..., 3] = 255          # X8R8G8B8
        return img
    if fmt == "L8":
        g = raw.reshape(h, w); return np.dstack([g, g, g, np.full_like(g, 255)])
    if fmt == "A8":
        a = raw.reshape(h, w); return np.dstack([a, a, a, np.full_like(a, 255)])
    if fmt == "A8L8":
        p = raw.reshape(h, w, 2); l = p[..., 0]; return np.dstack([l, l, l, p[..., 1]])
    raise ValueError(fmt)

def _rough_img(img):
    """how noisy the picture is: natural ~2-30, scrambled/wrong-format decode 55+"""
    a = img[..., :3].astype(np.float32) @ np.array([.299, .587, .114], np.float32)
    h, w = a.shape
    y0, x0 = max(0, h // 2 - 128), max(0, w // 2 - 128)
    a = a[y0:y0 + 256, x0:x0 + 256]
    if a.shape[0] < 3 or a.shape[1] < 3: return 0.0
    return float(np.abs(np.diff(a, axis=1)).mean() + np.abs(np.diff(a, axis=0)).mean())

def _dim_candidates(size, chain):
    """(fmt, w, h) whose byte size equals `size` (chain=True: also accept a full mip chain, +-96 bytes)"""
    out = []; p2 = (4096, 2048, 1024, 512, 256, 128, 64, 32)
    for fmt, bs in (("DXT1", 8), ("DXT5", 16), ("BGRA", 0)):
        for w in p2:
            for h in (w, w // 2, w * 2):
                if h not in p2: continue
                single = fmt_bytes(fmt, w, h)
                if chain:
                    full = raw_chain_wh(w, h, 4) if fmt == "BGRA" else chain_bytes_wh(w, h, bs)
                    ok = abs(single - size) <= 96 or abs(full - size) <= 96
                else:
                    ok = single == size
                if ok: out.append((fmt, w, h))
    return out

def _guess_decode(data, size, chain, limit=45.0):
    """unknown block of texture bytes -> best (fmt,w,h,img,rough) by smoothness, or None"""
    best = None
    for fmt, w, h in _dim_candidates(size, chain):
        try: img = decode_any(data, w, h, fmt)
        except Exception: continue
        r = _rough_img(img)
        if best is None or r < best[4]: best = (fmt, w, h, img, r)
    return best if best and best[4] < limit else None

def _tex_info(iff, b1, b2, recs):
    """-> (info, orphans, unknown, has_table)
       info    : key -> (fmt, w, h, lod0_offset, note)
       orphans : [(size, offset)] LOD0 chunks in the header table that no descriptor claimed
       unknown : [(key, w, h, record_offset)] descriptors with an unknown format (no table)"""
    d = open(iff, "rb").read(); hs = struct.unpack("<I", d[4:8])[0]
    texs = []
    for h, do, so in sorted([r for r in recs if r[1] and r[2]], key=lambda r: r[2]):
        desc = b1[do:do + 0xF0]
        if len(desc) < 0x70: continue
        w, hh = struct.unpack("<HH", desc[0x68:0x6C])
        if w < 4 or hh < 4 or w > 8192 or hh > 8192: continue
        texs.append((h[:8], fmt_of(desc[8:12]), w, hh, so))
    if not texs: return {}, [], [], False
    ents = _header_table(d[:hs])
    lod0 = []
    tails = [i for i, e in enumerate(ents) if e[0] == 0x9F]
    if tails:                                        # physical layout: chunks in table order, ending at the end of block 2
        run = ents[tails[0]:]; pos = len(b2) - sum(e[1] for e in run)
        for fl, sz, vo in run:
            if fl == 0x80: lod0.append((sz, pos))
            pos += sz
    out = {}; orphans = []; unk = []; j = 0
    for key, fmt, w, hh, so in texs:
        if fmt: need = {fmt_bytes(fmt, w, hh): fmt}
        else:   need = {fmt_bytes(f, w, hh): f for f in ("BGRA", "DXT5", "DXT1")}
        if lod0 and j < len(lod0):
            k = next((m for m in range(j, min(j + 4, len(lod0))) if lod0[m][0] in need), None)
            if k is not None:
                orphans += lod0[j:k]
                out[key] = (fmt or need[lod0[k][0]], w, hh, lod0[k][1], "" if fmt else "format guessed from size")
                j = k + 1; continue
            if fmt:
                print("   warning: %s table size %d != %dx%d %s (%d) - using table anyway" % (key, lod0[j][0], w, hh, fmt, need and list(need)[0]))
                out[key] = (fmt, w, hh, lod0[j][1], "size mismatch"); j += 1; continue
            continue                                  # unknown format, nothing matches: the orphan sweep will look at the chunks
        if fmt: out[key] = (fmt, w, hh, so, "")       # per-texture chain: top level at the record offset
        else:   unk.append((key, w, hh, so))
    orphans += lod0[j:]
    return out, orphans, unk, bool(lod0)

# ---- which decoded texture goes in which 2K20 slot ----
def _look(v):
    img = v["img"][::4, ::4]
    a = img[..., :3].astype(np.float32)
    m = a.reshape(-1, 3).mean(0); sat = float((a.max(2) - a.min(2)).mean())
    al = img[..., 3].astype(np.float32)
    return m, sat, float(al.mean()), float(al.std())

def _normalish(v, m, al_std):
    if v["fmt"] == "ATI2": return 3
    if m[2] > 165 and abs(m[0] - 128) < 40 and abs(m[1] - 128) < 40: return 2
    if v["fmt"] != "DXT1" and m[0] < 40 and al_std > 1 and 90 < m[1] < 170: return 2      # DXT5nm
    return 0

def _assign_slots(dec):
    slot_of = {}; taken = set(); how = {}
    for k, s in SLOT_REMAP.items():                       # 1) your --map
        if k in dec and s not in taken: slot_of[k] = s; taken.add(s); how[k] = "--map"
    for k in dec:                                         # 2) known hashes
        if k in slot_of: continue
        nm = SLOTS.get(k, (None,))[0]
        if nm and nm not in taken: slot_of[k] = nm; taken.add(nm); how[k] = "hash"
    cand = {k: _look(v) for k, v in dec.items()           # 3) by look, only for slots still empty
            if k not in slot_of and min(dec[k]["w"], dec[k]["h"]) >= 64 and dec[k]["rough"] < 55}
    def take(slot, k, why):
        slot_of[k] = slot; taken.add(slot); how[k] = "guessed: " + why; cand.pop(k, None)
    if "normal_map" not in taken:
        sc = {k: _normalish(dec[k], l[0], l[3]) for k, l in cand.items()}
        sc = {k: s for k, s in sc.items() if s >= 2}
        if sc: k = max(sc, key=lambda x: (sc[x], dec[x]["w"] * dec[x]["h"])); take("normal_map", k, "bluish normal-map look")
    if "face_diffuse" not in taken:
        sk = [k for k, (m, sat, am, asd) in cand.items() if m[0] > m[1] > m[2] and m[0] > 80 and sat > 10]
        if sk: take("face_diffuse", max(sk, key=lambda x: dec[x]["w"] * dec[x]["h"]), "skin-tone look")
    if "material_map" not in taken:
        mc = [k for k, (m, sat, am, asd) in cand.items() if not (am < 245 and asd > 40)]      # no alpha cut-outs (that is hair)
        if mc:
            k = max(mc, key=lambda x: (int(dec[x]["w"] == 2 * dec[x]["h"] or dec[x]["h"] == 2 * dec[x]["w"]), dec[x]["w"] * dec[x]["h"]))
            take("material_map", k, "largest remaining non-hair texture")
    if "detail_mask" not in taken and cand:
        k = min(cand, key=lambda x: cand[x][1]); take("detail_mask", k, "lowest-saturation leftover")
    return slot_of, how

def _post_texture(key, fourcc, img, outdir, results, done, name=None):
    w, hgt = img.shape[1], img.shape[0]
    if name is None:
        name, size, fname = SLOTS.get(key, ("extra_" + key, 0, "extra_%s_%dx%d.png" % (key, w, hgt)))
    else:
        size, fname = 0, ""
    if size == 0:
        base = {"face_diffuse": "1_FACE_DIFFUSE", "material_map": "2_MATERIAL_MAP", "normal_map": "3_NORMAL_MAP",
                "detail_mask": "4_DETAIL_MASK", "hair": "5_HAIR"}.get(name, name)
        fname = "%s_%dx%d.png" % (base, w, hgt)
        if name == "face_diffuse": fname = "1_FACE_DIFFUSE_%d_rgba.png" % w
    im = Image.fromarray(img, "RGBA")
    if name == "normal_map":
        a = img.astype(np.float32)
        if fourcc not in ("DXT1", "ATI2") and a[..., 0].mean() < 40 and a[..., 3].std() > 1:     # DXT5nm: X=alpha, Y=green
            x = a[..., 3] / 255 * 2 - 1; y = a[..., 1] / 255 * 2 - 1
        else:
            x = a[..., 0] / 255 * 2 - 1; y = a[..., 1] / 255 * 2 - 1
        z = np.sqrt(np.clip(1 - x * x - y * y, 0, 1))
        im = Image.fromarray(np.dstack([(x * .5 + .5) * 255, (y * .5 + .5) * 255, (z * .5 + .5) * 255]).astype(np.uint8), "RGB")
    elif name in ("material_map", "detail_mask") or (name not in ("face_diffuse", "hair") and fourcc in ("DXT1", "ATI1", "ATI2", "L8", "A8")):
        im = im.convert("RGB")
    if size and size != w:
        im = _resize(im, size)
    im.save(os.path.join(outdir, fname)); results[name] = im.copy()
    done.append((name, fourcc, "%dx%d" % (w, hgt), "-> %s %s" % (fname, im.size)))

def _save_any(img, path):
    if img[..., 3].min() == 255: Image.fromarray(img[..., :3], "RGB").save(path)
    else: Image.fromarray(img, "RGBA").save(path)

def extract_textures(iff, outdir):
    b1, b2, recs = read_iff14(iff)
    info, orphans, unk, has_table = _tex_info(iff, b1, b2, recs)
    if not info:
        return extract_textures_legacy(iff, outdir)
    os.makedirs(outdir, exist_ok=True)
    mv = memoryview(b2)
    dec = {}
    for key, (fmt, w, hh, off, note) in info.items():
        try: img = decode_any(mv[off:], w, hh, fmt)
        except Exception as e:
            print("   skipped %s (%s %dx%d: %s)" % (key, fmt, w, hh, e)); continue
        dec[key] = dict(fmt=fmt, img=img, w=w, h=hh, off=off, note=note)
    if DEEP_SCAN:
        n0 = len(dec)
        for k, (sz, off) in enumerate(orphans):                       # chunks in the LOD table that no descriptor owns
            if sz < 2048 or off + sz > len(b2): continue
            r = _guess_decode(mv[off:off + sz], sz, False)
            if r: dec["orphan%02d" % k] = dict(fmt=r[0], img=r[3], w=r[1], h=r[2], off=off, note="orphan LOD chunk, format guessed")
        if not has_table:                                             # per-texture chains: look at unknown formats / unlisted records
            offs = sorted({so for _, do, so in recs if so} | {len(b2)})
            seen = set(dec) | {k for k, _, _, _ in unk}
            todo = [(k, so) for k, w, hh, so in unk]
            todo += [(h[:8], so) for h, do, so in recs if so and h[:8] not in seen and so < len(b2)]
            for key, so in todo:
                nxt = min((o for o in offs if o > so), default=len(b2)); span = nxt - so
                if span < 2048: continue
                r = _guess_decode(mv[so:nxt], span, True)
                if r: dec[key] = dict(fmt=r[0], img=r[3], w=r[1], h=r[2], off=so, note="record sweep, format guessed")
        if len(dec) > n0: print("   deep scan found %d extra texture(s) the header did not describe" % (len(dec) - n0))
    for v in dec.values(): v["rough"] = _rough_img(v["img"])
    slot_of, how = _assign_slots(dec)
    allout = os.path.join(outdir, "all_textures"); os.makedirs(allout, exist_ok=True)
    for k, v in dec.items():                                          # raw dump of everything so nothing is lost
        _save_any(v["img"], os.path.join(allout, "%s_%s_%dx%d.png" % (k, v["fmt"], v["w"], v["h"])))
    results = {}; done = []
    for k, v in dec.items():
        _post_texture(k, v["fmt"], v["img"], outdir, results, done, name=slot_of.get(k, "extra_" + k))
    print("Textures from", os.path.basename(iff))
    for x in done: print("  ", *x)
    for k, v in dec.items():
        tag = how.get(k)
        if tag and tag != "hash" or v["note"]:
            print("   %s %s %dx%d -> %s  [%s%s]" % (k, v["fmt"], v["w"], v["h"], slot_of.get(k, "extra"), tag or "-", "; " + v["note"] if v["note"] else ""))
    print("   every decoded texture also saved in:", allout)
    if "material_map" in slot_of.values():
        mk = next(k for k, s in slot_of.items() if s == "material_map")
        chd = os.path.join(outdir, "material_channels"); os.makedirs(chd, exist_ok=True)
        mi = dec[mk]["img"]
        for ci, cn in enumerate("RGB"): Image.fromarray(mi[..., ci], "L").save(os.path.join(chd, "2_MATERIAL_%s.png" % cn))
        if mi[..., 3].std() > 1: Image.fromarray(mi[..., 3], "L").save(os.path.join(chd, "2_MATERIAL_A.png"))
        print("   material channels split ->", chd)
    else:
        print("  !! NO MATERIAL MAP found. decoded: %s" % ", ".join("%s(%s %dx%d)" % (k, v["fmt"], v["w"], v["h"]) for k, v in dec.items()))
        print("     pick it yourself:  --map HASH=material_map   (HASH from all_textures file names)  or  --material your.png")
    _noise_guard(results, iff)
    return results




# ----------------------- texture encoding into 2K20 IFF -----------------------
TAB=np.array([(2,8),(5,17),(9,29),(13,42),(18,60),(24,80),(33,106),(47,183)])
MODS=np.stack([np.array([a,b,-a,-b]) for a,b in TAB])            # (8,4) selector 0..3 -> modifier
EAC=np.array([[-3,-6,-9,-15,2,5,8,14],[-3,-7,-10,-13,2,6,9,12],[-2,-5,-8,-13,1,4,7,12],[-2,-4,-6,-13,1,3,5,12],
 [-3,-6,-8,-12,2,5,7,11],[-3,-7,-9,-11,2,6,8,10],[-4,-7,-8,-11,3,6,7,10],[-3,-5,-8,-11,2,4,7,10],
 [-2,-6,-8,-10,1,5,7,9],[-2,-5,-8,-10,1,4,7,9],[-2,-4,-8,-10,1,3,7,9],[-2,-5,-7,-10,1,4,6,9],
 [-2,-4,-7,-10,1,3,6,9],[-1,-2,-3,-10,0,1,2,9],[-4,-6,-8,-9,3,5,7,8],[-3,-5,-7,-9,2,4,6,8]])
def _blocks(img):
    h,w=img.shape[:2];return img.reshape(h//4,4,w//4,4,-1).transpose(0,2,1,3,4).reshape(-1,4,4,img.shape[2])
LW = np.array([0.299, 0.587, 0.114], np.float32) * 3     # perceptual (luma-heavy) error weights
UPSCALE = True          # v67: enlarging (HD base bigger than the 2K14 map) = clean upscaler: Lanczos in 2x steps + light unsharp after each step
UPSCALE_SHARP = 0.0     # 0 = plain Lanczos
def _lz(img, n):
    if img.mode == "RGBA":
        r, g, b, a = img.split(); rgb = Image.merge("RGB", (r, g, b)).resize((n, n), Image.LANCZOS); rgb.putalpha(a.resize((n, n), Image.LANCZOS)); return rgb
    return img.resize((n, n), Image.LANCZOS)
def _upscale(img, size):
    while img.size[0] < size:
        n = min(img.size[0] * 2, size); img = _lz(img, n)
        if UPSCALE_SHARP > 0:
            if img.mode == "RGBA":
                r, g, b, a = img.split(); rgb = Image.merge("RGB", (r, g, b)).filter(ImageFilter.UnsharpMask(radius=1.0, percent=int(80 * UPSCALE_SHARP), threshold=2)); rgb.putalpha(a); img = rgb
            else: img = img.filter(ImageFilter.UnsharpMask(radius=1.0, percent=int(80 * UPSCALE_SHARP), threshold=2))
    return img

def _resize(img, size):
    """v50: AREA (box) filter when shrinking, and RGB / ALPHA RESIZED SEPARATELY.
    ROOT CAUSE of the 'static noise' (v49 and earlier): Pillow silently PREMULTIPLIES RGBA by alpha before it resizes.  In the
    2K14 face texture alpha is only a MASK (hair = 0, eye/nostril/mouth openings = 0) while the RGB under it is real
    (dark hair, eye outlines).  Premultiplying wiped that RGB to black and un-premultiplying the faint edge pixels produced
    random coloured dots -> black hair with blue/red/yellow specks and black outlines around eyes, nose and mouth.
    Also: Lanczos rings around hard edges, so shrinking uses box (exact area average); Lanczos only when enlarging."""
    if img.size == (size, size): return img
    if size > img.size[0] and UPSCALE: return _upscale(img, size)
    flt = Image.LANCZOS            # v65: LANCZOS for every resize (down and up), as requested; RGB and alpha still resized separately (no premultiply)
    if img.mode == "RGBA":
        r, g, b, a = img.split()
        rgb = Image.merge("RGB", (r, g, b)).resize((size, size), flt)
        al = a.resize((size, size), flt)
        rgb.putalpha(al); return rgb
    return img.resize((size, size), flt)

def _encode_eac_serial(alpha):
    """alpha (H,W) uint8 -> bytes (8 per block).  v96: same result as before, ~3x faster (int16, the search keeps only the error, indices computed once for the winner)."""
    B=_blocks(alpha[:,:,None].astype(np.float32))[...,0];N=len(B);p=np.arange(16);v=B[:,p%4,p//4]   # (N,16)
    out=np.zeros((N,8),np.uint8)
    flat=(v.max(1)==v.min(1))
    # v39: flat block = base value + modifier 0.  OLD code used multiplier 0, which many GPUs/drivers treat as 1
    # -> alpha 255 became 252.  Table 13 index 4 has modifier 0, multiplier 1 -> exact on every decoder.
    out[flat,0]=v[flat,0].astype(np.uint8); out[flat,1]=(1<<4)|13
    out[flat,2:8]=np.array([0x92,0x49,0x24,0x92,0x49,0x24],np.uint8)
    todo=np.where(~flat)[0]
    EACi=[np.asarray(EAC[t],np.int16) for t in range(16)]
    for c0 in range(0,len(todo),512):
        ids=todo[c0:c0+512];V=v[ids];n=len(ids);Vi=V.astype(np.int16)[:,:,None]
        mid=np.round((V.max(1)+V.min(1))/2);mean=np.round(V.mean(1))
        best=np.full(n,1<<30,np.int32);bb=np.zeros(n);bm=np.zeros(n,int);bt=np.zeros(n,int)
        for base in (mid,mean):
            b16=base.astype(np.int16)[:,None]
            for t in range(16):
                for m in range(1,16):
                    cand=np.clip(b16+EACi[t][None,:]*m,0,255)                       # (n,8) int16
                    e=np.abs(Vi-cand[:,None,:]).min(2).sum(1,dtype=np.int32)
                    r=e<best;best[r]=e[r];bb[r]=base[r];bm[r]=m;bt[r]=t
        # indices only for the winning (base, table, multiplier) of every block
        bi=np.zeros((n,16),int)
        for t in range(16):
            for m in range(1,16):
                sel=np.where((bt==t)&(bm==m))[0]
                if len(sel)==0: continue
                cand=np.clip(bb[sel].astype(np.int16)[:,None]+EACi[t][None,:]*m,0,255)
                bi[sel]=np.abs(Vi[sel]-cand[:,None,:]).argmin(2)
        bits=np.zeros(n,np.uint64)
        for k in range(16):bits|=bi[:,k].astype(np.uint64)<<np.uint64(45-3*k)
        out[ids,0]=bb.astype(np.uint8);out[ids,1]=((bm<<4)|bt).astype(np.uint8)
        for i in range(6):out[ids,2+i]=((bits>>np.uint64(8*(5-i)))&np.uint64(255)).astype(np.uint8)
    return out.tobytes()

# v96: blocks are independent -> big textures are cut into horizontal strips (multiples of 4 rows) and encoded in parallel threads
# (numpy releases the GIL).  Block order is row-major, so the strips just concatenate.  CF_THREADS=1 turns it off.
import concurrent.futures as _cfut
ENC_THREADS = int(os.environ.get("CF_THREADS", "0")) or max(1, min(8, os.cpu_count() or 2))
def _par_rows(fn, img):
    h = img.shape[0]
    if ENC_THREADS <= 1 or h < 64: return fn(img)
    per = max(16, -(-h // ENC_THREADS + 3) // 4 * 4); cuts = list(range(0, h, per))
    parts = [img[a:min(h, a + per)] for a in cuts]
    with _cfut.ThreadPoolExecutor(max_workers=min(ENC_THREADS, len(parts))) as ex: return b"".join(ex.map(fn, parts))
def encode_eac(alpha): return _par_rows(_encode_eac_serial, alpha)
def _enc_policy(kind):
    """v56: native ETC2 only (individual/differential + PLANAR + T + H, best per block).  No ETC1-only fallback, no env switches.
    Normal map: smooth ETC2 modes + flat X/Y weights (no T/H palette noise)."""
    modes = ("etc1", "planar", "T", "H"); W = None      # 'etc1' = ETC2's individual/differential block types (part of the ETC2 spec)
    if kind == "normal_map": modes = ("etc1", "planar"); W = np.array([1.0, 1.0, 0.35], np.float32)
    if ETC2_ONLY:                                       # v79: ETC2 encoder - planar / T / H only, no ETC1-style blocks at all
        modes = tuple(m for m in modes if m != "etc1")
        if kind == "normal_map": modes = ("planar", "T", "H")
    return modes, W
def _etcpak_rgba_bytes(img):
    h, w = img.shape[:2]; a = np.empty((h, w, 4), np.uint8); a[..., :3] = img[..., :3]
    a[..., 3] = img[..., 3] if img.shape[2] > 3 else 255
    return np.ascontiguousarray(a).tobytes(), w, h
def encode_etc2_rgb(img, kind=None):
    """v62b: etcpak (ETC2 RGB8) when available; otherwise the built-in v52 encoder (best of ETC1 / PLANAR / T / H per block)."""
    if _ETCPAK is not None and not _ETCPAK_FAILED[0] and img.shape[0] % 4 == 0 and img.shape[1] % 4 == 0:
        try:
            raw, w, h = _etcpak_rgba_bytes(img); d = bytes(_ETCPAK.compress_etc2_rgb(raw, w, h))
            if len(d) == (w // 4) * (h // 4) * 8: return d
            raise ValueError("etcpak returned %d bytes" % len(d))
        except Exception as e:
            _ETCPAK_FAILED[0] = True; print("   WARNING: etcpak failed (%s) -> built-in ETC2 encoder" % e)
    modes, W = _enc_policy(kind)
    return _par_rows(lambda im: _E2.encode_rgb(np.ascontiguousarray(im[...,:3]),W=W,passes=ENC_PASSES,modes=modes)[0], img)
def encode_etc2_rgba(img, kind=None):
    if _ETCPAK is not None and not _ETCPAK_FAILED[0] and img.shape[0] % 4 == 0 and img.shape[1] % 4 == 0:
        try:
            raw, w, h = _etcpak_rgba_bytes(img); d = bytes(_ETCPAK.compress_etc2_rgba(raw, w, h))
            if len(d) == (w // 4) * (h // 4) * 16: return d          # etcpak block = [EAC alpha 8B][ETC2 colour 8B] = same layout as this file
            raise ValueError("etcpak returned %d bytes" % len(d))
        except Exception as e:
            _ETCPAK_FAILED[0] = True; print("   WARNING: etcpak failed (%s) -> built-in ETC2 encoder" % e)
    rgb=encode_etc2_rgb(img, kind);a=encode_eac(img[...,3])
    n=len(rgb)//8;A=np.frombuffer(a,np.uint8).reshape(n,8);C=np.frombuffer(rgb,np.uint8).reshape(n,8)
    return np.concatenate([A,C],1).tobytes()

def _find_descs(b1):
    out = []
    for o in range(0, len(b1) - 0xF0 + 4, 4):
        f1, f2 = struct.unpack("<II", b1[o + 0x10:o + 0x18])
        if f1 == f2 and f1 in (7, 15, 16):
            w, h = struct.unpack("<HH", b1[o + 0xC8:o + 0xCC])
            if w and w == h and (w & (w - 1)) == 0 and 16 <= w <= 4096:
                out.append((o, f1, w))
    return out




# ---------------- v44: DATA-DRIVEN texture placement (no hard-coded layout) ----------------
# The IFF header holds a table of chunks: (size<<8 | type, offset). Every texture record points (its "data" field) at a
# span; the chunks that lie inside that span are the real storage of that texture: LOD0 chunk, optional LOD1 chunk,
# and one chunk with all the smaller mips. We read those instead of assuming "last 4 textures at end of block".
def _hdr_chunks(hdr, b2len):
    out = []
    for o in range(0x30, len(hdr) - 15, 8):
        f, off = struct.unpack_from("<QQ", hdr, o)
        sz = f >> 8
        if (f & 0x80) and f >> 40 == 0 and sz > 0 and off > 0 and off % 16 == 0 and off + sz // 4 <= b2len + 0x100000:   # v79: size field = 4 x bytes (HD: big LOD0 chunks of normal / hair were dropped -> only 3 of 5 textures written)
            out.append((off, sz, f & 0xff))
    return out

def _lvl_size_fmt(f, w, h):
    if f == 7: return w * h * 2
    if f == 1: return w * h * 4
    bs = 16 if f == 16 else 8
    return max(1, (w + 3) // 4) * max(1, (h + 3) // 4) * bs

def tex_map(hdr, b1, b2len):
    """-> {record_hash_hex: dict(fmt, w, h, levels=[(offset, nbytes, w, h)])} read from the file itself."""
    chunks = _hdr_chunks(bytes(hdr), b2len)
    res = {}
    for o in range(0, len(hdr) - 31, 4):
        t = struct.unpack_from("<I", hdr, o + 8)[0]
        if t not in (1, 2) or struct.unpack_from("<I", hdr, o + 12)[0] != 0: continue
        x, y = struct.unpack_from("<QQ", hdr, o + 16)
        if not (0x100 <= x < len(b1) - 0xD0) or y <= 0 or y >= b2len: continue
        f1, f2 = struct.unpack_from("<II", b1, x + 0x10)
        w, h = struct.unpack_from("<HH", b1, x + 0xC8)
        if f1 != f2 or f1 not in (1, 7, 15, 16) or not w or not h: continue
        span = [c for c in chunks if c[0] == y and c[1] > 0]
        if not span: continue
        end = y + max(c[1] for c in span)
        inside = sorted({(off, sz) for off, sz, t_ in chunks if y < off < end and off + sz <= end})
        if not inside: continue
        # levels: consume chunks in address order, filling mips (largest first) while they fit the chunk
        lv = []; ww, hh = w, h; ci = 0
        levels = []
        while True:
            levels.append((ww, hh, _lvl_size_fmt(f1, ww, hh)))
            if ww == 1 and hh == 1: break
            ww = max(1, ww // 2); hh = max(1, hh // 2)
        li = 0; ok = True
        for off, sz in inside:
            pos = off; used = 0
            while li < len(levels) and used + levels[li][2] <= sz:
                lw, lh, nb = levels[li]
                lv.append((pos, nb, lw, lh)); pos += nb; used += nb; li += 1
            if li >= len(levels): break
        if li < len(levels) and any(l[0] > 1 or l[1] > 1 for l in levels[li:]): ok = False
        res[bytes(hdr[o:o + 4]).hex()] = dict(fmt=f1, w=w, h=h, levels=lv, complete=ok, desc=x, span=(y, end))
    return res


# ---------------- v47: ETC2 decoder (individual / differential / PLANAR; T/H blocks flagged invalid) ----------------
# v46 BUG: the old decoder only knew ETC1 and used uint8 arithmetic. Real ETC2 encoders write PLANAR/T/H blocks on smooth
# skin; those were decoded as garbage (or wrapped) -> wrong base-face colour -> wrong gain -> RED skin.
def _etc2_rgb_blocks(blk):
    """blk (N,8) uint8 -> (px (N,4,4,3) int32 [y,x], valid (N,) bool).  v52: full ETC2 (T/H/planar all decoded, all valid)."""
    px, mode = _E2.decode_rgb(blk)
    return px, np.ones(len(blk), bool)

def _eac_blocks(blk):
    """blk (N,8) uint8 -> (N,4,4) int32 alpha [y,x]"""
    b = blk.astype(np.int64); N = len(b)
    base = b[:, 0]; mul = b[:, 1] >> 4; tab = b[:, 1] & 15
    bits = np.zeros(N, np.int64)
    for i in range(6): bits = (bits << 8) | b[:, 2 + i]
    out = np.zeros((N, 4, 4), np.int32)
    for i in range(16):
        s = (bits >> (45 - 3 * i)) & 7
        out[:, i % 4, i // 4] = np.clip(base + EAC[tab, s] * mul, 0, 255)
    return out

def _etc_decode(raw, off, w, alpha, return_valid=False):
    """decode one ETC2 RGB8 / RGBA8 level (w x w) at raw[off:]"""
    bs = 16 if alpha else 8; nb = (w // 4) ** 2
    blk = np.frombuffer(bytes(raw[off:off + nb * bs]), np.uint8).reshape(nb, bs)
    px, valid = _etc2_rgb_blocks(blk[:, 8:] if alpha else blk)
    img = np.full((w, w, 4), 255, np.uint8); bw = w // 4
    img[..., :3] = px.reshape(w // 4, w // 4, 4, 4, 3).transpose(0, 2, 1, 3, 4).reshape(w, w, 3).astype(np.uint8)
    if alpha:
        al = _eac_blocks(blk[:, :8])
        img[..., 3] = al.reshape(bw, bw, 4, 4).transpose(0, 2, 1, 3).reshape(w, w).astype(np.uint8)
    vm = np.repeat(np.repeat(valid.reshape(bw, bw), 4, 0), 4, 1)
    return (img, vm) if return_valid else img


def _encode_tiny(cur, f, name):
    """v59: 4x4 / 2x2 / 1x1 mip = ONE ETC2 block.  2x2 / 1x1 are tiled into the block exactly like the 2K20 base.  One block cannot hold arbitrary
    colours, so the encoder is re-run with a per-channel MEAN compensation until the decoded mean equals the true downsampled mean
    (otherwise distant LODs / low mips drift in tone).  Only compensates ETC2 quantisation - the source texture is not edited."""
    sz = cur.shape[0]; tgt = cur[..., :3].astype(np.float64); adj = tgt.copy(); best = None
    for _ in range(10):
        a = np.clip(np.round(adj), 0, 255).astype(np.uint8)
        t = np.tile(np.dstack([a, cur[..., 3:4]]), (4 // sz, 4 // sz, 1))
        data = encode_etc2_rgb(t, name) if f == 15 else encode_etc2_rgba(t, name)
        blk = np.frombuffer(data[8:] if f == 16 else data, np.uint8).reshape(-1, 8)
        px, _m = _E2.decode_rgb(blk); dec = px.reshape(1, 1, 4, 4, 3).transpose(0, 2, 1, 3, 4).reshape(4, 4, 3)[:sz, :sz].astype(np.float64)
        err = tgt - dec; sc = (np.abs(err.reshape(-1, 3).mean(0)).max(), np.abs(err).mean())
        if best is None or sc < best[0]: best = (sc, data)
        if sc[0] < 0.5: break
        adj = np.clip(adj + err.reshape(-1, 3).mean(0), 0, 255)
    return best[1]

# v62b: all skin-tone editing REMOVED (no gain, no chroma neutralise).  Textures are written exactly as extracted; only the ETC2 encoder (etcpak) touches them.

def _nextgen(img, name):
    """v65: edits the 2K14 texture before the mips are built.  RGB only - alpha (skin mask / hair opacity) is never changed.
    face_diffuse / hair : light unsharp mask (clean, crisp detail at the slot size).
    hair                : RGB BLEED - colour of transparent pixels is filled from the nearest hair pixel, so Lanczos mips / ETC2 blocks do not pull
                          black or grey into the strands (that is what makes hair turn into shards / dark panels with distance)."""
    if not NEXTGEN or name not in ("face_diffuse", "hair"): return img
    img = img.convert("RGBA"); a = np.asarray(img).copy(); rgb = a[..., :3].astype(np.float32); al = a[..., 3]
    if name == "hair":
        known = al >= 8; col = rgb.copy(); wgt = known.astype(np.float32)
        col *= wgt[..., None]
        for _ in range(24):
            if known.all(): break
            pc = np.pad(col, ((1, 1), (1, 1), (0, 0))); pw = np.pad(wgt, 1); acc = np.zeros_like(col); cnt = np.zeros_like(wgt)
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    if dy == 0 and dx == 0: continue
                    sl = (slice(1 + dy, 1 + dy + col.shape[0]), slice(1 + dx, 1 + dx + col.shape[1]))
                    acc += pc[sl] * pw[sl][..., None] * 1.0; cnt += pw[sl]
            fill = (~known) & (cnt > 0); col[fill] = acc[fill] / cnt[fill][:, None]; wgt[fill] = 1.0; known = known | fill
        rgb = np.where((al >= 8)[..., None], rgb, col)
    k = float(NEXTGEN_SHARP)
    if k > 0:
        im = Image.fromarray(np.clip(rgb + 0.5, 0, 255).astype(np.uint8), "RGB").filter(ImageFilter.UnsharpMask(radius=1.1, percent=int(70 * k), threshold=3))
        sh = np.asarray(im).astype(np.float32)
        if name == "hair": sh = np.where((al >= 8)[..., None], sh, rgb)       # no sharpening halo inside the transparent bleed
        rgb = sh
    a[..., :3] = np.clip(rgb + 0.5, 0, 255).astype(np.uint8)
    return Image.fromarray(a, "RGBA")

# ======================================================================================
# v72  SKIN UNIFY: the body skin (material_map) is moved to the SAME skin tone as the face (face_diffuse), in CIE Lab.
#   Why the old versions never matched: only the face was colour-fixed, material_map was never touched, so the two textures
#   ended up with different skin colour AND brightness (visible seam at the neck / arms vs face).
#   Method: median skin colour (L*, a*, b*) of the face after the face fix = TARGET.  Every skin-like pixel of material_map is shifted
#   by (target - its own median) with a soft, blurred, skin-likeness weight (lips / tattoos / clothes / strong colours get ~0).
#   Shading, pores, tattoos and texture detail stay (it is a SHIFT, not a recolour).  Alpha is never touched.
# ======================================================================================
SKIN_UNIFY = os.environ.get("CF_SKIN_UNIFY", "off").lower()   # "face" body follows the final face skin | "base" body follows the 2K20 base face | "off"
UNIFY_K = float(os.environ.get("CF_UNIFY_K", "1"))              # 0..1  colour (a*, b*) match strength
UNIFY_L = float(os.environ.get("CF_UNIFY_L", "1"))              # 0..1  brightness (L*) match strength
FACE_SKIN_FINAL = [None]                                        # (Lab median of the face skin after the face fix, n pixels)
_RGB2XYZ = np.array([[0.4124564, 0.3575761, 0.1804375], [0.2126729, 0.7151522, 0.0721750], [0.0193339, 0.1191920, 0.9503041]])
_WHITE = np.array([0.95047, 1.0, 1.08883])

def _srgb2lab(rgb):
    c = np.clip(np.asarray(rgb, np.float64) / 255.0, 0, 1)
    lin = np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)
    xyz = (lin @ _RGB2XYZ.T) / _WHITE
    f = np.where(xyz > 216 / 24389, np.cbrt(xyz), (24389 / 27 * xyz + 16) / 116)
    return np.stack([116 * f[..., 1] - 16, 500 * (f[..., 0] - f[..., 1]), 200 * (f[..., 1] - f[..., 2])], -1)

def _lab2srgb(lab):
    fy = (lab[..., 0] + 16) / 116; fx = fy + lab[..., 1] / 500; fz = fy - lab[..., 2] / 200
    def inv(t): return np.where(t ** 3 > 216 / 24389, t ** 3, (116 * t - 16) / (24389 / 27))
    xyz = np.stack([inv(fx), inv(fy), inv(fz)], -1) * _WHITE
    lin = xyz @ np.linalg.inv(_RGB2XYZ).T
    c = np.where(lin <= 0.0031308, lin * 12.92, 1.055 * np.clip(lin, 1e-9, None) ** (1 / 2.4) - 0.055)
    return np.clip(c * 255.0, 0, 255)

def _skin_sel(rgb, alpha=None):
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]; lu = 0.299 * r + 0.587 * g + 0.114 * b
    m = (lu > 40) & (lu < 245) & (r >= g * 0.95) & (g >= b * 0.80) & (r - b > 6)
    if alpha is not None: m &= (alpha >= 250)
    return m

def _skin_median_lab(lab, sel):
    """robust median Lab of the skin pixels (outliers in colour trimmed away: lips, tattoos, scars)"""
    v = lab[sel]
    if len(v) < 400: return None
    med = np.median(v, 0); d = np.hypot(v[:, 1] - med[1], v[:, 2] - med[2]); v = v[d <= np.percentile(d, 80)]
    return np.median(v, 0), int(len(v))

def _face_skin_lab(img, w, use_alpha=True):
    a = np.asarray(_resize(img, w).convert("RGBA"), np.float64)
    return _skin_median_lab(_srgb2lab(a[..., :3]), _skin_sel(a[..., :3], a[..., 3] if use_alpha else None))

def _skin_unify(rgba, target_lab, k_c, k_l):
    """shift the skin of rgba (float64 HxWx4) to target_lab.  returns (new rgba, median before, median after) or None"""
    rgb = rgba[..., :3]; lab = _srgb2lab(rgb); sel = _skin_sel(rgb)             # body map: alpha is NOT a skin mask -> ignored
    got = _skin_median_lab(lab, sel)
    if got is None: return None
    med = got[0]; dl = target_lab - med
    dist = np.hypot(lab[..., 1] - med[1], lab[..., 2] - med[2])
    like = np.clip(1.0 - (dist - 9.0) / 14.0, 0, 1)                             # near the skin colour = 1, lips / strong colours = 0
    lu = rgb @ np.array([0.299, 0.587, 0.114]); like *= ((lu > 25) & (lu < 250))   # pure black / white (seams, masks) untouched
    sig = max(1.0, rgb.shape[0] / 256.0)
    like = np.asarray(Image.fromarray((like * 255).astype(np.uint8), "L").filter(ImageFilter.GaussianBlur(sig)), np.float64) / 255.0   # no hard edges
    new = lab.copy(); new[..., 0] += dl[0] * k_l * like; new[..., 1] += dl[1] * k_c * like; new[..., 2] += dl[2] * k_c * like
    out = rgba.copy(); out[..., :3] = _lab2srgb(new)
    after = _skin_median_lab(_srgb2lab(out[..., :3]), _skin_sel(out[..., :3]))
    return out, med, (after[0] if after else None)


# v75  TINT MATCH (face + body).  The game multiplies the skin area (alpha mask) with its own skin tint on top of the texture, so a 2K14 colour that is
#   already warm/red gets reddened twice.  Here ONLY the chroma (a*, b*) of the skin is moved a fraction TINT_K of the way towards the neutral 2K20
#   base skin; brightness (L*) and all detail / shading / lips / tattoos (soft skin-likeness weight) stay exactly as in 2K14 -> still close to the original.
#   Face and body get the SAME shift, and the body chroma is then pulled TINT_MATCH of the way to the face chroma so both have one skin colour.
TINT_ON = os.environ.get("CF_TINT", "1") != "0"
TINT_K = float(os.environ.get("CF_TINT_K", "0.6"))          # 0 = untouched 2K14 colour .. 1 = chroma of the 2K20 base skin
TINT_MATCH = float(os.environ.get("CF_TINT_MATCH", "1.0"))  # 0 = body keeps own chroma .. 1 = body chroma == face chroma
NATIVE = os.environ.get("CF_NATIVE", "0") == "1"           # v78: exact 2K14 colours, game skin tint off (face alpha 0), no adjustment
OUT_MODE = int(os.environ.get("CF_OUT_MODE", "2"))        # v76: 1 = SD & HD x2 | 2 = SD & HD x4 (1024) | 3 = SD & HD NATIVE (2K14 resolution per texture, never below the template slot)
MAX_TEX = int(os.environ.get("CF_MAX_TEX", "512"))        # v80: largest texture slot written (1024 / native gave an all-black CF in game; 512 + 256 are stable). 0 = no limit
FACE_TO_BODY = os.environ.get("CF_FACE_TO_BODY", "1") != "0"   # v80: face_diffuse skin follows the material_map (body) skin
FACE_K = float(os.environ.get("CF_FACE_K", "1.0")); FACE_L = float(os.environ.get("CF_FACE_L", "1.0"))   # colour / brightness strength
TATTOO_SHARP = float(os.environ.get("CF_TATTOO_SHARP", "0.6"))  # v80: unsharp on the body map when it is shrunk to the slot (keeps tattoo lines crisp)
FACE_GREEN = float(os.environ.get("CF_FACE_GREEN", "2.1"))   # v81: modder tip - green on the face texture (a* shift, x this) so it matches the 2K20 skin; 0 = off
FACE_BRIGHT = float(os.environ.get("CF_FACE_BRIGHT", "2.6"))  # v81: brightness boost by skin lightness (light skin more, dark skin little); 0 = off
FACE_TARGET = os.environ.get("CF_FACE_TARGET", "")   # v86: "L,a,b" = push the face skin median to exactly this Lab (e.g. tan 2K14 look: 38,16,21); "" = auto green/brightness
LOD1_HAIR = os.environ.get("CF_LOD1_HAIR", "1") != "0"; LOD1_EXTRA = {}; LOD1_PORTED = [False]; SLOT_OF = {}; BODY_SKIN = [None]; REPLACE = {}; REPLACE_ALL = {}
MAT_CAP = int(os.environ.get("CF_MAT_CAP", str(MAX_TEX or 1024)))       # v76: the BODY map (tattoos) is never smaller than the 2K14 panel, in SD too (capped here; native mode: 4096)
TINT_L = float(os.environ.get("CF_TINT_L", "0.9"))        # v76: body brightness (L*) -> face brightness, 0 = keep, 1 = equal
HD_FACTOR = {1: 2, 2: 4, 3: 1}.get(OUT_MODE, 4)
TINT_STATE = {"face_orig": None, "face_new": None, "delta": None, "face_L": None}

def _tint_shift(img, w, target_ab, label, target_L=None, k_l=0.0, k_c=1.0):
    """move the skin chroma of PIL image `img` to target_ab (L* kept).  returns (new PIL image, median before, median after) or (img, None, None)"""
    a4 = np.asarray(_resize(img, w).convert("RGBA"), np.float64)
    got = _skin_median_lab(_srgb2lab(a4[..., :3]), _skin_sel(a4[..., :3]))
    if got is None: print("   TINT %s skipped (not enough skin pixels)" % label); return img, None, None
    tgt = np.array([got[0][0] if target_L is None else target_L, target_ab[0], target_ab[1]])
    r = _skin_unify(a4, tgt, k_c, k_l)
    if r is None: return img, None, None
    out, b, a = r
    print("   TINT %s: skin a*b* %s -> %s (target %s)  L* %.1f kept" % (label, np.round(b[1:], 1).tolist(), np.round(a[1:], 1).tolist() if a is not None else "?", np.round(target_ab, 1).tolist(), b[0]) if target_L is None else "   TINT %s: skin L* %.1f -> %.1f, a*b* %s -> %s (target L* %.1f a*b* %s)" % (label, b[0], a[0] if a is not None else -1, np.round(b[1:], 1).tolist(), np.round(a[1:], 1).tolist() if a is not None else "?", target_L, np.round(target_ab, 1).tolist()))
    return Image.fromarray(np.clip(out + 0.5, 0, 255).astype(np.uint8), "RGBA"), b, a

def _face_green(img, w, green=None):
    """v81 (modder tip): add GREEN to the face texture (removes the 2K14 red cast) + brightness depending on the skin:
    light skin = more brightness + a little green, dark skin = little brightness + a little green. Soft skin weight -> lips / eyes / hair edges stay."""
    a = np.asarray(_resize(img, w).convert("RGBA"), np.float64); rgb = a[..., :3]; lab = _srgb2lab(rgb)
    got = _skin_median_lab(lab, _skin_sel(rgb, a[..., 3]))
    if got is None: print("   FACE GREEN skipped (skin not found)"); return img
    med = got[0]; t = float(np.clip((med[0] - 40.0) / 30.0, 0, 1))          # 0 = dark skin .. 1 = light skin
    dL = FACE_BRIGHT * (3.5 + 4.5 * t); da = -(FACE_GREEN if green is None else green) * (4.0 + 2.0 * t)   # L* gain / a* shift (negative a* = greener)
    db = 0.0
    if FACE_TARGET:
        tl, ta, tb = [float(x) for x in FACE_TARGET.split(",")]; dL, da, db = tl - med[0], ta - med[1], tb - med[2]; print("   FACE TARGET L*a*b* %s: shift %+.1f %+.1f %+.1f" % ((tl, ta, tb), dL, da, db))
    dist = np.hypot(lab[..., 1] - med[1], lab[..., 2] - med[2]); like = np.clip(1.0 - (dist - 12.0) / 18.0, 0, 1)
    lu = rgb @ np.array([0.299, 0.587, 0.114]); like *= ((lu > 20) & (lu < 252))
    sig = max(1.0, rgb.shape[0] / 256.0); like = np.asarray(Image.fromarray((like * 255).astype(np.uint8), "L").filter(ImageFilter.GaussianBlur(sig)), np.float64) / 255.0
    new = lab.copy(); new[..., 0] += dL * like; new[..., 1] += da * like; new[..., 2] += (db if FACE_TARGET else -0.5 * da) * like
    out = a.copy(); out[..., :3] = _lab2srgb(new)
    print("   FACE GREEN: skin L* %.1f a* %.1f -> L* +%.1f, a* %+.1f (light-skin factor %.2f)" % (med[0], med[1], dL, da, t))
    return Image.fromarray(np.clip(out + 0.5, 0, 255).astype(np.uint8), "RGBA")

def _tint_face(raw, w):
    base = SKIN_REF[0]
    if base is None: print("   TINT face skipped (no 2K20 base skin reference)"); return raw
    bl = _face_skin_lab(Image.fromarray(np.clip(base, 0, 255).astype(np.uint8), "RGBA" if base.shape[2] == 4 else "RGB"), base.shape[0], base.shape[2] == 4)
    fl = _face_skin_lab(raw, w, True)
    if bl is None or fl is None: print("   TINT face skipped (skin not found)"); return raw
    tgt = fl[0][1:] + TINT_K * (bl[0][1:] - fl[0][1:])
    out, b, a = _tint_shift(raw, w, tgt, "face_diffuse")
    if b is not None: TINT_STATE.update(face_orig=fl[0][1:].copy(), face_new=tgt.copy(), delta=(tgt - fl[0][1:]), face_L=float(fl[0][0]))
    return out

def _tint_body(raw, w):
    st = TINT_STATE
    if st["face_new"] is None: print("   TINT body skipped (no face result)"); return raw
    a4 = np.asarray(_resize(raw, w).convert("RGBA"), np.float64)
    got = _skin_median_lab(_srgb2lab(a4[..., :3]), _skin_sel(a4[..., :3]))
    if got is None: print("   TINT body skipped (not enough skin pixels)"); return raw
    own = got[0][1:] + st["delta"]                                   # same cast removal as the face
    tgt = (1 - TINT_MATCH) * own + TINT_MATCH * st["face_new"]       # then towards the face chroma
    out, b, a = _tint_shift(raw, w, tgt, "material_map (body)", st["face_L"], TINT_L)
    return out

def _unify_material(raw, w, base_target=None):
    """called for material_map; returns the (possibly) corrected PIL image"""
    tgt = None; src = "face"
    if SKIN_UNIFY == "relative" and FACE_SKIN_FINAL[0] is not None and base_target is not None and SKIN_REF_MAT[0] is not None:
        try:
            bm = SKIN_REF_MAT[0]; bm = bm[..., :3]; bl = _skin_median_lab(_srgb2lab(bm), _skin_sel(bm))
            if bl is not None: tgt = FACE_SKIN_FINAL[0][0] + (bl[0] - base_target[0]); src = "face + 2K20 base face->body offset"
        except Exception as e: print("   relative unify failed (%s)" % e)
    if tgt is None and SKIN_UNIFY == "base" and base_target is not None: tgt, src = base_target[0], "2K20 base face"
    if tgt is None and FACE_SKIN_FINAL[0] is not None: tgt = FACE_SKIN_FINAL[0][0]
    if tgt is None: print("   SKIN UNIFY skipped (no face skin target found)"); return raw
    a4 = np.asarray(_resize(raw, w).convert("RGBA"), np.float64)
    r = _skin_unify(a4, tgt, UNIFY_K, UNIFY_L)
    if r is None: print("   SKIN UNIFY skipped (not enough skin-coloured pixels in material_map)"); return raw
    out, b, a = r
    def _rgbs(l): return np.round(_lab2srgb(np.asarray(l)[None, :])[0]).astype(int).tolist()
    print("   SKIN UNIFY (target = %s): face skin L*a*b* %s  | material_map skin BEFORE %s -> AFTER %s   [dL %.1f  dab %.1f -> %.1f]" % (
        src, np.round(tgt, 1).tolist(), np.round(b, 1).tolist(), np.round(a, 1).tolist() if a is not None else "?", abs(tgt[0] - b[0]), np.hypot(tgt[1] - b[1], tgt[2] - b[2]),
        np.hypot(tgt[1] - a[1], tgt[2] - a[2]) if a is not None else -1))
    try:
        if CHECK_DIR:
            sw = Image.new("RGB", (3 * 150, 190), (40, 40, 40)); d = ImageDraw.Draw(sw)
            for i, (lab_, nm) in enumerate(((tgt, "FACE skin (target)"), (b, "BODY before"), (a if a is not None else b, "BODY after"))):
                d.rectangle([i * 150 + 6, 6, i * 150 + 144, 150], fill=tuple(_rgbs(lab_))); d.text((i * 150 + 8, 160), nm, fill=(255, 255, 255))
            sw.save(os.path.join(CHECK_DIR, "skin_unify_check.png"))
    except Exception: pass
    return Image.fromarray(np.clip(out + 0.5, 0, 255).astype(np.uint8), "RGBA")

# ===================== v94: TONE MATCH (material_map + face_diffuse = ONE skin colour, 2K20 base tones) =====================
# The 6 base material maps of 2K20 (light .. dark) are the reference palette: robust skin median Lab of their torso (rows < 72 %, tattoo / ink trimmed).
# own  = the same robust skin median of the 2K14 body map (panel 1, NATIVE resolution)
# ref  = inverse-distance mix of the 3 nearest base tones;  T = own + (TONE_L, TONE_K, TONE_K) * (ref - own)   -> cast removal towards 2K20 skin, the player keeps his lightness
# face_diffuse AND material_map are both shifted so that their skin median == T (2 passes).  Shift weight = soft skin-likeness (colour + lightness near the
# skin median): tattoo ink, lips, hair, brows, black / white seams are ~0 -> HD tattoos stay exactly as drawn.  Alpha is never touched.
TONE_ON = os.environ.get("CF_TONE", "1") != "0"
TONE_K = float(os.environ.get("CF_TONE_K", "0.6"))      # 0 = keep own colour (a*, b*) .. 1 = colour of the nearest 2K20 base tones
TONE_L = float(os.environ.get("CF_TONE_L", "0.0"))      # 0 = keep own lightness .. 1 = lightness of the nearest 2K20 base tones
TONE_FACE_GREEN = float(os.environ.get("CF_TONE_FACE_GREEN", "0.0"))   # v95: green of the game compensation in TONE mode (TONE MATCH already removed the red cast; full 2.1 over-greens).  brightness = FACE_BRIGHT
TONE_ROWS = 0.72                                         # torso part of the body map used for the measurement (below = hands / forearms / sleeves)
TONE_REF_DIR = os.environ.get("CF_TONE_REF", "")
HD_SIZE = int(os.environ.get("CF_HD_SIZE", "0"))         # v94: 0 = off | 1024 / 2048 / 4096 = HD slot size of face_diffuse + material_map
TONE_BASES = [("2k20 base 1 (light)", (70.76, 10.86, 17.83)), ("2k20 base 2 (medium-red)", (41.58, 11.11, 12.89)), ("2k20 base 3 (pale)", (77.94, 4.56, 11.23)),
              ("2k20 base 4 (brown-red)", (36.44, 16.83, 12.69)), ("2k20 base 5 (dark)", (26.22, 4.21, 9.08)), ("2k20 base 6 (tan)", (56.34, 6.45, 7.11))]
TONE_STATE = dict(T=None, own=None, ref=None, face=None, body=None, face_game=None)
_LUMA = np.array([0.299, 0.587, 0.114])

def _skin_stat(rgb, rows=None, alpha=None):
    """robust skin Lab median: skin-coloured pixels, then twice the 80 % closest in (L*/1.5, a*, b*) -> tattoos / lips / shadows / hair trimmed.  (lab median, n) or None"""
    step = max(1, rgb.shape[0] // 512); r = np.asarray(rgb[::step, ::step], np.float64); al = None if alpha is None else np.asarray(alpha[::step, ::step], np.float64)
    sel = _skin_sel(r, al)
    if rows: sel[int(r.shape[0] * rows):] = False
    v = _srgb2lab(r)[sel]
    if len(v) < 400: return None
    for _ in range(2):
        med = np.median(v, 0); d = np.sqrt(((v[:, 0] - med[0]) / 1.5) ** 2 + (v[:, 1] - med[1]) ** 2 + (v[:, 2] - med[2]) ** 2); v = v[d <= np.percentile(d, 80)]
    return np.median(v, 0), int(len(v))

def _tone_refs():
    if TONE_REF_DIR and os.path.isdir(TONE_REF_DIR):
        out = []
        for f in sorted(os.listdir(TONE_REF_DIR)):
            if not f.lower().endswith(".png"): continue
            try:
                a = np.asarray(Image.open(os.path.join(TONE_REF_DIR, f)).convert("RGBA")); g = _skin_stat(a[..., :3], TONE_ROWS)
                if g: out.append((f, tuple(g[0])))
            except Exception as e: print("   tone ref %s skipped (%s)" % (f, e))
        if len(out) >= 2: return out
        print("   --tone-ref: fewer than 2 usable PNGs in %s -> built-in 2K20 tones" % TONE_REF_DIR)
    return TONE_BASES

def _tone_plan(imgs):
    TONE_STATE.update(T=None, own=None, ref=None, face=None, body=None)
    if not TONE_ON or NATIVE: return
    m = imgs.get("material_map")
    if m is None: print("   TONE MATCH skipped (no material_map)"); return
    m = m.convert("RGBA")
    if m.size[0] >= 1.8 * m.size[1]: m = m.crop((0, 0, m.size[0] // 2, m.size[1]))
    got = _skin_stat(np.asarray(m)[..., :3], TONE_ROWS)
    if got is None: print("   TONE MATCH skipped (skin not found in material_map)"); return
    own = got[0]; refs = _tone_refs()
    dist = np.array([np.sqrt(((own[0] - l[0]) / 2.0) ** 2 + (own[1] - l[1]) ** 2 + (own[2] - l[2]) ** 2) for _n, l in refs]); o = np.argsort(dist)[:3]
    w = 1.0 / (dist[o] + 2.0) ** 2; w /= w.sum(); ref = (w[:, None] * np.array([refs[i][1] for i in o])).sum(0)
    T = own + np.array([TONE_L, TONE_K, TONE_K]) * (ref - own)
    TONE_STATE.update(T=T, own=own, ref=ref)
    print("   TONE MATCH: player body skin L*a*b* %s | nearest 2K20 tones %s -> ref %s | TARGET (face = body) %s  [k %.2f / L %.2f]" % (
        np.round(own, 1).tolist(), ", ".join("%s dE %.1f" % (refs[i][0], dist[i]) for i in o), np.round(ref, 1).tolist(), np.round(T, 1).tolist(), TONE_K, TONE_L))

def _tone_shift(img, label, rows=None, use_alpha=False):
    """shift the skin of PIL image `img` (native size) so that its skin median == TONE_STATE['T'].  returns (image, before, after)"""
    T = TONE_STATE["T"]; a = np.array(img.convert("RGBA"), np.uint8); H, W = a.shape[:2]; first = None; after = None
    for it in range(2):
        got = _skin_stat(a[..., :3], rows, a[..., 3] if use_alpha else None)
        if got is None:
            print("   TONE %s skipped (skin not found)" % label); return img, None, None
        med = got[0]; first = med if first is None else first; dl = T - med
        if it == 1 and np.sqrt((dl[0] / 1.5) ** 2 + dl[1] ** 2 + dl[2] ** 2) < 0.6: after = med; break
        like = np.zeros((H, W), np.uint8)
        for y in range(0, H, 256):
            rgb = a[y:y + 256, :, :3].astype(np.float64); lab = _srgb2lab(rgb)
            lk = np.clip(1.0 - (np.hypot(lab[..., 1] - med[1], lab[..., 2] - med[2]) - 9.0) / 14.0, 0, 1) * np.clip(1.0 - (np.abs(lab[..., 0] - med[0]) - 16.0) / 20.0, 0, 1)
            lu = rgb @ _LUMA; lk *= ((lu > 25) & (lu < 250)); like[y:y + 256] = np.round(lk * 255)
        like = np.asarray(Image.fromarray(like, "L").filter(ImageFilter.GaussianBlur(max(1.0, W / 256.0))), np.float32) / 255.0
        for y in range(0, H, 256):
            lab = _srgb2lab(a[y:y + 256, :, :3].astype(np.float64)); lab += like[y:y + 256, :, None] * dl; a[y:y + 256, :, :3] = np.clip(_lab2srgb(lab) + 0.5, 0, 255).astype(np.uint8)
        g2 = _skin_stat(a[..., :3], rows, a[..., 3] if use_alpha else None); after = g2[0] if g2 else None
    print("   TONE %s: skin L*a*b* %s -> %s  (target %s, miss dE %.2f)" % (label, np.round(first, 1).tolist(), np.round(after, 1).tolist() if after is not None else "?", np.round(T, 1).tolist(),
          float(np.sqrt(((after[0] - T[0]) / 1.5) ** 2 + (after[1] - T[1]) ** 2 + (after[2] - T[2]) ** 2)) if after is not None else -1))
    return Image.fromarray(a, "RGBA"), first, after

def _tone_report(outdir):
    st = TONE_STATE
    if st["face"] is None or st["body"] is None: return
    d = st["face"] - st["body"]; de = float(np.sqrt(d[0] ** 2 + d[1] ** 2 + d[2] ** 2))
    print("   TONE CHECK: face skin (before game compensation) %s | body skin %s | dE(face, body) = %.2f %s" % (np.round(st["face"], 1).tolist(), np.round(st["body"], 1).tolist(), de, "OK" if de < 2.5 else "<-- not equal, check skin pixels"))
    fg = st.get("face_game")
    if fg is not None: print("   TONE CHECK: face texture written %s = body %+s  (green / brightness so that the game tint lands the face on the body)" % (np.round(fg, 1).tolist(), np.round(fg - st["body"], 1).tolist()))
    try:
        if outdir:
            sw = Image.new("RGB", (5 * 130, 170), (40, 40, 40)); dr = ImageDraw.Draw(sw)
            for i, (lab_, nm) in enumerate(((st["own"], "player body"), (st["ref"], "2K20 ref"), (st["T"], "TARGET"), (st["face"], "face final"), (st["body"], "body final"))):
                dr.rectangle([i * 130 + 6, 6, i * 130 + 124, 140], fill=tuple(int(x) for x in np.round(_lab2srgb(np.asarray(lab_)[None, :])[0]))); dr.text((i * 130 + 8, 148), nm, fill=(255, 255, 255))
            sw.save(os.path.join(outdir, "skin_tone_check.png"))
    except Exception: pass
# ===================== end v94 TONE MATCH =====================

def write_textures_dd(b1, b2, imgs, hdr):
    """v45: texture list comes from the file's own records/descriptors (every texture, any count, SD or HD);
    placement = per-LOD groups at the end of the data block (this is exactly where D-C writes - verified by diffing a
    D-C edit: LOD0 group = [face, material, normal, detail, hair-mask] ending at the block end).
    ALL mip levels are rewritten (D-C only rewrites LOD0 -> that is why distant LODs looked wrong)."""
    FACE_SKIN_FINAL[0] = None
    tm = tex_map(hdr, b1, len(b2))
    if not tm: raise ValueError("no texture records found in header")
    recs = sorted(tm.items(), key=lambda kv: kv[1]["desc"])            # descriptor order == memory order
    layout = [(t["fmt"], t["w"]) for _, t in recs]
    order, total, offs = _tex_plan(layout, PHYS_END[0] or len(b2), _nch_from_hdr(hdr, len(layout)))
    if total > len(b2): raise ValueError("data block smaller than texture plan")
    print("   texture slots from file: %s" % ", ".join("%s:%d/%d" % (hx[:4], f, w) for (hx, _), (f, w) in zip(recs, layout)))
    # v48: SLOT ROLES ARE DETECTED FROM THE BASE, not from the hash.  2K14: 7ec1 = normal map, e53c = AO/cavity mask.
    # 2K20 base: e53c = the real face NORMAL map (128,128,255), 7ec1 = flat mask.  The old code wrote the grey mask into the
    # 2K20 normal slot (tilted normals -> red/sweaty lighting) and the normal map into the mask slot.
    def _is_normal(ti):
        f, w = layout[ti]
        try:
            if f == 15: m = _etc_decode(b2, offs[(ti, 0)], w, False)[..., :3].reshape(-1, 3).mean(0)
            elif f == 7:
                a = np.frombuffer(bytes(b2[offs[(ti, 0)]:offs[(ti, 0)] + w * w * 2]), np.uint8).reshape(-1, 2).mean(0); m = np.array([a[0], a[1], 255.0])
            else: return None
            return bool(105 < m[0] < 150 and 105 < m[1] < 150 and m[2] > 215)
        except Exception: return None
    want = {"6a482dae": "face_diffuse", "27a62111": "material_map", "51c65d83": "hair"}
    nrm = [(hx, ti) for ti, (hx, _) in enumerate(recs) if hx in ("7ec1fc55", "e53c961f")]
    det = {hx: _is_normal(ti) for hx, ti in nrm}
    for hx, ti in nrm:
        if det[hx] is None: det[hx] = (hx == "e53c961f")                    # observed 2K20 layout
    if len(nrm) == 2 and det["7ec1fc55"] == det["e53c961f"]:                # ambiguous -> observed 2K20 layout
        det = {"7ec1fc55": False, "e53c961f": True}
    for hx, isn in det.items(): want[hx] = "normal_map" if isn else "detail_mask"
    if ROLES[0] is None: ROLES[0] = dict(want)
    else: want = dict(ROLES[0])
    print("   slot roles (detected from base): %s" % ", ".join("%s=%s" % (h[:4], n) for h, n in want.items()))
    if ROLES_ONLY[0]: return bytes(b2)
    # v67: layout check ON THE BASE: the box-filtered LOD0 must equal the written LOD1 (corr ~1.0 when the plan offsets are right).
    # (the header chunk SIZES are 4x the byte sizes - comparing them, as v63 did, always said "NOT IN HEADER": that message was wrong.)
    try:
        def _dn(x): return x.reshape(x.shape[0] // 2, 2, x.shape[1] // 2, 2, 3).mean((1, 3))
        res = []
        for ti_, (f_, w_) in enumerate(layout):
            if f_ not in (15, 16) or w_ < 64: continue
            m0 = np.asarray(_etc_decode(b2, offs[(ti_, 0)], w_, f_ == 16))[..., :3].astype(float); m1 = np.asarray(_etc_decode(b2, offs[(ti_, 1)], w_ // 2, f_ == 16))[..., :3].astype(float)
            a_ = _dn(m0) - _dn(m0).mean(); b_ = m1 - m1.mean(); res.append(float((a_ * b_).sum() / np.sqrt((a_ * a_).sum() * (b_ * b_).sum() + 1e-9)))
        print("   texture layout check (every LOD level lives where the plan says): LOD0->LOD1 correlation %s %s" % (np.round(res, 3).tolist(), "OK" if res and min(res) > 0.9 else "<-- DOES NOT MATCH, mips may be misplaced"))
    except Exception as e: print("   texture layout check skipped (%s)" % e)
    BODY_SKIN[0] = None
    if FACE_TO_BODY and not NATIVE and "material_map" in imgs:
        try:
            _m = imgs["material_map"].convert("RGBA")
            if _m.size[0] >= 1.8 * _m.size[1]: _m = _m.crop((0, 0, _m.size[0] // 2, _m.size[1]))
            _m = np.asarray(_resize(_m, min(512, _m.size[0])), np.float64); _g = _skin_median_lab(_srgb2lab(_m[..., :3]), _skin_sel(_m[..., :3]))
            if _g: BODY_SKIN[0] = _g[0]; print("   BODY skin (material_map) L*a*b* %s -> the face is matched to it" % np.round(_g[0], 1).tolist())
            else: print("   body skin not found in material_map - face keeps the old tint logic")
        except Exception as e: print("   body skin measure failed (%s)" % e)
    _f2b = BODY_SKIN[0] is not None
    _tone_plan(imgs); _tone = TONE_STATE["T"] is not None; TONE_STATE["face"] = None; TONE_STATE["body"] = None
    out = bytearray(b2); _tot = float(sum(t_["w"] ** 2 for h_, t_ in recs if want.get(h_))) or 1.0; PROG["acc"] = 0.0
    for ti, (hx, t) in sorted(enumerate(recs), key=lambda p_: 0 if want.get(p_[1][0]) == "face_diffuse" else 1):      # v72: face first (its final skin = target for the body)
        name = want.get(hx)
        if not name: continue
        f, w = t["fmt"], t["w"]
        raw = imgs[name].convert("RGBA") if name in imgs else Image.new("RGBA", (w, w), (128, 128, 255, 255) if name == "normal_map" else (200, 200, 200, 255))
        if name == "material_map" and raw.size[0] >= 1.8 * raw.size[1]:
            raw = raw.crop((0, 0, raw.size[0] // 2, raw.size[1]))           # 2K14 map = 2 panels; panel 1 matches the 2K20 layout (corr 0.53 vs ~0.0)
            print("   material_map: 2-panel 2K14 map -> left panel used (not stretched)")
        # v64: SKIN CAST REMOVAL.  The earlier "skin-tone match" only changed brightness and limited tint to +-6 %, so the red CAST of the 2K14 diffuse
        # was never touched (that is why removing it changed nothing).  The 2K20 base face is a neutral beige and the game tints the skin area (alpha = mask)
        # again, so a baked-in 2K14 tint is counted twice = red.  Here the MEDIAN skin colour of the CF is moved to the median skin colour of the base
        # with ONE global per-channel gain, then every pixel keeps its own luminance.  Detail, shading and freckles stay; lips (more saturated) and
        # hair / openings (low alpha) are left alone.  FACE_NEUTRAL = 0 turns it off.
        _mode = os.environ.get("CF_SKIN_MODE", FACE_SKIN_MODE).lower(); k_neu = SKIN_K if _mode in ("chroma", "match") else 0.0
        if name == "face_diffuse" and _mode == "alpha0":
            _r, _g, _b, _a = raw.convert("RGBA").split(); raw = Image.merge("RGBA", (_r, _g, _b, Image.new("L", raw.size, 0))); print("   face_diffuse: alpha set to 0 (colour untouched)")
        if name == "face_diffuse" and f == 16:          # v67: material_map = BODY skin (arms / torso) - it was still the red 2K14 colour
            try:
                tp = (SKIN_REF[0] if SKIN_REF[0] is not None else np.asarray(_etc_decode(b2, offs[(ti, 0)], w, f == 16), np.float64)); a4 = np.asarray(_resize(raw, w).convert("RGBA"), np.float64)
                if tp.shape[2] == 3: tp = np.concatenate([tp, np.full(tp.shape[:2] + (1,), 255.0)], 2)
                def _smask(x):
                    r, g, bl = x[..., 0], x[..., 1], x[..., 2]; lu = 0.299 * r + 0.587 * g + 0.114 * bl
                    m = (x[..., 3] >= 250) & (lu > 45) & (lu < 240) & (r >= g * 0.95) & (g >= bl * 0.85) & (r - bl > 8)
                    if m.sum() > 400:
                        sat = (r - bl) / np.maximum(r, 1.0); lo, hi = np.percentile(sat[m], [10, 90]); m &= (sat >= lo) & (sat <= hi)
                    return m
                mt_, mc_ = _smask(tp), _smask(a4)
                if mt_.sum() < 400 or mc_.sum() < 400: print("   skin cast removal skipped (not enough skin pixels)")
                else:
                    mt, mc = np.median(tp[..., :3][mt_], 0), np.median(a4[..., :3][mc_], 0)
                    print("   SKIN CHECK %s: CF skin median RGB %s (R/G %.3f B/G %.3f) | base skin %s (R/G %.3f B/G %.3f)" % (name, np.round(mc), mc[0] / mc[1], mc[2] / mc[1], np.round(mt), mt[0] / mt[1], mt[2] / mt[1]))
                    if k_neu > 0:
                        Yw = np.array([0.299, 0.587, 0.114]); rc = mc / (mc @ Yw); rt = mt / (mt @ Yw); gain = np.clip(rt / rc, 0.6, 1.5)
                        rgb = a4[..., :3]; Y = rgb @ Yw; mx = rgb.max(2); sat = (mx - rgb.min(2)) / np.maximum(mx, 1.0)
                        s0 = float(np.median(sat[mc_])); like = np.clip(1.0 - (sat - 1.3 * s0) / (0.7 * s0 + 1e-6), 0, 1)       # lips / strong colours -> 0
                        wgt = (k_neu * a4[..., 3] / 255.0 * like)[..., None]
                        new = rgb * gain; new *= (Y / np.maximum(new @ Yw, 1e-3))[..., None]
                        if _mode == "match": new = np.clip(new * float((mt @ Yw) / (mc @ Yw)), 0, 255)         # brightness of the base skin too (the game tints on top)
                        a4[..., :3] = np.clip((1 - wgt) * rgb + wgt * new, 0, 255)
                        mc2 = np.median(a4[..., :3][mc_], 0)
                        print("   %s: skin cast removed (strength %.2f): gain RGB %s -> CF skin now %s (R/G %.3f B/G %.3f)" % (name, k_neu, np.round(gain, 3), np.round(mc2), mc2[0] / mc2[1], mc2[2] / mc2[1]))
                        raw = Image.fromarray(np.clip(a4 + 0.5, 0, 255).astype(np.uint8), "RGBA")
            except Exception as e: print("   skin step skipped (%s)" % e)
        if name == "face_diffuse" and _tone:                       # v94: face skin == body skin == TARGET (native resolution, before any resize)
            try:
                _r = _tone_shift(raw, "face_diffuse", None, True)
                if _r[1] is not None: raw = _r[0]; TONE_STATE["face"] = _r[2]
            except Exception as e: print("   TONE face failed (%s) - left as it was" % e)
        elif name == "face_diffuse" and _f2b:
            try:
                _r = _tint_shift(raw, w, BODY_SKIN[0][1:], "face_diffuse -> body skin", float(BODY_SKIN[0][0]), FACE_L, FACE_K)
                if _r[1] is not None: raw = _r[0]
            except Exception as e: print("   face -> body match failed (%s) - left as it was" % e)
        elif name == "face_diffuse" and TINT_ON:
            try: raw = _tint_face(raw, w)
            except Exception as e: print("   TINT face failed (%s) - left as it was" % e)
        if name == "face_diffuse" and (FACE_GREEN > 0 or FACE_BRIGHT > 0) and not NATIVE:
            try: raw = _face_green(raw, w, TONE_FACE_GREEN if _tone else None)
            except Exception as e: print("   FACE GREEN failed (%s) - left as it was" % e)
        if name == "face_diffuse":                                  # v72: remember the final face skin colour
            try:
                FACE_SKIN_FINAL[0] = _face_skin_lab(raw, w, True)
                if _tone and FACE_SKIN_FINAL[0]: TONE_STATE["face_game"] = FACE_SKIN_FINAL[0][0]
                if FACE_SKIN_FINAL[0]: print("   face skin (final) L*a*b* %s  [%d px]" % (np.round(FACE_SKIN_FINAL[0][0], 1).tolist(), FACE_SKIN_FINAL[0][1]))
            except Exception as e: print("   face skin measure skipped (%s)" % e)
        elif name == "material_map" and _tone:                    # v94: body skin -> TARGET at the native size of the 2K14 map (HD tattoos untouched)
            try:
                _r = _tone_shift(raw, "material_map (body)", TONE_ROWS, False)
                if _r[1] is not None: raw = _r[0]; TONE_STATE["body"] = _r[2]
            except Exception as e: print("   TONE body failed (%s) - left as it was" % e)
        elif name == "material_map" and TINT_ON and not _f2b:
            try: raw = _tint_body(raw, w)
            except Exception as e: print("   TINT body failed (%s) - left as it was" % e)
        elif name == "material_map" and SKIN_UNIFY != "off":        # v72: body skin -> same tone as the face
            try:
                _bt = _face_skin_lab(Image.fromarray(np.clip(SKIN_REF[0], 0, 255).astype(np.uint8), "RGBA" if SKIN_REF[0].shape[2] == 4 else "RGB"), SKIN_REF[0].shape[0], SKIN_REF[0].shape[2] == 4) if SKIN_REF[0] is not None else None
                raw = _unify_material(raw, w, _bt)
            except Exception as e: print("   SKIN UNIFY failed (%s) - material_map left as it was" % e)
        _rs = _resize(raw, w)
        if name == "material_map" and TATTOO_SHARP > 0:
            try:
                _p = _rs.convert("RGBA").split(); _c = Image.merge("RGB", _p[:3]).filter(ImageFilter.UnsharpMask(radius=1.2, percent=int(120 * TATTOO_SHARP), threshold=3)); _c.putalpha(_p[3]); _rs = _c
                print("   material_map: HD tattoo sharpen %.2f" % TATTOO_SHARP)
            except Exception as e: print("   tattoo sharpen skipped (%s)" % e)
        src = _nextgen(_rs, name)
        try:
            if CHECK_DIR and name in ("face_diffuse", "hair", "material_map"): src.convert("RGBA").save(os.path.join(CHECK_DIR, "nextgen_%s.png" % name))
        except Exception: pass
        nlev = 0
        for (tt, k), off in offs.items():
            if tt != ti: continue
            sz = w >> k
            cur = np.asarray(_resize(src, sz)).astype(np.uint8)
            if f == 7: data = cur[..., :2].tobytes()
            elif f == 1: data = cur.tobytes()
            else:
                data = _encode_tiny(cur, f, name) if sz <= 4 else (encode_etc2_rgb(cur, name) if f == 15 else encode_etc2_rgba(cur, name))
            nb = _lvl_bytes(f, sz)
            if len(data) != nb: raise ValueError("%s level %d: %d != %d bytes" % (name, sz, len(data), nb))
            out[off:off + nb] = data; nlev += 1
            if k > 0 and sz >= 4 and f in (15, 16):          # v63: EVERY mip level is decoded back from the written bytes and compared to the intended image
                try:
                    blk2 = np.frombuffer(bytes(out[off:off + nb]), np.uint8).reshape(-1, 16 if f == 16 else 8)
                    px2, _m2 = _E2.decode_rgb(blk2[:, 8:] if f == 16 else blk2)
                    d2 = px2.reshape(sz // 4, sz // 4, 4, 4, 3).transpose(0, 2, 1, 3, 4).reshape(sz, sz, 3).astype(np.float64); r2 = cur[..., :3].astype(np.float64)
                    mse2 = max(((d2 - r2) ** 2).mean(), 1e-9); dm = d2.reshape(-1, 3).mean(0) - r2.reshape(-1, 3).mean(0)
                    print("   %s mip%d %4dpx @0x%x: PSNR %.1f dB | mean RGB intended %s decoded %s%s" % (name, k, sz, off, 10 * np.log10(255 ** 2 / mse2), np.round(r2.reshape(-1, 3).mean(0)).astype(int), np.round(d2.reshape(-1, 3).mean(0)).astype(int), "  <-- TONE SHIFT" if np.abs(dm).max() > 4 else ""))
                except Exception as e: print("   %s mip%d check skipped (%s)" % (name, k, e))
            if k == 0 and f in (15, 16):                      # v50 SELF-CHECK: decode what was just written, compare to the intended image
                try:
                    blk = np.frombuffer(data, np.uint8).reshape(-1, 16 if f == 16 else 8)
                    pxd, md = _E2.decode_rgb(blk[:, 8:] if f == 16 else blk)
                    dec = pxd.reshape(sz // 4, sz // 4, 4, 4, 3).transpose(0, 2, 1, 3, 4).reshape(sz, sz, 3).astype(np.float64)
                    ref = cur[..., :3].astype(np.float64)
                    mse = max(((dec - ref) ** 2).mean(), 1e-9)
                    bad = (np.abs(dec - ref).mean(2).reshape(sz // 4, 4, sz // 4, 4).mean((1, 3)) > 24).sum()
                    mc = np.bincount(md, minlength=5)
                    nchk, nbad = _spec_check(blk[:, 8:] if f == 16 else blk)
                    print("   %s ETC2 spec check: %d/%d blocks identical to the independent spec decoder%s" % (name, nchk - nbad, nchk, "" if not nbad else "  <-- MISMATCH, report this"))
                    print("   %s self-check: PSNR %.2f dB | blocks ind/diff/T/H/planar = %s | bad blocks (>24 err): %d" % (name, 10 * np.log10(255 ** 2 / mse), "/".join(str(int(x)) for x in mc), bad))
                    if ETC2_ONLY: print("   %s ETC1-style blocks (individual/differential): %d %s" % (name, int(mc[0] + mc[1]), "OK - ETC2 only" if mc[0] + mc[1] == 0 else "<-- should be 0"))
                    Image.fromarray(dec.astype(np.uint8)).save(os.path.join(CHECK_DIR, "check_%s_decoded.png" % name)) if CHECK_DIR else None
                except Exception as e:
                    print("   %s self-check skipped (%s)" % (name, e))
        print("   %s: fmt %d %dx%d -> %d levels, LOD0 at 0x%x" % (name, f, w, w, nlev, offs[(ti, 0)]))
        PROG["acc"] += w * w / _tot; _progress(PROG["lo"] + (PROG["hi"] - PROG["lo"]) * min(PROG["acc"], 1.0), "%s  %s %dpx" % (PROG["tag"], name, w))
    if _tone: _tone_report(globals().get("CHECK_DIR"))
    return out

# --------------------------- IFF -> IFF mesh port --------------------------

def _decompress_zlib_payload(data, un=None):
    """Tolerate bad Adler32 checksum (RED-edited IFFs)."""
    try:
        return zlib.decompress(data)
    except zlib.error:
        pass
    if len(data) >= 3:
        try:
            return zlib.decompress(data[2:], -15)
        except zlib.error:
            pass
    raise zlib.error("decompress failed")

def read_iff(path):
    d = open(path, "rb").read()
    hs = struct.unpack("<I", d[4:8])[0]
    if hs > 0 and hs < len(d) and d[hs:hs+4] != b"ZLIB":
        rb, p = _raw_iff_blocks(d, hs)
        if rb:                                                    # v79: uncompressed IFF
            blocks = [dict(un=u, co=u, fl=0, raw=b) for b, u in rb]
            return dict(hdr=bytearray(d[:hs]), hs=hs, blocks=blocks, tail=d[p:], size=len(d), raw_container=True)
    if hs <= 0 or hs >= len(d) or d[hs:hs+4] != b"ZLIB":
        sys.exit("not a readable IFF for mesh port (no ZLIB and no raw block table at hs=%s)" % hs)
    blocks, p = [], hs
    while p + 16 <= len(d) and d[p:p + 4] == b"ZLIB":
        un, co, fl = struct.unpack(">III", d[p + 4:p + 16])
        payload = d[p + 16:p + co] if p + co <= len(d) else d[p + 16:]
        try:
            raw = _decompress_zlib_payload(payload, un)
        except zlib.error as e:
            sys.exit("ZLIB failed at %d (%s)" % (p, e))
        if un and len(raw) > un:
            raw = raw[:un]
        blocks.append(dict(un=len(raw) if not un else un, co=co, fl=fl, raw=raw[:un] if un else raw))
        # keep declared un for write_iff size match
        blocks[-1]["un"] = un if un else len(blocks[-1]["raw"])
        if len(blocks[-1]["raw"]) < blocks[-1]["un"]:
            # pad if short (should not happen often)
            blocks[-1]["raw"] = blocks[-1]["raw"] + b"\x00" * (blocks[-1]["un"] - len(blocks[-1]["raw"]))
        p += co
    return dict(hdr=bytearray(d[:hs]), hs=hs, blocks=blocks, tail=d[p:], size=len(d))


def find_all_streams(raw, minrun=400):
    found = []
    for par in range(0, 8, 2):
        m = (len(raw) - par) // 8
        if m < minrun: continue
        arr = np.frombuffer(raw[par:par + m * 8], "<i2").reshape(m, 4)
        ok = np.abs(arr[:, 3]) == 32767
        i = 0
        while i < m:
            if ok[i]:
                j = i
                while j < m and ok[j]: j += 1
                if j - i >= minrun:
                    found.append((par + i * 8, j - i))
                i = j
            else:
                i += 1
    seen, uniq = set(), []
    for off, n in sorted(found, key=lambda x: -x[1]):
        if off not in seen:
            seen.add(off); uniq.append((off, n))
    return uniq

def get_pos(raw, off, n):
    return np.frombuffer(raw[off:off + 8 * n], "<i2").reshape(n, 4)[:, :3].astype(np.float64) * 0.001

def set_pos(raw, off, P):
    arr = np.frombuffer(bytes(raw[off:off + 8 * len(P)]), "<i2").reshape(len(P), 4).copy()
    if not np.isfinite(P).all(): raise ValueError('NaN/inf vertex positions - refusing to write a broken mesh')
    if (np.abs(P) / 0.001 > 32767).any(): print('   WARNING: vertices outside int16 range are clipped')
    arr[:, :3] = np.clip(np.round(P / 0.001), -32767, 32767).astype(np.int16)
    out = bytearray(raw); out[off:off + 8 * len(P)] = arr.tobytes(); return out

def write_iff(iff, newblocks, path):
    """newblocks: list of raw bytes. A block may now change size (HD upgrade); header sizes are patched."""
    hdr = bytearray(iff["hdr"]); hs = iff["hs"]
    olds, news = [], []
    p_old = p_new = hs; body = b""
    for b, raw in zip(iff["blocks"], newblocks):
        un = len(raw)
        if un != b["un"]:
            done = False
            for fmt in ("<Q", "<I"):
                pat = struct.pack(fmt, b["un"])
                if bytes(hdr).count(pat) == 1:
                    i = bytes(hdr).index(pat); hdr[i:i + len(pat)] = struct.pack(fmt, un); done = True; break
            print("   block size %d -> %d  (header field %s)" % (b["un"], un, "patched" if done else "NOT FOUND - game may reject"))
        c = zlib.compressobj(9); z = c.compress(raw) + c.flush()
        co = len(z) + 16
        olds.append((b["co"], p_old)); news.append((co, p_new))
        body += b"ZLIB" + struct.pack(">III", un, co, b["fl"]) + z
        p_old += b["co"]; p_new += co
    for (oc, op), (nc, np_) in zip(olds, news):
        for ov, nv in ((oc, nc), (op, np_)):
            if ov == nv: continue
            pat = struct.pack("<Q", ov); cnt = bytes(hdr).count(pat)
            if cnt != 1: raise RuntimeError("header field %x found %d times" % (ov, cnt))
            i = bytes(hdr).index(pat); hdr[i:i + 8] = struct.pack("<Q", nv)
    out = bytes(hdr) + body + iff["tail"]
    out = bytearray(out); old = struct.unpack(">I", bytes(iff["hdr"][8:12]))[0]
    if old == iff["size"] - len(iff["tail"]) or old == iff["size"]:
        out[8:12] = struct.pack(">I", len(out))
    open(path, "wb").write(bytes(out))



def _lvl_bytes(f, s):
    if f == 7: return s * s * 2
    if f == 1: return s * s * 4
    return max(1, s // 4) ** 2 * (16 if f == 16 else 8)

def _nch_from_hdr(hdr, n):
    """number of LOD chunks (types 0x80,0x81,0x82) per texture, read from the header chunk table: textures that own a 0x82 chunk come first.
    2K20 CF: face/material/normal = 3 (LOD0,LOD1,LOD2) + tail 0x9f, detail/hair = 2 (LOD0,LOD1) + tail 0x9f."""
    n82 = 0; o = 0x108
    while o + 8 <= len(hdr) and (struct.unpack_from("<Q", hdr, o)[0] & 0xff) == 0x82: n82 += 1; o += 16
    return [3 if i < n82 else 2 for i in range(n)]

def _tex_plan(layout, b2len, nch=None):
    """physical memory plan (verified on base_SD, modder SD and modder HD): [tails of every texture][LOD2 group][LOD1 group][LOD0 group], ending at b2len.
    LOD chunk k < nch[tex] goes to group k, every smaller mip is the tail."""
    tails, groups = [], {}
    for ti, (f, w) in enumerate(layout):
        tail = []; k = 0
        while (w >> k) >= 1:
            if (nch[ti] if nch else None) is not None:
                if k < nch[ti]: groups.setdefault(k, []).append((ti, k))
                else: tail.append((ti, k))
            else:
                if (w >> k) >= 64: groups.setdefault(k, []).append((ti, k))
                else: tail.append((ti, k))
            k += 1
        tails.append(tail)
    order = [x for t in tails for x in t] + [x for k in sorted(groups, reverse=True) for x in groups[k]]
    total = sum(_lvl_bytes(layout[ti][0], layout[ti][1] >> k) for ti, k in order)
    pos = b2len - total; offs = {}
    for ti, k in order:
        offs[(ti, k)] = pos; pos += _lvl_bytes(layout[ti][0], layout[ti][1] >> k)
    return order, total, offs

def _umeyama(src, dst):
    """Best rotation + uniform scale + translation (NO shear / non-uniform stretch),
    so the real 2K14 head proportions survive the move into 2K20 space."""
    mu_s, mu_d = src.mean(0), dst.mean(0)
    A, B = src - mu_s, dst - mu_d
    U, D, Vt = np.linalg.svd(B.T @ A / len(src))
    S = np.eye(3)
    if np.linalg.det(U) * np.linalg.det(Vt) < 0: S[2, 2] = -1
    R = U @ S @ Vt
    sc = float(np.trace(np.diag(D) @ S) / ((A ** 2).sum() / len(src)))
    return sc, R, mu_s, mu_d

















# ===================== v51: FULL 2K14 HAIR MESH INJECTION =====================
# 2K20 IFF layout (reverse engineered):
#   block0 : int16x4 position stream (stride 8, n verts)               [tool already handles]
#   block1 : [0 .. idx_end) u16 TRIANGLE STRIP (degenerate joins)  -> face strips first, HAIR strips = contiguous tail
#            [idx_end ..)   n x 28-byte vertex records:
#                 0..7  normal  snorm16 xyz,0     8..15 tangent snorm16 xyz,0
#                16..19 uv      u16 x2  (u = u14*32768, v = (1-v14)*32768)
#                20..23 bone idx u8x4            24..27 bone weight u8x4
# The hair strip tail + hair vertex slots are overwritten IN PLACE with the real 2K14 hair (counts never grow, so no pointer fix-ups).




# ===================== end v51 =====================

# ===================== v52: NATIVE HEAD + HAIR UV TRANSFER =====================
# The 2K14 head is ported with its EXACT shape, so the 2K14 textures (face / material / normal / detail / hair) must be read with
# the 2K14 UV layout.  v51 kept the template's 2K20 UVs for the head (only 82% of the vertices share a UV with 2K14) and only the hair
# got 2K14 UVs.  Now the head's UV + normal + tangent are transferred from the 2K14 surface as well:
#   1. every 2K20 head vertex is projected onto the 2K14 head surface (in the fitted 2K20 space) -> candidate UVs of all 2K14
#      triangles touching that point (a point on a UV seam has one candidate per side);
#   2. vertices whose index partner sits exactly there keep that partner's own UV; all others are free;
#   3. a seam-aware optimiser picks one candidate per vertex so the 2K20 triangles are not smeared across a 2K14 seam
#      (stretched triangles: template 343 / plain index copy 524 / nearest surface 1141 / this 380 on PCF).
# Records: 28-byte per vertex after the strip (normal 0..7, tangent 8..15, uv 16..19), same layout in 2K14 and 2K20.


CAND_TOL=float(os.environ.get('CF_UV_CAND_TOL','0.0'))


SEAM_WCOL = float(os.environ.get("CF_SEAM_WCOL", "1.0"))     # weight of the texel-colour match when a seam candidate is chosen
SEAM_WPREF = float(os.environ.get("CF_SEAM_WPREF", "0.30"))   # 0 = free seam choice, large = stick to the index partner's UV

# ===================== end v52 UV =====================

# ===================== v55: LOD MESHES FOLLOW LOD0 (beard / eyes / ears / hair) =====================
# ROOT CAUSE of the broken LODs: only LOD0 got the native UV / normals / tangents / eye / ear / hair work.  The secondary head streams
# only got positions (and by VERTEX INDEX, which is not valid for a decimated mesh) -> their template 2K20 UVs sampled the 2K14-layout texture
# = wrong beard, eyes, ears and hair as soon as the game switches LOD (the edit-player screen often shows LOD1).
# Now every LOD vertex is matched to LOD0 by (template position + template UV) - the same vertex/seam side - and receives the LOD0 result:
# displacement (IDW over the 4 best matches), UV, normal, tangent.  Beard, eyes (rigid, template UV), ears and hair therefore agree with LOD0.


# ===================== end v55 LOD =====================










# -------------------------------- OBJ port --------------------------------








# ------------------------------- interactive ------------------------------



# ------------------------------- v42: BATCH -------------------------------










# ===================== v59: 1:1 MESH PORT =====================
# The 2K14 head mesh (face verts 0..2076 + hair/beard/accessory verts 2077..n14-1) is copied AS IT IS into the 2K20 container:
#   * vertex slot i  <-  2K14 vertex i  (position fitted into the 2K20 frame, normal/tangent rotated, UV + bone idx/weights verbatim)
#   * index buffer   <-  the 2K14 strips verbatim (padded with degenerate repeats up to the template's fixed length)
#   * LOD table      <-  the 2K14 progressive-mesh table (per-LOD index / vertex cutoffs, matched by hash)
# Nothing is projected, filtered, clustered, smoothed or re-UV'd.  Only the neck ring is blended to the 2K20 template so it meets the 2K20 body.
def _trimmed_fit(A, B, keep=0.8, rounds=3):
    sel = np.arange(len(A))
    for _ in range(rounds):
        sc, R, mu_s, mu_d = _umeyama(A[sel], B[sel])
        F = sc * (A - mu_s) @ R.T + mu_d; e = np.linalg.norm(F - B, axis=1)
        sel = np.argsort(e)[:int(len(A) * keep)]
    if abs(sc - 1.0) < 0.08: sc = 1.0; sc_, R, mu_s, mu_d = 1.0, R, A[sel].mean(0), B[sel].mean(0)
    return sc, R, mu_s, mu_d

def _lod_entries(b0, new_layout):
    """progressive-mesh table entries: [(byte_offset_of_N, hash)].  2K14: [hash,0,5,N,d1,d2,0,V,d3]   2K20: [hash,0,0,0,5,N,d1,d2,0,V,d3]"""
    a = np.frombuffer(bytes(b0[:len(b0) // 4 * 4]), "<u4"); out = []
    for i in range(4, len(a) - 8):
        if new_layout:
            ok = a[i - 1] == 5 and a[i + 3] == 0 and 3000 < a[i] < 20000 and 1000 < a[i + 4] < 8000 and a[i - 2] == 0 and a[i - 3] == 0 and a[i - 4] == 0 and a[i - 5] != 0
            h = a[i - 5] if ok else None
        else:
            ok = a[i - 1] == 5 and a[i + 3] == 0 and 3000 < a[i] < 20000 and 1000 < a[i + 4] < 8000 and a[i - 2] == 0
            h = a[i - 3] if ok else None
        if ok and h: out.append((i * 4, int(h), [int(x) for x in a[i:i + 6]]))
    return out

def _draw_entries(b0, n_vert, n_idx, both=False):
    """v62: ALL draw-call records of the table [.., 5, firstIdx, idxCount, idxCount-2, 0, firstVert, vertCount, ..] (incl. the skin and the first
    part, whose start index / start vertex are small -> the old `3000 < N` filter skipped them and left the TEMPLATE ranges in the file).
    -> [(byte_off_of_firstIdx, [firstIdx, idxCount, idxCount-2, 0, firstVert, vertCount])] in file order"""
    a = np.frombuffer(bytes(b0[:len(b0) // 4 * 4]), "<u4").astype(np.int64); out = []
    for i in range(4, len(a) - 8):
        if a[i - 1] == 5 and a[i + 1] > 2 and a[i + 2] == a[i + 1] - 2 and a[i + 3] == 0 and a[i] + a[i + 1] <= n_idx and a[i + 4] + a[i + 5] <= n_vert and a[i + 5] > 0:
            if not both and out and int(a[i]) < out[-1][1][0]: break          # second table (starts at index 0 again = other mesh): leave untouched
            out.append((i * 4, [int(x) for x in a[i:i + 6]]))
    return out

def _split_lod_groups(ents):
    groups = []
    for e in ents:
        if not groups or e[1][0] < groups[-1][-1][1][0]: groups.append([])
        groups[-1].append(e)
    return groups

def _entry_hash(b0, off):
    a = np.frombuffer(bytes(b0[:len(b0) // 4 * 4]), "<u4"); i = off // 4
    if i >= 5 and a[i - 2] == 0 and a[i - 3] == 0 and a[i - 4] == 0 and a[i - 5] != 0: return int(a[i - 5])      # 2K20 record
    if i >= 3 and a[i - 2] == 0 and a[i - 3] != 0: return int(a[i - 3])                                      # 2K14 record
    return None

def _patch_lod_groups(b0, b0_14, n14, nidx14, n20, L20):
    b0 = bytearray(b0); all_groups = os.environ.get("CF_PATCH_T2", PATCH_ALL_LOD) != "0"; SLOT_OF.clear()
    g14 = _split_lod_groups(_draw_entries(b0_14, n14, nidx14, True)); g20 = _split_lod_groups(_draw_entries(bytes(b0), n20, L20, True))
    n14e = sum(len(g) for g in g14); n20e = sum(len(g) for g in g20); n_ok = 0
    print("   LOD table: 2K14 has %d group(s) %s | 2K20 has %d group(s) %s" % (len(g14), [len(g) for g in g14], len(g20), [len(g) for g in g20]))
    if not g14 or not g20: print("   WARNING: draw table not found - LOD ranges NOT patched"); return bytes(b0), 0, n14e, n20e
    pad = L20 - nidx14                                                       # degenerate padding at the end of the index buffer (draws nothing)
    for j, dst in enumerate(g20):
        if j > 0 and not all_groups: break
        if j > 0 and (not LOD1_PORTED[0] or BIG_STATE.get('lod1')):                                     # v88: the 2K14 LOD1 ranges only make sense together with its LOD1 buffers; not ported -> keep the template's LOD1 table
            print("   LOD group %d: 2K14 LOD1 buffers not ported -> template LOD1 draw table kept" % j); continue
        src = g14[min(j, len(g14) - 1)]
        if len(src) == len(dst): pairs = list(zip(dst, src)); lost = []
        else:                                                                # different part count: match by hash, the rest is made invisible
            h14 = {}
            for e in src:
                h = _entry_hash(b0_14, e[0])
                if h is not None and h not in h14: h14[h] = e
            pairs, lost = [], []
            for k, d in enumerate(dst):
                h = _entry_hash(bytes(b0), d[0]); m = h14.get(h) if h is not None else (src[k] if k < len(src) else None)
                (pairs if m is not None else lost).append((d, m) if m is not None else d)
            used = {id(m) for _d, m in pairs}; extra = [e for e in src if id(e) not in used]      # v79 HEADBAND: 2K14 parts (headband / band / goggles) with no hash match used to be DROPPED
            for e in sorted(extra, key=lambda e: -e[1][1]):
                if not lost: break
                k_ = min(range(len(lost)), key=lambda q: abs(lost[q][1][5] - e[1][5])); pairs.append((lost.pop(k_), e))
            print("   LOD group %d: part count differs (2K14 %d / 2K20 %d) -> matched %d by hash/position, %d hidden, %d extra 2K14 part(s) %s" % (j, len(src), len(dst), len(pairs), len(lost), len(extra), "placed in free slots" if len(extra) else ""))
        if j == 0:                                                           # v87: remember the slot every 2K14 part took in LOD0 (headband etc.) -> LOD1 uses the same slot
            _ix = {id(d_): k_ for k_, d_ in enumerate(dst)}
            for d_, e_ in pairs:
                h_ = _entry_hash(b0_14, e_[0])
                if h_ is not None and id(d_) in _ix: SLOT_OF.setdefault(h_, _ix[id(d_)])
        for (off, old), (o14_, new) in pairs:
            b0[off:off + 24] = struct.pack("<6I", *new); n_ok += 1
        if LOD1_EXTRA and j >= 1 and min(j, len(g14) - 1) >= 1:
            # v87: rebuilt LOD1 parts (hair, HEADBAND ...) -> free draw slots.  Before, only slots whose TEMPLATE hash equalled the 2K14 hash were used, so a headband
            # (hash not in the template) never got a slot and vanished in LOD1.  Order: 1) same slot as in LOD0  2) same hash  3) any other free slot
            lost_d = dict(lost); todo = dict(LOD1_EXTRA)
            def _put(off_, h_, how_):
                b0[off_:off_ + 24] = struct.pack("<6I", *todo[h_]); lost_d.pop(off_, None); todo.pop(h_); print("   LOD group %d: part %08x -> rebuilt LOD1 part (%s)" % (j, h_, how_))
            n0_ = len(todo)
            for h_ in list(todo):
                k_ = SLOT_OF.get(h_)
                if k_ is not None and k_ < len(dst) and dst[k_][0] in lost_d: _put(dst[k_][0], h_, "same slot as LOD0")
            for off_ in list(lost_d):
                h_ = _entry_hash(bytes(b0), off_)
                if h_ in todo: _put(off_, h_, "same hash")
            for h_ in sorted(todo, key=lambda q: -todo[q][1]):
                if not lost_d: break
                _put(max(lost_d, key=lambda q: lost_d[q][5]), h_, "free slot")
            if todo: print("   WARNING: LOD group %d: no free draw slot for %d rebuilt part(s) %s - they stay invisible in LOD1" % (j, len(todo), ", ".join("%08x" % q for q in todo)))
            n_ok += n0_ - len(todo); lost = list(lost_d.items())
        for off, old in lost:
            if pad >= 3: b0[off:off + 24] = struct.pack("<6I", nidx14, pad, pad - 2, 0, old[4], old[5]); n_ok += 1
        print("   LOD group %d (2K14 group %d): %s" % (j, min(j, len(g14) - 1), "  ".join("%d+%d->%d+%d" % (o[1][0], o[1][1], n[1][0], n[1][1]) for o, n in pairs)))
    return bytes(b0), n_ok, n14e, n20e

# ===================== v66: LOD1 MESH (far / bench) =====================
# FOUND by dumping the files: LOD1 is NOT a prefix of LOD0.  It is a second, complete mesh with its OWN index buffer and its OWN vertex records
#   record = 36 bytes: [position int16x4 (w=+-32767)][normal int16x4 (w=0)][tangent int16x4][uv 4][bone idx 4][weights 4]
#   position is PACKED: world = A * s + c,   s = (LOD0 y-extent) / 65534,  c = LOD0 bbox centre   (checked on base_SD: residual 0.5 of 1000 units)
# Until now only the draw ranges (LOD table) were copied, the LOD1 buffers kept the TEMPLATE hair -> template hair / broken hair far away.
def _find_lod1(b0, b1, n_head, ie_bytes, groups):
    if len(groups) < 2: return None
    g = groups[1]; n1 = max(r[4] + r[5] for _o, r in g); need = max(r[0] + r[1] for _o, r in g)
    a = np.frombuffer(b1[:len(b1) // 2 * 2], "<u2").astype(np.int64); lo = (ie_bytes + 28 * n_head) // 2
    small = (a[lo:] < n1).astype(np.int8); ch = np.flatnonzero(np.diff(np.r_[0, small, 0])); runs = [(lo + int(x), lo + int(y)) for x, y in zip(ch[::2], ch[1::2])]
    best = None
    for rs_, re_ in runs:
        if re_ - rs_ < need or a[rs_:re_].max() < n1 - 8: continue
        for base in range(rs_, rs_ + 8):                                   # exact start = the one where every LOD1 draw range stays inside its vertex range
            tot = ok = 0
            for _o, r in g:
                seg = a[base + r[0]: base + r[0] + r[1]]; tot += len(seg); ok += int(((seg >= r[4] - 12) & (seg < r[4] + r[5] + 12)).sum())
            sc_ = ok / max(tot, 1)
            if best is None or sc_ > best[0]: best = (sc_, base, re_)
        if best and best[0] > 0.98: break
    if not best or best[0] < 0.95: return None
    _s, base, re_ = best
    for d in (0, -2, 2, -4, 4, -6, 6):                                       # start of the 36-byte records (first word(s) of it may look like an index)
        rb = re_ * 2 + d; arr = np.frombuffer(b1[rb:rb + 36 * n1], "<i2")
        if len(arr) < 18 * n1: continue
        w = arr.reshape(n1, 18)[:, 3]
        if (np.abs(w) == 32767).mean() > 0.98: return dict(base=base, nidx=(rb // 2) - base, rec=rb, n1=n1)
    return None

def _lod1_fit_uv(b0, P0, uv0, idx0, g0, g1, w1):
    """The 2K14 LOD1 is a RE-MADE mesh, its packing is not the LOD0-bbox formula.  Recover  world = A*s + c  from the surface itself: every LOD1 face
    vertex has a UV -> find the LOD0 triangle covering the same UV -> world position there.  Robust RANSAC per axis, one common scale.
    (validated on base_SD: gives 0.00027840 / 0.00027831 / 0.00027888 vs the bbox formula 0.00027847)"""
    h0 = {}
    for off, r in g0[0]:
        h = _entry_hash(b0, off)
        if h is not None: h0.setdefault(h, r)
    A = []; Q = []
    for off, r1 in g1[1]:
        h = _entry_hash(b0, off); r0 = h0.get(h) if h is not None else None
        if r0 is None or r0[5] < 200 or r1[5] > 0.8 * r0[5]: continue
        st = idx0[r0[0]:r0[0] + r0[1]]; tris = np.array([t for t in zip(st[:-2], st[1:-1], st[2:]) if len(set(t)) == 3])
        if len(tris) == 0: continue
        T = uv0[tris]; cen = T.mean(1); p0 = T[:, 0]; M = np.stack([T[:, 1] - p0, T[:, 2] - p0], 2)
        ok = np.abs(M[:, 0, 0] * M[:, 1, 1] - M[:, 0, 1] * M[:, 1, 0]) > 1e-6
        for k in range(r1[4], r1[4] + r1[5]):
            u = w1[k, 12:14]; d2 = ((cen - u) ** 2).sum(1); cand = np.argpartition(d2, min(24, len(d2) - 1))[:24]
            for c in cand[np.argsort(d2[cand])]:
                if not ok[c]: continue
                l = np.linalg.solve(M[c], u - p0[c])
                if l[0] >= -0.01 and l[1] >= -0.01 and l[0] + l[1] <= 1.01:
                    t = tris[c]; Q.append(P0[t[0]] * (1 - l[0] - l[1]) + P0[t[1]] * l[0] + P0[t[2]] * l[1]); A.append(w1[k, 0:3]); break
    if len(A) < 100: return None
    A = np.array(A, float); Q = np.array(Q, float); rng = np.random.default_rng(0); sl = []; inls = []
    for ax in range(3):
        best = (0, None, None)
        for _ in range(600):
            i1, i2 = rng.choice(len(A), 2, replace=False)
            if abs(A[i1, ax] - A[i2, ax]) < 3000: continue
            s_ = (Q[i1, ax] - Q[i2, ax]) / (A[i1, ax] - A[i2, ax]); t_ = Q[i1, ax] - s_ * A[i1, ax]; inl = np.abs(A[:, ax] * s_ + t_ - Q[:, ax]) < 0.15
            if inl.sum() > best[0]: best = (int(inl.sum()), inl, s_)
        if best[1] is None or best[0] < 0.25 * len(A): return None
        sl.append(np.polyfit(A[best[1], ax], Q[best[1], ax], 1)[0]); inls.append(best[1])
    s_ = float(np.median(sl)); c_ = np.array([np.median(Q[inls[ax], ax] - s_ * A[inls[ax], ax]) for ax in range(3)])
    return s_, c_, len(A), min(int(i.sum()) for i in inls)


def _lod1_icp(P0, idx0, g0, rec1, g1):
    """v77: recover the packing  world = raw*s + c  of a 2K14 LOD1 straight from the GEOMETRY: the LOD1 head / face / eye vertices must lie on the LOD0
    surface (hair excluded).  Robust ICP over (s, cx, cy, cz), several starts.  (the UV-pair fit of v66 was off by ~2-3 % and the UV snap of v72 moved
    vertices onto the wrong side / strands -> spiky hair, spread eyes.)  returns (s, c, median surface distance) or None"""
    from scipy.spatial import cKDTree
    from scipy.optimize import least_squares
    rng = np.random.default_rng(0); S = []
    for _o, r in g0[0][:-1]:
        st = idx0[r[0]:r[0] + r[1]]; tr = np.array([t for t in zip(st[:-2], st[1:-1], st[2:]) if len(set(t)) == 3])
        if len(tr) == 0: continue
        w = rng.dirichlet([1, 1, 1], size=(len(tr), 12)); S.append((w[..., None] * P0[tr][:, None, :, :]).sum(2).reshape(-1, 3))
    if not S: return None
    tree = cKDTree(np.concatenate(S))
    V = np.concatenate([np.arange(r[4], r[4] + r[5]) for _o, r in g1[1][:-1]]); A = rec1[V, 0:3].astype(float)
    def res(p): return tree.query(A * p[0] + p[1:4])[0]
    s0, c0 = _lod1_pack(P0); best = None
    for fs in (1.0, 0.985, 0.97, 0.955, 1.01):
        for dy in (0.0, -0.2, 0.2):
            p0 = np.array([s0 * fs, c0[0], c0[1] + dy, c0[2]])
            try: r = least_squares(res, p0, loss="soft_l1", f_scale=0.05, x_scale=[1e-5, 0.02, 0.02, 0.02])
            except Exception: continue
            m = float(np.median(res(r.x)))
            if best is None or m < best[0]: best = (m, r.x)
    if best is None: return None
    return float(best[1][0]), best[1][1:4].copy(), best[0]

def _lod1_pack(P0):
    s_ = float(np.ptp(P0[:, 1])) / 65534.0; c_ = (P0.min(0) + P0.max(0)) / 2.0; return s_, c_

def _lod1_snap(g14, P14, R28, uv14, idx14, rec14):
    """v72: the 2K14 LOD1 is a re-made mesh (only ~58% of its UVs exist in LOD0) -> in 2K20 (base + modder: 100% of LOD1 UVs == LOD0 UVs) it breaks.
    Every LOD1 vertex is moved ONTO the LOD0 surface: UV match -> copy LOD0 vertex (pos / normal / tangent / uv); else barycentric inside the LOD0 triangle that
    covers the same UV (same part).  LOD1 topology + bone bytes of 2K14 stay.  LOD1 entries [head, face, small parts..., hair] <-> LOD0 [e0, e1, e2..e(n-2), e(n-1)]."""
    from scipy.spatial import cKDTree
    g0, g1 = g14[0], g14[1]
    if len(g1) != 4 or len(g0) < 4: return None
    n0 = len(g0); parts = [[0], [1], list(range(2, n0 - 1)), [n0 - 1]]
    N1 = len(rec14); pos = np.zeros((N1, 3)); nrm = np.zeros((N1, 3)); tan = np.zeros((N1, 3)); uv = rec14[:, 12:14].astype(float).copy(); done = np.zeros(N1, bool)
    nr0 = R28[:, 0:8].copy().view("<i2").reshape(-1, 4)[:, :3].astype(float); tn0 = R28[:, 8:16].copy().view("<i2").reshape(-1, 4)[:, :3].astype(float)
    nex = nin = nfb = 0
    for j, (_o, r1) in enumerate(g1):
        ents = [g0[e][1] for e in parts[j]]
        V = np.concatenate([np.arange(r[4], r[4] + r[5]) for r in ents]); tree = cKDTree(uv14[V])
        tl = []
        for r in ents:
            st = idx14[r[0]:r[0] + r[1]]; tl += [t for t in zip(st[:-2], st[1:-1], st[2:]) if len(set(t)) == 3]
        tris = np.array(tl); T = uv14[tris]; cen = T.mean(1); ctree = cKDTree(cen); p0 = T[:, 0]; M = np.stack([T[:, 1] - p0, T[:, 2] - p0], 2)
        okt = np.abs(M[:, 0, 0] * M[:, 1, 1] - M[:, 0, 1] * M[:, 1, 0]) > 1e-6
        for k in range(r1[4], r1[4] + r1[5]):
            u = rec14[k, 12:14].astype(float); d, nn = tree.query(u)
            if d <= 1.5:
                v = V[nn]; pos[k] = P14[v]; nrm[k] = nr0[v]; tan[k] = tn0[v]; uv[k] = uv14[v]; done[k] = True; nex += 1; continue
            _d, cand = ctree.query(u, k=min(24, len(cen))); hit = False
            for c in np.atleast_1d(cand):
                if not okt[c]: continue
                l = np.linalg.solve(M[c], u - p0[c])
                if l[0] >= -0.02 and l[1] >= -0.02 and l[0] + l[1] <= 1.02:
                    t = tris[c]; wv = np.array([1 - l[0] - l[1], l[0], l[1]])
                    pos[k] = wv @ P14[t]; nrm[k] = wv @ nr0[t]; tan[k] = wv @ tn0[t]; hit = True; nin += 1; break
            if not hit:
                v = V[nn]; pos[k] = P14[v]; nrm[k] = nr0[v]; tan[k] = tn0[v]; nfb += 1
            done[k] = True
    for a_ in (nrm, tan): a_ /= np.maximum(np.linalg.norm(a_, axis=1, keepdims=True), 1e-9)
    print("   LOD1 snapped onto LOD0 surface: %d verts exact UV | %d interpolated | %d nearest-vertex fallback | %d not covered" % (nex, nin, nfb, int((~done).sum())))
    return pos, nrm, tan, uv, done

def _port_lod1(b0_14, b1_14, n14, ie14, g14, P14, b0_20, b1_20, n20, ie20, g20, P20, xf, R):
    L14 = _find_lod1(b0_14, b1_14, n14, ie14, g14); L20 = _find_lod1(b0_20, bytes(b1_20), n20, ie20, g20)
    if not L14 or not L20: print("   LOD1: buffers not found (2K14 %s / 2K20 %s) - LOD1 mesh NOT ported" % (bool(L14), bool(L20))); return b1_20, None
    need14 = max(r[0] + r[1] for _o, r in g14[1])                             # v79: indices the draw ranges really use (L14["nidx"] also counts trailing padding -> png2165 / png1612: 5542 > 5537 -> LOD1 was NOT ported -> broken far LOD)
    if L14["n1"] > L20["n1"] or need14 > L20["nidx"]:
        print("   WARNING: 2K14 LOD1 (%d verts / %d idx used) does not fit the 2K20 LOD1 slot (%d / %d) - LOD1 NOT ported" % (L14["n1"], need14, L20["n1"], L20["nidx"])); return b1_20, None
    a14 = np.frombuffer(b1_14[:len(b1_14) // 2 * 2], "<u2")
    rec14 = np.frombuffer(b1_14[L14["rec"]:L14["rec"] + 36 * L14["n1"]], "<i2").reshape(-1, 18).astype(np.int64)
    uv14 = np.frombuffer(b1_14[ie14:ie14 + 28 * n14], np.uint8).reshape(n14, 28)[:, 16:20].copy().view("<i2").reshape(n14, 2).astype(float)
    s14, c14 = _lod1_pack(P14); ok_pack = False
    try:
        ic = _lod1_icp(P14, a14[:ie14 // 2].astype(np.int64), g14, rec14, g14)
        if ic is not None and ic[2] < 0.3: s14, c14 = ic[0], ic[1]; ok_pack = True
    except Exception as e: print("   LOD1 packing fit failed (%s)" % e)
    if not ok_pack:
        try:
            fit = _lod1_fit_uv(b0_14, P14, uv14, a14[:ie14 // 2].astype(np.int64), g14, g14, rec14.astype(float))
            if fit is not None: s14, c14 = fit[0], fit[1]
        except Exception as e: print("   LOD1 UV fit failed (%s)" % e)
    s20, c20 = _lod1_pack(P20)
    world = rec14[:, 0:3] * s14 + c14
    snap = None
    if os.environ.get("CF_LOD1_SNAP", "0") == "1":                            # old v72 UV snap (off: it moved vertices onto wrong strands / sides)
        try:
            R28 = np.frombuffer(b1_14[ie14:ie14 + 28 * n14], np.uint8).reshape(n14, 28)
            snap = _lod1_snap(g14, P14, R28, uv14, a14[:ie14 // 2].astype(np.int64), rec14)
        except Exception as e: print("   LOD1 snap failed (%s)" % e)
    if snap is not None: world = np.where(snap[4][:, None], snap[0], world)
    new = xf(world)
    A = np.round((new - c20) / s20); clip = float((np.abs(A) > 32767).any(1).mean()); A = np.clip(A, -32767, 32767)
    out = rec14.copy(); out[:, 0:3] = A; out[:, 3] = np.where(rec14[:, 3] < 0, -32767, 32767)
    if snap is not None:
        m_ = snap[4]; out[m_, 12:14] = np.round(snap[3][m_]); out[m_, 4:7] = np.round(snap[1][m_] * 32767); out[m_, 8:11] = np.round(snap[2][m_] * 32767)
    for c0 in (4, 8):                                                        # normal, tangent -> rotated into the 2K20 frame
        v = out[:, c0:c0 + 3].astype(float) @ R.T; v /= np.maximum(np.linalg.norm(v, axis=1, keepdims=True), 1e-9); out[:, c0:c0 + 3] = np.round(v * 32767)
    recs20 = np.frombuffer(bytes(b1_20[L20["rec"]:L20["rec"] + 36 * L20["n1"]]), "<i2").reshape(-1, 18).astype(np.int64).copy()
    recs20[:, 0:3] = 0                                                       # unused slots collapse to the bbox centre
    recs20[:L14["n1"]] = out
    b1_20 = bytearray(b1_20); b1_20[L20["rec"]:L20["rec"] + 36 * L20["n1"]] = recs20.astype("<i2").tobytes()
    idx = a14[L14["base"]:L14["base"] + need14].astype(np.int64); idx = np.concatenate([idx, np.full(L20["nidx"] - len(idx), idx[-1], np.int64)])
    b1_20[2 * L20["base"]:2 * (L20["base"] + L20["nidx"])] = idx.astype("<u2").tobytes()
    LOD1_EXTRA.clear()
    if LOD1_HAIR:
        try: LOD1_EXTRA.update(_lod1_add_hair(b0_14, b1_14, n14, ie14, g14, P14, xf, R, s20, c20, L14, L20, need14, b1_20))
        except Exception as e: print("   LOD1 hair rebuild failed (%s)" % e)
    print("   LOD1 mesh: 2K14 %d verts / %d idx -> 2K20 slots %d / %d | packing s=%.5f -> %.5f | clipped verts %.2f%%" % (L14["n1"], L14["nidx"], L20["n1"], L20["nidx"], s14, s20, 100 * clip))
    return bytes(b1_20), dict(n1=L14["n1"], clip=clip)


def _strip_tris(s):
    t = []
    for i in range(len(s) - 2):
        a, b, c = int(s[i]), int(s[i + 1]), int(s[i + 2])
        if a == b or b == c or a == c: continue
        t.append((a, b, c) if i % 2 == 0 else (b, a, c))
    return t

def _tris_to_strip(tris):
    seq = []
    for a, b, c in tris:
        if not seq: seq = [a, b, c]; continue
        seq += [seq[-1], a, a]
        if (len(seq) - 1) % 2 == 1: seq.append(a)       # real triangle must start on an even strip index (keeps the winding)
        seq += [b, c]
    return seq

def _lod1_add_hair(b0_14, b1_14, n14, ie14, g14, P14, xf, R, s20, c20, L14, L20, need14, b1_20):
    """v80: the 2K14 LOD1 has no hair (it lives in another 2K14 IFF).  Every 2K14 LOD0 part that has no LOD1 counterpart (hash) is rebuilt for LOD1
    from its LOD0 triangles (subsampled to the free LOD1 slots) and appended to the LOD1 vertex / index buffers.  -> {hash: draw record}"""
    h1 = {_entry_hash(b0_14, o) for o, _r in g14[1]}; miss = []
    for o, r in g14[0]:
        h = _entry_hash(b0_14, o)
        if h is not None and h not in h1: miss.append((h, r))
    if not miss: print("   LOD1 hair: every LOD0 part already has a 2K14 LOD1 part - nothing to add"); return {}
    free_v = L20["n1"] - L14["n1"]; free_i = L20["nidx"] - need14
    if free_v < 8 or free_i < 16: print("   LOD1 hair: no free LOD1 slots (%d verts / %d idx)" % (free_v, free_i)); return {}
    a14 = np.frombuffer(b1_14[:len(b1_14) // 2 * 2], "<u2").astype(np.int64); parts = []
    for h, r in miss:
        t = _strip_tris(a14[r[0]:r[0] + r[1]])
        if t: parts.append((h, np.array(t, np.int64)))
    if not parts: return {}
    def pick(frac):
        sel = []
        for h, t in parts:
            k = len(t) if (len(t) <= 160 and frac >= 0.2) else max(1, int(len(t) * frac)); sel.append((h, t[np.unique(np.linspace(0, len(t) - 1, k).astype(int))]))
        return sel
    frac = 1.0
    while True:
        sel = pick(frac); nv = sum(len(np.unique(t)) for _h, t in sel); ni = sum(5 * len(t) + 2 for _h, t in sel)
        if (nv <= free_v and ni <= free_i) or frac < 0.04: break
        frac *= 0.85
    if nv > free_v or ni > free_i: print("   LOD1 hair: does not fit (%d/%d verts, %d/%d idx) - skipped" % (nv, free_v, ni, free_i)); return {}
    R28 = np.frombuffer(b1_14[ie14:ie14 + 28 * n14], np.uint8).reshape(n14, 28); extra = {}; voff = 0; ioff = 0
    for h, t in sel:
        vs = np.unique(t); strip = np.array(_tris_to_strip(np.searchsorted(vs, t) + L14["n1"] + voff), np.int64)
        A = np.clip(np.round((xf(P14[vs]) - c20) / s20), -32767, 32767); v16 = np.ascontiguousarray(R28[vs]).view("<i2").reshape(len(vs), 14).astype(np.int64)
        rec = np.zeros((len(vs), 18), np.int64); rec[:, 0:3] = A; rec[:, 3] = 32767
        for c0, s0 in ((4, 0), (8, 4)):
            v = v16[:, s0:s0 + 3].astype(float) @ R.T; v /= np.maximum(np.linalg.norm(v, axis=1, keepdims=True), 1e-9); rec[:, c0:c0 + 3] = np.round(v * 32767); rec[:, c0 + 3] = v16[:, s0 + 3]
        rec[:, 12:14] = v16[:, 8:10]; rec[:, 14:16] = v16[:, 10:12]; rec[:, 16:18] = v16[:, 12:14]
        o = L20["rec"] + 36 * (L14["n1"] + voff); b1_20[o:o + 36 * len(vs)] = rec.astype("<i2").tobytes()
        o = 2 * (L20["base"] + need14 + ioff); b1_20[o:o + 2 * len(strip)] = strip.astype("<u2").tobytes()
        extra[h] = (need14 + ioff, len(strip), len(strip) - 2, 0, L14["n1"] + voff, len(vs)); voff += len(vs); ioff += len(strip)
    print("   LOD1 hair rebuilt from LOD0: %d part(s), %d verts / %d idx (kept %.0f%% of the triangles)" % (len(extra), voff, ioff, 100 * frac))
    return extra

def _pick_head_stream(b0, b1):
    """v88: the head vertex stream is NOT always the biggest |w|==32767 run (pngYAXELV2 has a 23619-vert run that is not the head).  The right one is the stream
    whose vertex count matches the highest index used by the index buffer.  CF_HEAD_STREAM=<byte offset> forces one."""
    st = find_all_streams(b0)
    if not st: sys.exit("no vertex stream found in the 2K14 file")
    env = os.environ.get("CF_HEAD_STREAM")
    if env:
        for o_, n_ in st:
            if o_ == int(env): print("   head stream forced: offset %d, %d verts" % (o_, n_)); return o_, n_
    if len(st) < 2: return st[0]
    a = np.frombuffer(b1[:len(b1) // 2 * 2], "<u2").astype(np.int64)
    def score(n_):
        w = np.flatnonzero(a >= n_)
        if not len(w) or w[0] < 3: return 0.0
        return float(a[:w[0]].max()) / max(1, n_ - 1)
    sc0 = score(st[0][1])
    if sc0 >= 0.8: return st[0]
    for o_, n_ in st[1:]:
        if score(n_) >= 0.98:
            print("   head stream: the biggest run (%d verts @%d) does not match the index buffer (uses %.0f%% of it) -> using %d verts @%d" % (st[0][1], st[0][0], 100 * sc0, n_, o_))
            return o_, n_
    return st[0]


# ===================== v89: BIG 2K14 heads (hair / beard bigger than the 2K20 container) + own LOD1 hair =====================
# pngYAXELV2: LOD0 table = 12 head parts (2259 verts / 6183 idx) + HAIR 155f1399 (17500 verts / 65937 idx) + part bc6c4cc7 (2304 verts / 3454 idx), the real vertex
# stream has 23619 verts and ITS OWN index buffer (not the one at byte 0).  v88 took the small stream -> hair parts dropped -> template hair hidden -> BALD.
# v89: finds the right stream / index buffer / vertex records, keeps ALL head parts verbatim and fits the head's OWN hair (cut into strip runs, evenly
# sampled) into the free slots of the 2K20 container -> no template hair in LOD0.  LOD1 is built from the same parts (face clustered, hair sampled).
BIG_MESH = os.environ.get("CF_BIG", "1") != "0"; BIG_STATE = {}; LOD1_OWN_HAIR = os.environ.get("CF_LOD1_OWN_HAIR", "1") != "0"; LOD1_HAIR_OVR = {}

def _strip_runs(seg, maxlen=48):
    """triangle strip (indices) -> [(start parity, run)] cut at the degenerate restarts and chunked to <= maxlen"""
    seg = np.asarray(seg, np.int64); n = len(seg)
    if n < 3: return []
    cuts = np.flatnonzero(seg[:-1] == seg[1:]) + 1; bd = [0] + [int(c) for c in cuts] + [n]; runs = []
    for s, e in zip(bd[:-1], bd[1:]):
        if e - s < 3: continue
        t = s
        while t < e:
            u = min(e, t + maxlen)
            if u - t >= 3: runs.append((t % 2, seg[t:u]))
            if u >= e: break
            t = u - 2
    return runs

def _emit_runs(runs):
    out = []
    for p0, run in runs:
        run = [int(x) for x in run]
        if out:
            out += [out[-1], run[0]]
            if (len(out) - 1) % 2 != p0 % 2: out.append(run[0])
            out += run[1:]
        else:
            if p0 % 2: out.append(run[0])
            out += run
    return out

def _pick_runs(runs, idx_budget, vert_budget):
    """evenly spaced subset of the runs that fits both budgets (as many as possible)"""
    if not runs or idx_budget < 8 or vert_budget < 4: return []
    N = len(runs); lens = np.array([len(r) + 3 for _p, r in runs])
    def sel(k): return np.unique(np.linspace(0, N - 1, k).astype(int))
    def ok(k):
        s = sel(k)
        if int(lens[s].sum()) > idx_budget: return False
        return len(np.unique(np.concatenate([runs[i][1] for i in s]))) <= vert_budget
    lo, hi = 0, N
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if ok(mid): lo = mid
        else: hi = mid - 1
    return [runs[i] for i in sel(lo)] if lo > 0 else []

def _stripify(tris):
    """greedy triangle strips (consistent winding) -> index list (strips joined by degenerates)"""
    tris = [tuple(int(x) for x in t) for t in tris]; edge = {}
    for k, (a, b, c) in enumerate(tris):
        for u, v in ((a, b), (b, c), (c, a)): edge.setdefault((u, v), []).append(k)
    used = [False] * len(tris); runs = []
    def take(u, v):
        for k in edge.get((u, v), ()):
            if not used[k]:
                a, b, c = tris[k]
                for x, y, z in ((a, b, c), (b, c, a), (c, a, b)):
                    if (x, y) == (u, v): return k, z
        return None, None
    for k0 in range(len(tris)):
        if used[k0]: continue
        used[k0] = True; s = list(tris[k0])
        while True:
            i = len(s) - 3; p, q = s[i + 1], s[i + 2]
            k, w = take(q, p) if i % 2 == 0 else take(p, q)
            if k is None: break
            used[k] = True; s.append(w)
        runs.append((0, np.array(s, np.int64)))
    return _emit_runs(runs)

def _cluster_decimate(P, tris, target):
    """vertex clustering (grid) on a triangle list: each cell collapses onto the vertex nearest to its centre"""
    tris = np.asarray(tris, np.int64)
    if len(tris) <= target: return tris
    vs = np.unique(tris); Q = P[vs]; lo = Q.min(0); span = max(float(np.ptp(Q, 0).max()), 1e-6)
    best = tris
    def run(cell):
        key = np.floor((Q - lo) / cell).astype(np.int64); kid = key[:, 0] * 1000003 + key[:, 1] * 1009 + key[:, 2]
        _u, inv = np.unique(kid, return_inverse=True); cen = np.zeros((inv.max() + 1, 3)); cnt = np.bincount(inv)
        for d in range(3): cen[:, d] = np.bincount(inv, weights=Q[:, d]) / cnt
        dist = ((Q - cen[inv]) ** 2).sum(1); rep = np.full(inv.max() + 1, -1, np.int64)
        for j in np.argsort(-dist): rep[inv[j]] = j                       # last write = smallest distance
        mp = dict(zip(vs.tolist(), vs[rep[inv]].tolist())); t = np.vectorize(mp.get)(tris)
        t = t[(t[:, 0] != t[:, 1]) & (t[:, 1] != t[:, 2]) & (t[:, 0] != t[:, 2])]
        if len(t):
            key2 = np.sort(t, axis=1); _u2, ix = np.unique(key2, axis=0, return_index=True); t = t[np.sort(ix)]
        return t
    a, b = span / 400.0, span / 2.0
    for _ in range(14):
        mid = (a * b) ** 0.5; t = run(mid)
        if len(t) > target: a = mid
        else: b = mid; best = t
    return best


def _tri_comps(tris):
    """connected components (shared vertex) of a triangle list -> list of index arrays into tris (order of first appearance)"""
    tris = np.asarray(tris, np.int64); par = {}
    def f(x):
        while par.setdefault(x, x) != x: par[x] = par[par[x]]; x = par[x]
        return x
    for a, b, c in tris.tolist():
        ra, rb, rc = f(a), f(b), f(c)
        if ra != rb: par[rb] = ra
        rc = f(c); ra = f(a)
        if rc != ra: par[rc] = ra
    lab = {}; out = []
    for k, t in enumerate(tris.tolist()):
        r = f(t[0])
        if r not in lab: lab[r] = len(out); out.append([])
        out[lab[r]].append(k)
    return [np.array(x, np.int64) for x in out]

def _pick_ribbons(tris, idx_budget, vert_budget):
    """evenly spaced connected pieces (hair ribbons) of a triangle list, re-stripped, that fit both budgets -> strip (index list)"""
    tris = np.asarray(tris, np.int64)
    if len(tris) < 1 or idx_budget < 8 or vert_budget < 4: return []
    comps = _tri_comps(tris); N = len(comps)
    def build(k):
        sel = np.unique(np.linspace(0, N - 1, k).astype(int)); t = tris[np.concatenate([comps[i] for i in sel])]
        st = _stripify(t); return st, len(np.unique(t))
    lo, hi, best = 0, N, []
    while lo < hi:
        mid = (lo + hi + 1) // 2; st, nv = build(mid)
        if len(st) <= idx_budget and nv <= vert_budget: lo = mid; best = st
        else: hi = mid - 1
    return best

def _big_prepare(b0_14, b1_14, n20, L20):
    ents = _draw_entries(b0_14, 10 ** 7, 10 ** 8, True); g = _split_lod_groups(ents)
    if not g: return None
    g0 = g[0]; need_v = max(r[4] + r[5] for _o, r in g0); need_i = max(r[0] + r[1] for _o, r in g0)
    if need_v <= n20 and need_i <= L20: return None
    sts = [s for s in find_all_streams(b0_14) if s[1] >= need_v]
    if not sts: print("   BIG head: no vertex stream with >= %d verts found" % need_v); return None
    o14, n14 = min(sts, key=lambda s: s[1]); a = np.frombuffer(b1_14[:len(b1_14) // 2 * 2], "<u2").astype(np.int64)
    r0, r1 = g0[0][1], g0[1][1]; lim = max(r1[4] + r1[5], r0[4] + r0[5]); need_first = r0[1] + r1[1]
    m = (a < lim).astype(np.int8); ch = np.flatnonzero(np.diff(np.r_[0, m, 0])); cands = []
    for s_, e_ in zip(ch[::2], ch[1::2]):
        if e_ - s_ >= need_first: cands += list(range(int(s_), int(min(e_ - need_first, s_ + 64)) + 1))
    def score(j, parts):
        ok = tot = 0
        for _o, r in parts:
            seg = a[j + r[0]:j + r[0] + r[1]]
            if len(seg) < r[1]: return 0.0
            tot += len(seg); ok += int(((seg >= r[4]) & (seg < r[4] + r[5])).sum())
        return ok / max(tot, 1)
    good = [j for j in cands if score(j, g0[:3]) > 0.995]; best = None
    for j in good:                                                             # the SMALL legacy index buffer also matches the head parts -> pick by the WHOLE table
        sc = score(j, g0)
        if best is None or sc > best[0] + 1e-9: best = (sc, j)
        if best[0] > 0.9999: break
    if not best or best[0] < 0.9: print("   BIG head: index buffer of the %d-vert stream not found (best %.0f%%)" % (n14, 100 * (best[0] if best else 0))); return None
    j = best[1]; full = best[0]
    print("   BIG head: stream %d verts @%d, index buffer @byte %d (%.2f%% of the LOD0 table in range), table needs %d verts / %d idx > 2K20 slot %d / %d" % (n14, o14, 2 * j, 100 * full, need_v, need_i, n20, L20))
    ro = None; samp = np.unique(np.linspace(0, n14 - 1, 600).astype(int))
    def rec_score(off):
        # v90: normals unit-length AND bone weights sum to 255 (uint8x4 @24..28) AND bone idx <= 63 -> pins the REAL record start (v89 only checked normals + a +-130 byte window = picked a record table shifted by 288 bytes -> garbage bones / weights -> exploded head, headless bench)
        if off < 0 or off + 28 * n14 > len(b1_14): return 0.0
        R_ = np.frombuffer(b1_14[off:off + 28 * n14], np.uint8).reshape(n14, 28)[samp]
        v = R_[:, 0:8].copy().view("<i2").reshape(-1, 4)[:, :3].astype(float) / 32767.0
        nm = np.linalg.norm(v, axis=1); okn = ((nm > 0.9) & (nm < 1.1)).mean()
        okw = (R_[:, 24:28].astype(int).sum(1) == 255).mean(); okb = (R_[:, 20:24].max(1) <= 63).mean()
        return float(min(okn, okw, okb))
    rbest = (0.0, None)
    for d in range(-64, 6000, 2):
        for off in (2 * j - 28 * n14 - d, 2 * j + 2 * need_i + d):
            sc = rec_score(off)
            if sc > rbest[0] + 1e-9: rbest = (sc, off)
        if rbest[0] > 0.9999: break
    if rbest[0] < 0.9: print("   BIG head: vertex records not found (best %.0f%%)" % (100 * rbest[0])); return None
    ro = rbest[1]; print("   BIG head: vertex records @byte %d (normals ok %.0f%%)" % (ro, 100 * rbest[0]))
    P = get_pos(b0_14, o14, n14); R28 = np.frombuffer(b1_14[ro:ro + 28 * n14], np.uint8).reshape(n14, 28); idx = a[j:j + need_i]
    heavy = [(o, r) for o, r in g0 if r[5] > 1500 or r[1] > 6000]; fixed = [(o, r) for o, r in g0 if (o, r) not in heavy]
    if not heavy or not fixed: print("   BIG head: no separable heavy (hair) part"); return None
    Vf = max(r[4] + r[5] for _o, r in fixed); If = max(r[0] + r[1] for _o, r in fixed)
    if Vf > n20 or If > L20: print("   BIG head: fixed parts alone do not fit"); return None
    free_v = n20 - Vf - 16; free_i = L20 - If - 12; tr = []
    for _o, r in heavy: tr += _strip_tris(idx[r[0]:r[0] + r[1]])
    hair = np.array(_pick_ribbons(np.array(tr, np.int64), free_i, free_v), np.int64)
    if not len(hair): print("   BIG head: hair does not fit at all"); return None
    u = np.unique(hair); newh = Vf + np.searchsorted(u, hair); ids = np.concatenate([np.arange(Vf), u])
    tot_h = sum(r[1] for _o, r in heavy); tot_hv = sum(r[5] for _o, r in heavy)
    print("   BIG head: head parts verbatim (%d verts / %d idx) + OWN hair fitted: %d of %d idx, %d of %d verts (no template hair)" % (Vf, If, len(hair), tot_h, len(u), tot_hv))
    idx2 = np.concatenate([idx[:If], newh]); P2 = P[ids]; R2 = np.ascontiguousarray(R28[ids]); b0p = bytearray(b0_14); hair_ent = heavy[0]
    for o, r in heavy[1:]: struct.pack_into("<I", b0p, o - 4, 0)                  # extra heavy parts: no longer a draw entry (merged into the hair entry)
    for gg in g[1:]:
        for o, _r in gg: struct.pack_into("<I", b0p, o - 4, 0)                  # garbage LOD1 table of the big file
    hrec = (If, len(hair), len(hair) - 2, 0, Vf, len(u)); struct.pack_into("<6I", b0p, hair_ent[0], *hrec)
    chk = _split_lod_groups(_draw_entries(bytes(b0p), len(P2), len(idx2), True))
    if len(chk) != 1: print("   BIG head: table check failed (%d groups)" % len(chk)); return None
    ents2 = [(o, r) for o, r in chk[0]]
    return dict(n=len(P2), idx=idx2, P=P2, R=R2, b0=bytes(b0p), ents=ents2, o14=o14, nfull=n14, ids=ids, hair_i=[k for k, (o, _r) in enumerate(ents2) if o == hair_ent[0]][0], Vf=Vf, If=If)

def _lod1_parts(P, R28, parts, xf, R, s20, c20, voff, ioff):
    """parts = [strip (indices into P / R28)] -> (records (m,18), idx list, [draw records])"""
    recs = []; idx = []; draws = []
    for strip in parts:
        strip = np.asarray(strip, np.int64)
        if len(strip) < 3: draws.append((ioff, 3, 1, 0, voff, 1)); idx += [0, 0, 0] if False else []; continue
        vs = np.unique(strip); st = (np.searchsorted(vs, strip) + voff).astype(np.int64)
        A = np.clip(np.round((xf(P[vs]) - c20) / s20), -32767, 32767); v16 = np.ascontiguousarray(R28[vs]).view("<i2").reshape(len(vs), 14).astype(np.int64)
        rec = np.zeros((len(vs), 18), np.int64); rec[:, 0:3] = A; rec[:, 3] = 32767
        for c0, s0 in ((4, 0), (8, 4)):
            v = v16[:, s0:s0 + 3].astype(float) @ R.T; v /= np.maximum(np.linalg.norm(v, axis=1, keepdims=True), 1e-9); rec[:, c0:c0 + 3] = np.round(v * 32767); rec[:, c0 + 3] = v16[:, s0 + 3]
        rec[:, 12:14] = v16[:, 8:10]; rec[:, 14:16] = v16[:, 10:12]; rec[:, 16:18] = v16[:, 12:14]
        recs.append(rec); idx += st.tolist(); draws.append((ioff, len(st), len(st) - 2, 0, voff, len(vs))); voff += len(vs); ioff += len(st)
    return (np.concatenate(recs) if recs else np.zeros((0, 18), np.int64)), idx, draws

def _write_lod1(b1, L20, recs, idx, base_v=0, base_i=0):
    """write LOD1 records / indices at slot offsets (rest of the slot: records keep w/o position, index pad = last index)"""
    b1 = bytearray(b1)
    if len(recs): o = L20["rec"] + 36 * base_v; b1[o:o + 36 * len(recs)] = recs.astype("<i2").tobytes()
    if len(idx): o = 2 * (L20["base"] + base_i); b1[o:o + 2 * len(idx)] = np.array(idx, "<u2").tobytes()
    return b1

def _lod1_big_old(big, b1, b0_20, n20, ie20, g20, P20new, xf, R):
    L20 = _find_lod1(b0_20, bytes(b1), n20, ie20, g20)
    if not L20: print("   LOD1: template LOD1 buffers not found - LOD1 left as template"); return b1, None
    s20, c20 = _lod1_pack(P20new); P, R28, idx, ents = big["P"], big["R"], big["idx"], big["ents"]
    seg = lambda k: idx[ents[k][1][0]:ents[k][1][0] + ents[k][1][1]]
    tot_i = L20["nidx"] - 12; tot_v = L20["n1"] - 8
    s0, s2 = seg(0), seg(2 if len(ents) > 2 else 0); hs = seg(big["hair_i"])
    fixed_i = len(s0) + len(s2) + 6; fixed_v = len(np.unique(s0)) + len(np.unique(s2))
    face = seg(1); face_cap = int(0.45 * (tot_i - fixed_i))
    if len(face) > face_cap:
        tr = np.array(_strip_tris(face), np.int64); T = max(50, int(face_cap / 2.2)); fs = None; keep = None
        for _ in range(7):
            d = _cluster_decimate(P, tr, T); fs = np.array(_stripify(d), np.int64)
            if len(fs) <= face_cap:
                keep = fs
                if len(fs) >= 0.88 * face_cap: break
            T = max(30, int(T * (face_cap / max(len(fs), 1)) * 0.96))
        face = keep if keep is not None else fs
    face_v = len(np.unique(face))
    hair = np.array(_pick_ribbons(np.array(_strip_tris(hs), np.int64), tot_i - fixed_i - len(face) - 4, tot_v - fixed_v - face_v - 4), np.int64)
    recs, lidx, draws = _lod1_parts(P, R28, [s0, face, s2, hair], xf, R, s20, c20, 0, 0)
    # v91: LOD1 uses its OWN skin palette (1 bone / weight 255, different idx than LOD0).  v90 copied the LOD0 bone idx / weights into the LOD1 records ->
    # wrong bones in far LOD / bench = exploded hair + white wedge.  Now bone idx, weights and the w sign come from the nearest TEMPLATE LOD1 vertex of the same part.
    try:
        from scipy.spatial import cKDTree
        tpl = np.frombuffer(bytes(b1[L20["rec"]:L20["rec"] + 36 * L20["n1"]]), "<i2").reshape(-1, 18).astype(np.int64); tw = tpl[:, 0:3] * s20 + c20
        g1t = g20[1] if len(g20) > 1 else []; wp = recs[:, 0:3] * s20 + c20; done = np.zeros(len(recs), bool)
        for jj, (_io, _n, _n2, _z, vo, nv) in enumerate(draws):
            if jj >= len(g1t) or vo >= len(recs): continue
            tr = g1t[jj][1]; V = np.arange(tr[4], tr[4] + tr[5]); rng_ = np.arange(vo, min(vo + nv, len(recs)))
            _d, nn = cKDTree(tw[V]).query(wp[rng_]); recs[rng_, 14:18] = tpl[V[nn], 14:18]; recs[rng_, 3] = tpl[V[nn], 3]; done[rng_] = True
        if not done.all():
            V = np.arange(tpl.shape[0]); _d, nn = cKDTree(tw).query(wp[~done]); recs[~done, 14:18] = tpl[nn, 14:18]; recs[~done, 3] = tpl[nn, 3]
        print("   LOD1 skin: bone idx / weights taken from the template LOD1 palette (%d verts)" % len(recs))
    except Exception as e: print("   LOD1 skin palette copy FAILED (%s) - far LOD may explode" % e)
    if len(recs) > L20["n1"] or len(lidx) > L20["nidx"]: print("   LOD1 synth does not fit (%d/%d verts, %d/%d idx) - LOD1 left as template" % (len(recs), L20["n1"], len(lidx), L20["nidx"])); return b1, None
    pad = np.full(L20["nidx"] - len(lidx), lidx[-1], np.int64); lidx = lidx + pad.tolist()
    rec_all = np.frombuffer(bytes(b1[L20["rec"]:L20["rec"] + 36 * L20["n1"]]), "<i2").reshape(-1, 18).astype(np.int64).copy(); rec_all[:, 0:3] = 0; rec_all[:len(recs)] = recs
    b1 = _write_lod1(b1, L20, rec_all, lidx)
    print("   LOD1 built from the head's own LOD0 parts: face %d idx (clustered), hair %d idx / %d verts (sampled)  [slots %d / %d verts, %d / %d idx]" % (len(face), len(hair), len(np.unique(hair)), len(recs), L20["n1"], len(lidx) - len(pad), L20["nidx"]))
    return bytes(b1), draws

def _lod1_big_new(big, b1, b0_20, n20, ie20, g20, P20new, xf, R, R20t, P20t, Rn, uvmatch=False):
    """v92: LOD1 of a big head.  v91 clustered the LOD0 face down -> shredded face (spikes, torn triangles) on the bench.
    Now the TEMPLATE's own LOD1 head / face / eye topology (indices, uv, bones, draw records) is kept and only MOVED onto the new head:
    every template LOD1 vertex lies on a template LOD0 vertex -> take the new head's vertex with the same index (position / normal / tangent / uv);
    the few without a match follow the IDW displacement of their neighbours.  Only the HAIR part is rebuilt (own hair strips) inside the template's hair slot."""
    from scipy.spatial import cKDTree
    L20 = _find_lod1(b0_20, bytes(b1), n20, ie20, g20)
    if not L20 or R20t is None or P20t is None or Rn is None or len(g20) < 2 or len(g20[1]) != 4: return None
    s20, c20 = _lod1_pack(P20new); s_t, c_t = _lod1_pack(P20t); g1 = [list(r) for _o, r in g20[1]]
    tpl = np.frombuffer(bytes(b1[L20["rec"]:L20["rec"] + 36 * L20["n1"]]), "<i2").reshape(-1, 18).astype(np.int64).copy(); tpl0 = tpl.copy(); tw = tpl[:, 0:3] * s_t + c_t
    nv = g1[2][4] + g1[2][5]; Vm = min(1679, len(P20t))
    d, vi = cKDTree(P20t[:Vm]).query(tw[:nv]); mapped = d < 0.02
    if uvmatch:                                                                  # v93: seams = several LOD0 verts on the same spot with different UVs -> take the twin whose UV equals the template LOD1 vertex UV (position alone picks a random twin = wrong texture side)
        try:
            uvt0 = np.ascontiguousarray(np.asarray(R20t)[:Vm, 16:20]).view("<i2").reshape(-1, 2); tu0 = tpl[:nv, 12:14]; tr0 = cKDTree(P20t[:Vm]); nfix = 0
            for k_ in np.flatnonzero(mapped):
                if (uvt0[vi[k_]] == tu0[k_]).all(): continue
                for c_ in tr0.query_ball_point(tw[k_], 0.02):
                    if (uvt0[c_] == tu0[k_]).all(): vi[k_] = c_; nfix += 1; break
            print("   LOD1 (template topology): %d seam vertices moved to the LOD0 twin with the right UV" % nfix)
        except Exception as e: print("   LOD1 seam fix skipped (%s)" % e)
    if uvmatch and (~mapped).any():                                              # v93: template LOD1 UVs == template LOD0 UVs (100% on the 2K20 base) -> a vertex that is not ON a LOD0 vertex still has its LOD0 twin by UV
        try:
            uvt = np.ascontiguousarray(np.asarray(R20t)[:Vm, 16:20]).view("<i2").reshape(-1, 2); buk = {}
            for k_ in range(Vm): buk.setdefault((int(uvt[k_, 0]), int(uvt[k_, 1])), []).append(k_)
            tu = tpl[:nv, 12:14]; nuv = 0
            for k_ in np.flatnonzero(~mapped):
                c_ = buk.get((int(tu[k_, 0]), int(tu[k_, 1])))
                if not c_: continue
                c_ = np.array(c_); dd_ = np.linalg.norm(P20t[c_] - tw[k_], axis=1); j_ = int(dd_.argmin())
                if dd_[j_] < 0.25: vi[k_] = c_[j_]; mapped[k_] = True; nuv += 1
            print("   LOD1 (template topology): %d more verts matched to their LOD0 twin by UV" % nuv)
        except Exception as e: print("   LOD1 UV match skipped (%s)" % e)
    if mapped.mean() < 0.6: print("   LOD1 (template topology): only %.0f%% of the template LOD1 head vertices match a LOD0 vertex -> fallback" % (100 * mapped.mean())); return None
    newpos = tw[:nv].copy(); newpos[mapped] = P20new[vi[mapped]]; um = np.flatnonzero(~mapped); mt = np.flatnonzero(mapped)
    if len(um):
        kk = min(6, len(mt)); dd, ii = cKDTree(tw[mt]).query(tw[um], k=kk); dd = dd.reshape(len(um), -1); ii = ii.reshape(len(um), -1)
        disp = P20new[vi[mt]] - tw[mt]; w = 1.0 / np.maximum(dd, 1e-6) ** 2; w /= w.sum(1, keepdims=True); newpos[um] = tw[um] + (w[..., None] * disp[ii]).sum(1)
    tpl[:nv, 0:3] = np.clip(np.round((newpos - c20) / s20), -32767, 32767)
    Rm = np.ascontiguousarray(Rn[vi[mt]]); tpl[mt, 4:8] = Rm[:, 0:8].view("<i2").reshape(-1, 4); tpl[mt, 8:12] = Rm[:, 8:16].view("<i2").reshape(-1, 4); tpl[mt, 12:14] = Rm[:, 16:20].view("<i2").reshape(-1, 2)
    P, R28, idx, ents = big["P"], big["R"], big["idx"], big["ents"]; hs = idx[ents[big["hair_i"]][1][0]:ents[big["hair_i"]][1][0] + ents[big["hair_i"]][1][1]]
    th = g1[3]; ioff, voff = th[0], th[4]; ibud = th[1] - 6; vbud = th[5] - 4
    hair = np.array(_pick_ribbons(np.array(_strip_tris(hs), np.int64), ibud, vbud), np.int64)
    ti = np.frombuffer(bytes(b1[2 * L20["base"]:2 * (L20["base"] + L20["nidx"])]), "<u2").astype(np.int64).copy()
    if len(hair) >= 3:
        rh, ih, dr = _lod1_parts(P, R28, [hair], xf, R, s20, c20, voff, ioff); dh = dr[0]
        wp = rh[:, 0:3] * s20 + c20; V = np.arange(th[4], th[4] + th[5]); _d, nn = cKDTree(tw[V]).query(wp)
        rh[:, 14:18] = tpl0[V[nn], 14:18]; rh[:, 3] = tpl0[V[nn], 3]
        tpl[voff:voff + th[5], 0:3] = 0; tpl[voff:voff + len(rh)] = rh
        ti[ioff:ioff + th[1]] = ih[-1]; ti[ioff:ioff + len(ih)] = ih
        g1[3] = [ioff, len(hair), len(hair) - 2, 0, voff, len(np.unique(hair))]
    else:
        ti[ioff:ioff + 3] = voff; g1[3] = [ioff, 3, 1, 0, voff, 1]
    b1 = _write_lod1(b1, L20, tpl, ti.tolist())
    print("   LOD1 (v92): template head/face/eye topology moved onto the new head (%d / %d verts exact, rest by displacement), own hair %d idx / %d verts in the template hair slot (%d / %d)" % (int(mapped.sum()), nv, len(hair), g1[3][5], th[1], th[5]))
    return bytes(b1), [tuple(int(x) for x in r) for r in g1]

def _lod1_big(big, b1, b0_20, n20, ie20, g20, P20new, xf, R, R20t=None, P20t=None, Rn=None):
    try:
        r_ = _lod1_big_new(big, b1, b0_20, n20, ie20, g20, P20new, xf, R, R20t, P20t, Rn)
        if r_: return r_
    except Exception as e: print("   LOD1 (v92) failed (%s) -> old LOD1 builder" % e)
    return _lod1_big_old(big, b1, b0_20, n20, ie20, g20, P20new, xf, R)

def port_mesh_1to1(i14, i20):
    """-> (new block0, new block1, info)   [fixed: bone idx/weights taken from nearest 2K20 template vertex]"""
    b0_14 = bytes(i14["blocks"][0]["raw"]); b1_14 = bytes(i14["blocks"][1]["raw"])
    b0 = bytearray(i20["blocks"][0]["raw"]); b1 = bytearray(i20["blocks"][1]["raw"])
    (o14, n14), (o20, n20) = _pick_head_stream(b0_14, b1_14), find_all_streams(bytes(b0))[0]; LOD1_PORTED[0] = False
    P14 = get_pos(b0_14, o14, n14); P20 = get_pos(bytes(b0), o20, n20)
    a14 = np.frombuffer(b1_14[:len(b1_14) // 2 * 2], "<u2").astype(np.int64); ie14 = int(np.where(a14 >= n14)[0][0]) * 2
    a20 = np.frombuffer(bytes(b1[:len(b1) // 2 * 2]), "<u2").astype(np.int64); ie20 = int(np.where(a20 >= n20)[0][0]) * 2
    idx14 = a14[:ie14 // 2]; L20 = ie20 // 2; n14_full = n14; BIG_STATE.clear()
    _big = _big_prepare(b0_14, b1_14, n20, L20) if BIG_MESH else None
    if _big:
        n14 = _big["n"]; idx14 = _big["idx"]; P14 = _big["P"]; b0_14 = _big["b0"]; n14_full = n14; BIG_STATE.update(_big)
    if not _big and (n14 > n20 or len(idx14) > L20):                                                # v88: the 2K14 file carries extra data (more LODs) after the LOD0 mesh -> copy only what the LOD0 draw table uses
        _gt = _split_lod_groups(_draw_entries(b0_14, n14, len(idx14), True))
        if _gt:
            n_eff = max(r[4] + r[5] for _o, r in _gt[0]); i_eff = max(r[0] + r[1] for _o, r in _gt[0])
            if n_eff <= n20 and i_eff <= L20 and (n_eff < n14 or i_eff < len(idx14)):
                print("   2K14 mesh holds %d verts / %d idx but its LOD0 draw table only uses %d verts / %d idx -> copying those (2K20 slot %d / %d)" % (n14, len(idx14), n_eff, i_eff, n20, L20))
                n14 = n_eff; idx14 = idx14[:i_eff]; P14 = P14[:n14]
    if n14 > n20 or len(idx14) > L20: raise ValueError("2K14 mesh (%d verts, %d idx) does not fit the 2K20 container (%d verts, %d idx)" % (n14, len(idx14), n20, L20))
    R14 = _big["R"] if _big else np.frombuffer(b1_14[ie14:ie14 + 28 * n14], np.uint8).reshape(n14, 28)
    R20 = np.frombuffer(bytes(b1[ie20:ie20 + 28 * n20]), np.uint8).reshape(n20, 28).copy()
    FE = 2077; nb = min(FE, n14, n20)
    sc, R, mu_s, mu_d = _trimmed_fit(P14[:nb], P20[:nb])
    F = sc * (P14 - mu_s) @ R.T + mu_d
    _exact = EXACT and not (_big and os.environ.get("CF_BIG_EXACT", "0") != "1")           # v91: big heads are fitted (scale ~1.10 + 2K20 neck pin): verbatim 2K14 head is ~8% smaller than the 2K20 head -> looked like a long neck
    if _big and EXACT and not _exact: print("   BIG head: fitted to the 2K20 head size + neck pinned (CF_BIG_EXACT=1 = verbatim)")
    if _exact:                                                                       # v71: modder 1:1 = 2K14 positions / normals / tangents verbatim
        sc, R, mu_s, mu_d = 1.0, np.eye(3), np.zeros(3), np.zeros(3); F = P14.copy(); print("   EXACT 1:1: 2K14 vertex positions, normals, tangents copied verbatim (no fit, no neck blend)")
    # neck ring: blend to the 2K20 template so the head still meets the 2K20 body
    # v62b: the old ring (bottom 10 %) was too short -> the 2K14 neck stuck out of the 2K20 clothes.  Now the bottom CF_NECK_FULL (12 %) of the head height
    # is the 2K20 template neck EXACTLY, smooth-blended to the 2K14 shape up to CF_NECK_BLEND (30 %).  Raise both if the neck still pokes out.
    y = F[:nb, 1]; y0 = float(y.min()); span = float(np.ptp(y))
    nk_full = float(os.environ.get("CF_NECK_FULL", "0.12")); nk_end = max(float(os.environ.get("CF_NECK_BLEND", "0.30")), nk_full + 1e-3)
    t = np.clip(1.0 - ((y - y0) / span - nk_full) / (nk_end - nk_full), 0, 1); w = (t * t * (3 - 2 * t))[:, None]
    if _exact: t = np.zeros_like(t); w = np.zeros_like(w)
    print("   neck: bottom %.0f%% = 2K20 neck, blend to 2K14 shape at %.0f%% of head height (%d verts pinned)" % (100 * nk_full, 100 * nk_end, int((t >= 1).sum())))
    Pn = F.copy(); Pn[:nb] = (1 - w) * F[:nb] + w * P20[:nb]
    _Dn = Pn - F
    def _xf(Q):                                                                      # same transform + neck pinning for any 2K14 point (used for the LOD1 mesh)
        Fq = sc * (np.asarray(Q) - mu_s) @ R.T + mu_d
        return Fq + _idw_disp(Fq, F[:nb], _Dn[:nb], k=6)
    P = np.tile(Pn.mean(0), (n20, 1)); P[:n14] = Pn                                  # unused slots collapse to a point
    # v79 LOD1 FIX: LOD1 positions are int16 packed inside the mesh bounding box.  Unused slots now hold the TEMPLATE's own extreme vertices (min/max per axis),
    # so the bounds / pack frame of the file stay the template's (head shrinks the box -> far / bench LOD was packed against a different box than the game used).
    try:
        ex = np.unique(np.r_[P20.argmin(0), P20.argmax(0)]); free = np.arange(n14, n20)
        if len(free) >= len(ex): P[free[:len(ex)]] = P20[ex]; print("   LOD1 frame: %d unused slots pinned to the template bbox extremes" % len(ex))
    except Exception as e: print("   LOD1 frame pin skipped (%s)" % e)
    b0 = set_pos(bytes(b0), o20, P)
    # FIX v61: per-vertex float array that follows the position stream (n+35 floats).  Template and 2K14 are identical for slots 0..1702
    # and differ from 1703 on (= where the eye / lip / teeth pieces start to differ) -> the template's values were describing other vertices.
    if os.environ.get("CF_FLOATS", "src").lower() != "off":
        e14 = o14 + 8 * n14; e20 = o20 + 8 * n20
        if _big:                                                                   # v90: floats of the REAL (big) stream, re-ordered like the fitted mesh (v89 read them from the wrong stream)
            _fa = np.frombuffer(b0_14[_big["o14"] + 8 * _big["nfull"]:_big["o14"] + 12 * _big["nfull"]], "<f4"); f14 = _fa[_big["ids"]]
        else: f14 = np.frombuffer(b0_14[e14:e14 + 4 * n14], "<f4")
        bb = bytearray(b0); bb[e20:e20 + 4 * n14] = f14.tobytes(); b0 = bb
        print("   per-vertex floats: %d slots copied from 2K14 (CF_FLOATS=off to disable)" % n14)
    # FIX v60: eyes / teeth / mouth bag living in their OWN streams stayed at 2K20 template positions -> floating
    b0 = fit_secondary_streams(b0, bytes(i20["blocks"][0]["raw"]), (o20, n20), P20[:nb], Pn[:nb])
    # records: normal/tangent rotated into the 2K20 frame, UV verbatim
    out = R20.copy(); out[:n14] = R14
    for off in (0, 8):
        v = np.frombuffer(R14[:, off:off + 8].tobytes(), "<i2").reshape(-1, 4).astype(float); xyz = v[:, :3] @ R.T
        xyz /= np.maximum(np.linalg.norm(xyz, axis=1, keepdims=True), 1e-9); v2 = v.copy(); v2[:, :3] = np.round(xyz * 32767)
        out[:n14, off:off + 8] = np.frombuffer(v2.astype("<i2").tobytes(), np.uint8).reshape(-1, 8)
    # FIX: 2K14 bone palette != 2K20 palette -> bone idx (20..23) + weights (24..27) from nearest 2K20 template vertex
    # v62: the bone palette of 2K14 and 2K20 is IDENTICAL (checked: slots 0..1702 have 100% same idx+weights), so the 2K14 skinning is kept
    # VERBATIM (already in `out` from R14).  The old nearest-template-vertex guess rewrote ~half of the verts (eyes, lids, jaw, mouth, beard)
    # with the bones of unrelated vertices -> eyes/mouth deformed + floated.  CF_BONES=nearest restores the old behaviour.
    if os.environ.get("CF_BONES", "src").lower() == "nearest":
        bw = R20[:, 20:28].copy(); T = np.asarray(P20, np.float32); Q = np.asarray(Pn, np.float32)
        for a in range(0, n14, 256):
            e = min(a + 256, n14)
            d = ((Q[a:e, None, :] - T[None, :, :]) ** 2).sum(2)
            out[a:e, 20:28] = bw[d.argmin(1)]
    else:
        print("   bone idx/weights: copied verbatim from 2K14 (CF_BONES=nearest for old behaviour)")
    b1[ie20:ie20 + 28 * n20] = out.tobytes()
    idx_new = np.concatenate([idx14, np.full(L20 - len(idx14), idx14[-1], np.int64)]).astype("<u2")
    b1[0:2 * L20] = idx_new.tobytes()
    # v63: draw-call / LOD table.  The table is a list of LOD GROUPS (each group = every part of one LOD; a new group starts where firstIdx
    # falls back).  Before, only group 0 (LOD0) was copied; LOD1/LOD2/bench groups kept the TEMPLATE ranges -> template hair / broken hair far away.
    # Now every group j of the 2K20 file gets 2K14 group j (the last 2K14 group is reused if 2K20 has more LODs).  CF_PATCH_T2=0 = old behaviour.
    if os.environ.get("CF_LOD1", "1") != "0":
        _g14 = _split_lod_groups(_draw_entries(b0_14, n14, len(idx14), True)); _g20 = _split_lod_groups(_draw_entries(bytes(i20["blocks"][0]["raw"]), 10 ** 7, 10 ** 8, True))
        try:
            if _big:
                b1, _dr = _lod1_big(_big, b1, bytes(i20["blocks"][0]["raw"]), n20, ie20, _g20, P, _xf, R, R20t=R20.copy(), P20t=P20, Rn=out); BIG_STATE["lod1"] = _dr
            else:
                _tdone = False
                if os.environ.get("CF_LOD1_TPL", "1") != "0" and _g14 and _g14[0] and len(_g14[0]) >= 3:     # v93: same LOD1 method as the big heads (template topology moved onto the head)
                    try:
                        _e0 = _g14[0]; _cand = [k for k in range(2, len(_e0)) if _e0[k][1][5] >= 200 and _e0[k][1][1] >= 150]
                        _hi = max(_cand, key=lambda k: _e0[k][1][5]) if _cand else len(_e0) - 1
                        _bn = dict(P=P14, R=R14, idx=idx14, ents=_e0, hair_i=_hi)
                        _r1 = _lod1_big_new(_bn, b1, bytes(i20["blocks"][0]["raw"]), n20, ie20, _g20, P, _xf, R, R20.copy(), P20, out, uvmatch=True)
                        if _r1: b1, _dr = _r1; BIG_STATE["lod1"] = _dr; LOD1_EXTRA.clear(); LOD1_PORTED[0] = False; _tdone = True
                    except Exception as e: print("   LOD1 (v93 template topology) failed (%s) -> 2K14 LOD1 port" % e)
                if not _tdone:
                    b1, _l1 = _port_lod1(b0_14, b1_14, n14_full, ie14, _g14, P14, bytes(i20["blocks"][0]["raw"]), b1, n20, ie20, _g20, P, _xf, R); LOD1_PORTED[0] = bool(_l1)
        except Exception as e: print("   LOD1 port failed (%s) - LOD1 left as template" % e)
    b0, n_ok, n14e, n20e = _patch_lod_groups(bytes(b0), b0_14, n14, len(idx14), n20, L20)
    if BIG_STATE.get("lod1"):                                                          # v89 / v93: LOD1 draw table of a big head = the parts built from its own LOD0
        b0 = bytearray(b0); _gg = _split_lod_groups(_draw_entries(bytes(b0), 10 ** 7, 10 ** 8, True))
        if len(_gg) >= 2 and len(_gg[1]) == len(BIG_STATE["lod1"]):
            for (_o, _r), _rec in zip(_gg[1], BIG_STATE["lod1"]): struct.pack_into("<6I", b0, _o, *_rec)
            n_ok += len(_gg[1]); print("   LOD group 1: %d draw records written for the rebuilt LOD1" % len(_gg[1]))
        b0 = bytes(b0)
    return bytes(b0), bytes(b1), dict(n14=n14, idx14=len(idx14), lod14=n14e, lod20=n20e, lod_patched=n_ok, scale=sc)




# ===================== v60: FIT EYES / TEETH / MOUTH (secondary streams) TO THE 2K14 HEAD =====================
# The 2K14 head is copied into the head stream, but eyeballs, teeth, mouth-bag etc. are separate position streams in the
# 2K20 file.  They kept the template positions -> floating eyes + floating mouth in front of the face.
# Fix: affine ICP (template face -> ported 2K14 face), applied to every other stream.
#      Small blobs (eyeballs, <=600 verts) move RIGIDLY (translate + uniform scale) so they stay round.
# env: CF_SEC_MODE=affine(default)|off   CF_SEC_DX/DY/DZ = extra manual offset (model units, e.g. 0.01)
#      CF_SEC_MINRUN=16 (smallest stream detected)   CF_SEC_DEBUG=1 prints every stream found
def _nn_idx(A, B, ch=400):
    idx = np.empty(len(A), np.int64); dd = np.empty(len(A))
    for a in range(0, len(A), ch):
        e = ((A[a:a + ch, None, :] - B[None, :, :]) ** 2).sum(2); idx[a:a + ch] = e.argmin(1); dd[a:a + ch] = e.min(1)
    return idx, dd

def _affine_icp(S, D, iters=40, keep=0.85):
    S = np.asarray(S, float); D = np.asarray(D, float)
    sc = np.clip(np.ptp(D, 0) / np.maximum(np.ptp(S, 0), 1e-9), 0.6, 1.6)
    M = np.diag(sc); t = D.mean(0) - M @ S.mean(0)
    for _ in range(iters):
        X = S @ M.T + t
        i1, d1 = _nn_idx(X, D); i2, d2 = _nn_idx(D, X)
        src = np.concatenate([S, S[i2]]); dst = np.concatenate([D[i1], D]); err = np.concatenate([d1, d2])
        k = np.argsort(err)[:int(len(err) * keep)]
        A = np.hstack([src[k], np.ones((len(k), 1))])
        sol, *_ = np.linalg.lstsq(A, dst[k], rcond=None)
        Mn, tn = sol[:3].T, sol[3]
        done = np.abs(Mn - M).max() < 1e-7 and np.abs(tn - t).max() < 1e-7
        M, t = Mn, tn
        if done: break
    U, Sg, Vt = np.linalg.svd(M); M = U @ np.diag(np.clip(Sg, 0.6, 1.6)) @ Vt
    return M, t

def _components(P, max_n=4000):
    n = len(P)
    if n > max_n or n < 2: return np.zeros(n, np.int64)
    d = np.sqrt(((P[:, None, :] - P[None, :, :]) ** 2).sum(2)); np.fill_diagonal(d, np.inf)
    nn = d.min(1); nn = nn[np.isfinite(nn) & (nn > 1e-9)]
    if len(nn) == 0: return np.zeros(n, np.int64)
    adj = d <= 2.5 * float(np.median(nn)); lab = np.arange(n)
    for _ in range(n):
        new = np.minimum(np.where(adj, lab[None, :], n + 1).min(1), lab)
        if (new == lab).all(): break
        lab = new
    return np.unique(lab, return_inverse=True)[1]

# ===================== v62: LOCAL (per-vertex) FIT of eyes / teeth / mouth =====================
# ROOT CAUSE of floating eyes + mouth: v60 moved every secondary stream with ONE global affine map (template face -> ported 2K14 face).
# A 2K14 head has different eye-socket depth / eye spacing / mouth opening than the 2K20 template, so a global map can only be right on
# average -> the eyeballs and the mouth bag land in front of (or beside) the 2K14 face.
# Fix: the head stream keeps vertex-index correspondence with the template (that is what the global fit already relies on), so the
# displacement field  D[i] = ported[i] - template[i]  is known on the face.  Every eye / teeth / mouth vertex now gets the inverse-distance
# weighted displacement of its K nearest template face vertices (local, follows the socket / lips).  Eyeballs (small blobs) get ONE
# displacement at their centre (stay round) + a clamped local scale.
# env: CF_SEC_MODE=local(default)|affine|off   CF_SEC_K=8  CF_SEC_SRC=1703 (face verts used as displacement source)
def _idw_disp(Q, S, D, k=8, pw=2.0):
    """Q (m,3) points; S (n,3) template face verts; D (n,3) displacement of those verts -> (m,3)"""
    out = np.empty((len(Q), 3)); k = max(1, min(k, len(S)))
    for a in range(0, len(Q), 400):
        q = Q[a:a + 400]; d2 = ((q[:, None, :] - S[None, :, :]) ** 2).sum(2)
        nn = np.argpartition(d2, k - 1, axis=1)[:, :k]
        dd = np.take_along_axis(d2, nn, 1); w = 1.0 / (np.sqrt(dd) + 1e-6) ** pw; w /= w.sum(1, keepdims=True)
        out[a:a + 400] = (w[:, :, None] * D[nn]).sum(1)
    return out

def _local_streams_fit(P, S, D, k=8, blob=600):
    """P (n,3) template positions of one stream -> new positions (n,3)"""
    lab = _components(P); Q = P.copy()
    for c in np.unique(lab):
        m = lab == c; pc = P[m]
        if m.sum() <= blob:                                  # eyeball etc.: rigid translate + clamped local scale
            cen = pc.mean(0); disp = _idw_disp(cen[None], S, D, k=max(k, 24))[0]
            d2 = ((S - cen) ** 2).sum(1); nn = np.argsort(d2)[:60]
            a = np.linalg.norm((S[nn] - S[nn].mean(0)), axis=1).mean(); b = np.linalg.norm(((S[nn] + D[nn]) - (S[nn] + D[nn]).mean(0)), axis=1).mean()
            s = float(np.clip(b / max(a, 1e-9), 0.92, 1.08))
            Q[m] = (pc - cen) * s + cen + disp
        else:                                                # teeth / lips / mouth bag: per-vertex local displacement
            Q[m] = pc + _idw_disp(pc, S, D, k=k)
    return Q
# ===================== end v62 =====================

# ===================== v62b: FAR-LOD TEMPLATE HAIR =====================
# At bench distance the game draws extra LOD streams that still hold the 2K20 BASE hair (afro etc.).  They were only displaced, never removed.
# Any big secondary piece that reaches the top of the head / sticks out sideways is hair -> collapsed to one hidden point inside the head.
# The 2K14 hair lives in the head stream (copied 1:1 with the 2K14 LOD table), so it is what is left to draw.
# env: CF_LOD_HAIR=collapse(default)|off   CF_LOD_HAIR_DEBUG=1
def _lod_hair_mask(P, Sf):
    lo, hi = Sf.min(0), Sf.max(0); span = float(np.ptp(Sf[:, 1])); lab = _components(P); m = np.zeros(len(P), bool); nl = len(np.unique(lab))
    for c in np.unique(lab):
        sel = lab == c; pc = P[sel]
        if sel.sum() <= 600: continue                                          # eyeballs, lashes: never hair
        top = pc[:, 1].max() > hi[1] - 0.01 * span; side = pc[:, 0].min() < lo[0] - 0.02 * span or pc[:, 0].max() > hi[0] + 0.02 * span
        if os.environ.get("CF_LOD_HAIR_DEBUG"): print("      piece %d verts: y %.3f..%.3f (head top %.3f) -> %s" % (sel.sum(), pc[:, 1].min(), pc[:, 1].max(), hi[1], "HAIR" if (top or side) else "keep"))
        if not (top or side): continue
        if nl == 1 and len(P) > 4000: m[sel] = pc[:, 1] > hi[1] - 0.12 * span   # one big undivided stream: only the upper part
        else: m[sel] = True
    return m

def fit_secondary_streams(b0_new, b0_tpl, head, S_face, D_face):
    if os.environ.get("CF_SEC_MODE", "local").lower() == "off": return b0_new
    o_h, n_h = head; minrun = int(os.environ.get("CF_SEC_MINRUN", "16"))
    extra = np.array([float(os.environ.get("CF_SEC_D" + a, "0")) for a in "XYZ"])
    st = [(o, n) for o, n in find_all_streams(b0_tpl, minrun=minrun) if not (o_h <= o < o_h + 8 * n_h)]
    st = [(o, n) for o, n in st if not any(o2 <= o and o + 8 * n <= o2 + 8 * n2 and (o2, n2) != (o, n) for o2, n2 in st)]
    if os.environ.get("CF_SEC_DEBUG"):
        for o, n in st:
            P = get_pos(b0_tpl, o, n); print("   stream off=%d n=%d min=%s max=%s" % (o, n, np.round(P.min(0), 3), np.round(P.max(0), 3)))
    if not st: print("   (no secondary eye/mouth streams found)"); return b0_new
    if os.environ.get("CF_SEC_MODE", "local").lower() == "local":
        ns = min(int(os.environ.get("CF_SEC_SRC", "1703")), len(S_face)); S = np.asarray(S_face[:ns], float); Dd = np.asarray(D_face[:ns], float) - S
        k = int(os.environ.get("CF_SEC_K", "8")); out = bytearray(b0_new)
        for o, n in st:
            P = get_pos(b0_tpl, o, n); Q = _local_streams_fit(P, S, Dd, k=k) + extra
            if os.environ.get("CF_LOD_HAIR", LOD_HAIR).lower() != "off":
                hm = _lod_hair_mask(P, np.asarray(S_face, float))
                if hm.any(): Q[hm] = np.asarray(D_face, float).mean(0); print("   LOD hair: stream off=%d -> %d template-hair verts collapsed (hidden in the head)" % (o, int(hm.sum())))
            out = set_pos(bytes(out), o, Q)
            print("   local fit stream off=%d: %d verts, mean move %.4f" % (o, n, float(np.linalg.norm(Q - P, axis=1).mean())))
        return out
    M, t = _affine_icp(S_face, D_face)
    _, dd = _nn_idx(S_face @ M.T + t, D_face)
    print("   secondary fit: affine scales %s, face residual %.4f" % (np.round(np.linalg.svd(M)[1], 3), float(np.sqrt(dd).mean())))
    out = bytearray(b0_new)
    for o, n in st:
        P = get_pos(b0_tpl, o, n); Q = P @ M.T + t; lab = _components(P)
        s = float(abs(np.linalg.det(M)) ** (1 / 3))
        for c in np.unique(lab):
            m = lab == c
            if m.sum() <= 600:
                cen = P[m].mean(0); Q[m] = (P[m] - cen) * s + (cen @ M.T + t)
        out = set_pos(bytes(out), o, Q + extra)
        print("   moved stream off=%d: %d verts, %d piece(s)" % (o, n, len(np.unique(lab))))
    return out
# ===================== end v60 =====================

# ===================== v59: PORT + CLI =====================
def classify_template(path):
    i = read_iff(path); layout = [(f, w) for o, f, w in _find_descs(i["blocks"][0]["raw"])][-4:]
    if len(layout) != 4: raise ValueError("no CF texture layout")
    return ("HD" if layout[0][1] >= 512 else "SD"), layout

def _here():
    try: return os.path.dirname(os.path.abspath(__file__))
    except NameError: return os.getcwd()

def find_template(folder, explicit=None, exclude=()):
    """Any 2K20 CF IFF works as the container (the first one found is cached in cf_base/ and reused)."""
    ex = {os.path.abspath(x) for x in exclude}
    cache = os.path.join(_here(), "cf_base")
    cands = [explicit] if explicit else sorted(os.path.join(folder, f) for f in os.listdir(folder) if f.lower().endswith(".iff"))
    if not explicit and os.path.isdir(cache): cands += sorted(os.path.join(cache, f) for f in os.listdir(cache) if f.lower().endswith(".iff"))
    for p in cands:
        if os.path.abspath(p) in ex: continue
        try: kind, lay = classify_template(p)
        except (SystemExit, Exception): continue
        if kind != "SD" and not explicit: continue          # v64: an explicitly given HD base (-t base_1024.iff) is allowed
        try:
            os.makedirs(cache, exist_ok=True); dst = os.path.join(cache, "base_SD.iff")
            if not os.path.exists(dst) and os.path.abspath(p) != os.path.abspath(dst):
                import shutil; shutil.copyfile(p, dst); print("   saved reusable base -> cf_base/base_SD.iff")
        except Exception: pass
        print("   2K20 base -> %s (face %dpx)" % (os.path.basename(p), lay[0][1])); return p
    sys.exit("Walang 2K20 SD face IFF. Ilagay ang kahit anong 2K20 CF IFF sa folder (o gamitin ang -t).")

def _diag_dump(i14, i20):
    """[diag] structure dump (goes into cf_port_log.txt) - send that file when a LOD / hair problem remains."""
    for tag, i in (("2K14", i14), ("2K20 base", i20)):
        try:
            b0 = bytes(i["blocks"][0]["raw"]); print("   [diag] %s: block sizes %s" % (tag, [len(b["raw"]) for b in i["blocks"]]))
            for o, n in find_all_streams(b0, minrun=16)[:30]:
                P = get_pos(b0, o, n); print("   [diag]   stream off=%d n=%d bbox %s .. %s" % (o, n, np.round(P.min(0), 3), np.round(P.max(0), 3)))
            for gi, g in enumerate(_split_lod_groups(_draw_entries(b0, 10 ** 7, 10 ** 8, True))):
                print("   [diag]   LOD group %d: %s" % (gi, "  ".join("%s:%d+%d/v%d+%d" % (("%08x" % _entry_hash(b0, off)) if _entry_hash(b0, off) else "-", r[0], r[1], r[4], r[5]) for off, r in g)))
        except Exception as e: print("   [diag] %s dump failed (%s)" % (tag, e))

class _Ui:
    """v77: the console only shows ONE progress line (0-100 %); every detail goes to cf_port_log.txt (CF_VERBOSE=1 prints it all)"""
    def __init__(self, orig):
        self.o = orig; self.warn = []; self.last = -1; self.fi = 0; self.n = 1
        try: self.tty = bool(orig.isatty())
        except Exception: self.tty = False
    def show(self, frac, label=""):
        pct = int(max(0, min(100, 100 * (self.fi + max(0.0, min(1.0, frac))) / max(self.n, 1))))
        if pct < self.last and self.last < 100: pct = self.last
        if not self.tty and pct == self.last: return
        if not self.tty and pct < 100 and pct % 5 and pct - self.last < 5: return
        self.last = pct; bar = "#" * (pct // 4) + "-" * (25 - pct // 4)
        line = "[%s] %3d%%  %s" % (bar, pct, label)
        try: self.o.write(("\r" + line.ljust(70)) if self.tty else (line + "\n")); self.o.flush()
        except Exception: pass
    def say(self, t):
        try: self.o.write(("\r" + " " * 72 + "\r" if self.tty else "") + t + "\n"); self.o.flush()
        except Exception: pass

class _Tee:
    """everything -> log file; console only with CF_VERBOSE=1; WARNING / FAILED lines are collected for the end summary"""
    def __init__(self, path, orig, ui=None, verbose=False): self.f = open(path, "w", encoding="utf-8"); self.o = orig; self.ui = ui; self.v = verbose
    def write(self, t):
        if self.v:
            try: self.o.write(t)
            except Exception: pass
        try: self.f.write(t)
        except Exception: pass
        if self.ui is not None and ("WARNING" in t or "NOT ported" in t or "failed" in t):
            self.ui.warn.append(t.strip()[:110])
    def flush(self):
        try:
            if self.v: self.o.flush()
            self.f.flush()
        except Exception: pass

PROG = {"ui": None, "lo": 0.0, "hi": 1.0, "acc": 0.0, "tag": ""}
def _progress(frac, label=""):
    ui = PROG["ui"]
    if ui is not None: ui.show(frac, label)

def _u64(h, o): return struct.unpack_from("<Q", h, o)[0]

def _capture_skin_ref(i20):
    """decoded LOD0 of the SD template's face texture (skin target), taken before the template is enlarged"""
    try:
        b0t = i20["blocks"][0]["raw"]; b1t = i20["blocks"][1]["raw"]; tm = tex_map(i20["hdr"], b0t, len(b1t))
        recs = sorted(tm.items(), key=lambda kv: kv[1]["desc"]); layout = [(t["fmt"], t["w"]) for _, t in recs]
        offs = _tex_plan(layout, len(b1t), _nch_from_hdr(i20["hdr"], len(layout)))[2]
        for ti, (hx, t) in enumerate(recs):
            if hx == "27a62111":
                try: SKIN_REF_MAT[0] = np.asarray(_etc_decode(b1t, offs[(ti, 0)], t["w"], t["fmt"] == 16), np.float64)
                except Exception: pass
            if hx == "6a482dae": SKIN_REF[0] = np.asarray(_etc_decode(b1t, offs[(ti, 0)], t["w"], t["fmt"] == 16), np.float64)
    except Exception as e: print("   skin reference not captured (%s)" % e)

def to_hd(hdr, b0, b1, factor=2, widths=None):
    """SD template -> HD container (no HD template needed).  Reproduces what the modder's HD.iff differs from his SD.iff:
       * block0 texture descriptors: width/height x factor, mip field +0x40 per doubling (u16 at desc+0xC6)
       * header chunk table (4 entries per texture: LOD0 0x80, LOD1 0x81, LOD2 0x82, tail 0x9f; size field = 4 x real bytes) re-laid out after the old
         virtual end (each texture contiguous, 16-byte aligned); texture data pointers (= old LOD0 offsets) re-pointed; virtual size field (+0x78)
       * block1: mesh part kept, texture area = new plan, zero padding up to the new virtual end
       -> returns (hdr, b0, b1, phys_end, virtual_end)"""
    hdr = bytearray(hdr); b0 = bytearray(b0); widths = widths or {}
    tm = tex_map(hdr, b0, len(b1)); recs = sorted(tm.items(), key=lambda kv: kv[1]["desc"]); n = len(recs)
    base = {0x9f: 0xb8, 0x82: 0x108, 0x81: 0x138, 0x80: 0x188}
    for ti in range(n):
        for ty in (0x80, 0x81, 0x9f):
            if (_u64(hdr, base[ty] + 16 * ti) & 0xff) != ty: raise ValueError("unknown header chunk-table layout (type %02x tex %d)" % (ty, ti))
    nch = _nch_from_hdr(hdr, n); ents = []
    for ty, o0 in base.items():
        for ti in range(n):
            o = o0 + 16 * ti
            if (_u64(hdr, o) & 0xff) == ty: ents.append((o, ty, ti, _u64(hdr, o) >> 8, _u64(hdr, o + 8)))
    mesh_end = min(e[4] for e in ents); old_vend = max(e[4] + e[3] // 4 for e in ents)
    old80 = {ti: _u64(hdr, base[0x80] + 16 * ti + 8) for ti in range(n)}
    tw = [max(t["w"] * factor, int(widths.get(hx, 0))) for hx, t in recs]          # v76: target width per slot (factor, or an own minimum per texture hash)
    if MAX_TEX:
        _cl = [min(max(MAX_TEX, t["w"]), w_) for (_, t), w_ in zip(recs, tw)]
        if _cl != tw: print("   MAX_TEX %d: slot widths %s -> %s (bigger slots render black in game)" % (MAX_TEX, tw, _cl))
        tw = _cl
    for i_, w_ in enumerate(tw):
        if w_ & (w_ - 1): raise ValueError("target slot width %d is not a power of two" % w_)
    layout = [(t["fmt"], tw[i_]) for i_, (_, t) in enumerate(recs)]
    pos = (old_vend + 15) & ~15; new80 = {}
    for ti, (f, w) in enumerate(layout):
        pos = (pos + 15) & ~15; nlev = int(np.log2(w)) + 1; reals = [_lvl_bytes(f, w >> k) for k in range(nlev)]
        for k in range(nch[ti]):
            o = base[0x80 + k] + 16 * ti; struct.pack_into("<QQ", hdr, o, ((reals[k] * 4) << 8) | (0x80 + k), pos)
            if k == 0: new80[ti] = pos
            pos += reals[k]
        o = base[0x9f] + 16 * ti; tail = sum(reals[nch[ti]:]); struct.pack_into("<QQ", hdr, o, ((tail * 4) << 8) | 0x9f, pos); pos += tail
    new_vend = pos
    for q in range(0, len(hdr) - 7, 8):                                   # data pointers (old LOD0 offsets) -> new
        if 0xa8 <= q < 0x1e0: continue
        v = _u64(hdr, q)
        for ti, ov in old80.items():
            if v == ov: struct.pack_into("<Q", hdr, q, new80[ti])
    if _u64(hdr, 0x78) == old_vend: struct.pack_into("<Q", hdr, 0x78, new_vend)
    else: print("   WARNING: header virtual-size field (+0x78) is %d, expected %d - left alone" % (_u64(hdr, 0x78), old_vend))
    for i_, (hx, t) in enumerate(recs):                                    # descriptors in block0
        x = t["desc"]; fl = struct.unpack_from("<H", b0, x + 0xC6)[0]; sh = int(round(np.log2(tw[i_] / t["w"])))
        struct.pack_into("<H", b0, x + 0xC6, fl + 0x40 * sh); struct.pack_into("<HH", b0, x + 0xC8, tw[i_], t["h"] * tw[i_] // t["w"])
    _o, total, _of = _tex_plan(layout, 0, nch); phys_end = mesh_end + total
    b1n = bytearray(bytes(b1[:mesh_end])) + bytearray(new_vend - mesh_end)
    print("   HD from SD template: x%d | slots %s | mesh %d B | texture plan %d B | physical end %d | virtual end %d (zero padded)" % (factor, ", ".join("%d" % w for _, w in layout), mesh_end, total, phys_end, new_vend))
    return bytes(hdr), bytes(b0), bytes(b1n), phys_end, new_vend

def _p2near(x):
    x = max(1, int(x)); lo = 1 << (x.bit_length() - 1)
    return lo * 2 if x > lo * 1.4142 else lo

def _native_widths(imgs):
    """native width of every 2K14 texture (power of two, >= 256); the 2-panel body map counts one panel"""
    d = {}
    for name, im in imgs.items():
        w, h = im.size
        if name == "material_map" and w >= 1.8 * h: w //= 2
        d[name] = max(256, _p2near(w))
    return d

def port_iff(iff14_path, template_path, outdir, imgs):
    os.makedirs(outdir, exist_ok=True); globals()["CHECK_DIR"] = outdir
    i14 = read_iff(iff14_path); i20 = read_iff(template_path)
    try: _diag_dump(i14, i20)
    except Exception as e: print("   [diag] failed (%s)" % e)
    b0, b1, info = port_mesh_1to1(i14, i20)
    print("   MESH 1:1: %d verts, %d idx copied from 2K14 | LOD table: %d/%d entries patched | fit scale %.4f" % (info["n14"], info["idx14"], info["lod_patched"], info["lod20"], info["scale"]))
    if info["lod_patched"] < info["lod20"]: print("   WARNING: LOD table entries differ (2K14 %d / 2K20 %d / patched %d) - lower LODs may cut the hair" % (info["lod14"], info["lod20"], info["lod_patched"]))
    globals()["HAIR_MESH_INJECTED"] = True
    if NATIVE: globals()["TONE_ON"] = False; globals()["TINT_ON"] = False; globals()["SKIN_SD"] = "alpha0"; globals()["SKIN_HD"] = "alpha0"; globals()["SKIN_UNIFY"] = "off"
    if imgs:                                                                   # v82: NO placeholders - every slot must come from the 2K14 file
        _miss = [n_ for n_ in ALL_SLOTS if n_ not in imgs]
        if _miss and os.environ.get("CF_ALLOW_PLACEHOLDER", "0") != "1":
            raise ValueError("texture(s) not found in the 2K14 IFF: %s  (decoded: %s) - fix with --map HASH=slot or --material file.png, CF_ALLOW_PLACEHOLDER=1 to allow a placeholder" % (", ".join(_miss), ", ".join(imgs)))
    _progress(0.12, "textures"); _capture_skin_ref(i20); ROLES[0] = None; PHYS_END[0] = None
    base_name = os.path.splitext(os.path.basename(iff14_path))[0]; outs = []
    # ---- v76: slot roles first (detected on the untouched SD template), then per-output slot widths
    if imgs:
        ROLES_ONLY[0] = True
        try: write_textures_dd(b0, b1, imgs, i20["hdr"])
        finally: ROLES_ONLY[0] = False
    nat = _native_widths(imgs) if imgs else {}
    inv = {n: h for h, n in (ROLES[0] or {}).items()}
    tmw = {h: t["w"] for h, t in tex_map(i20["hdr"], b0, len(b1)).items()}
    print("   2K14 native texture widths: %s | output mode %d (%s)" % (nat, OUT_MODE, {1: "SD & HD x2", 2: "SD & HD x4", 3: "SD & HD NATIVE"}.get(OUT_MODE, "?")))
    mat_hx = inv.get("material_map"); mat_nat = nat.get("material_map", 0)
    _aS = float(sum(w_ ** 2 for w_ in tmw.values())) or 1.0                      # progress weights: SD pass vs HD pass (pixel area)
    _aH = float(sum((w_ * (HD_FACTOR if OUT_MODE != 3 else 1)) ** 2 for w_ in tmw.values())) if MAKE_HD else 0.0
    if OUT_MODE == 3 and MAKE_HD: _aH = float(sum(min(4096, nat.get(n_, 0)) ** 2 for n_ in nat) or _aS)
    _aS = _aS if MAKE_SD else 0.0; _tot = (_aS + _aH) or 1.0; _split = 0.12 + 0.86 * _aS / _tot
    def _build(factor, widths, skin, out, label):
        PROG["tag"] = label.split(",")[0]
        hdr2, b0h, b1h, phys_end, vend = to_hd(i20["hdr"], b0, b1, factor, widths)
        PHYS_END[0] = phys_end; globals()["FACE_SKIN_MODE"] = skin
        try: b1_x = bytes(write_textures_dd(b0h, b1h, imgs, hdr2))
        finally: PHYS_END[0] = None
        i20h = dict(i20); i20h["hdr"] = bytearray(hdr2)
        m0 = dict(i20["blocks"][0]); m1 = dict(i20["blocks"][1]); m1["un"] = len(b1_x); m0["un"] = len(b0h); i20h["blocks"] = [m0, m1] + list(i20["blocks"][2:])
        write_iff(i20h, [b0h, b1_x] + [b["raw"] for b in i20["blocks"][2:]], out); print("Port done (%s) -> %s" % (label, out)); return out
    # ---- SD: template slots, but the BODY map (tattoos) is never smaller than the 2K14 panel (capped by MAT_CAP)
    if MAKE_SD:
        PROG["lo"], PROG["hi"] = 0.12, _split
        out = os.path.join(outdir, base_name + "_2k20_SD.iff")
        sd_mat = min(MAT_CAP, max(tmw.get(mat_hx, 0), mat_nat)) if mat_hx else 0
        if imgs and mat_hx and sd_mat > tmw.get(mat_hx, 0):
            print("   ---- SD (body map / tattoos enlarged to %d) ----" % sd_mat)
            outs.append(_build(1, {mat_hx: sd_mat}, SKIN_SD, out, "SD, body map %d" % sd_mat))
        else:
            globals()["FACE_SKIN_MODE"] = SKIN_SD; PROG["tag"] = "SD"
            b1_sd = bytes(write_textures_dd(b0, b1, imgs, i20["hdr"])) if imgs else b1
            write_iff(i20, [b0, b1_sd] + [b["raw"] for b in i20["blocks"][2:]], out); outs.append(out); print("Port done (SD) -> %s" % out)
    if MAKE_HD and imgs:
        PROG["lo"], PROG["hi"] = (_split if MAKE_SD else 0.12), 0.98
        out = os.path.join(outdir, base_name + "_2k20_HD.iff")
        if HD_SIZE:                                                                # v94: HD file with big face / body slots
            _hs = HD_SIZE; wd = {}
            for n_, h_ in inv.items():
                wd[h_] = _hs if n_ in ("face_diffuse", "material_map") else min(_hs, 1024, nat.get(n_, 0))
            print("   ---- HD %d (face_diffuse + material_map = %d, other slots = 2K14 native, max 1024) ----" % (_hs, _hs))
            _old_mt = MAX_TEX; globals()["MAX_TEX"] = _hs
            try: outs.append(_build(1, wd, SKIN_HD, out, "HD %d" % _hs))
            finally: globals()["MAX_TEX"] = _old_mt
        elif OUT_MODE == 3:
            print("   ---- HD NATIVE (2K14 resolution per texture, min = template slot) ----")
            wd = {h: min(4096, nat[n]) for n, h in inv.items() if n in nat}
            outs.append(_build(1, wd, SKIN_HD, out, "HD native"))
        else:
            f = HD_FACTOR; wd = {mat_hx: min(MAT_CAP, mat_nat)} if mat_hx and mat_nat else {}
            print("   ---- HD x%d (enlarged from the SD template) ----" % f)
            outs.append(_build(f, wd, SKIN_HD, out, "HD x%d" % f))
    globals()["FACE_SKIN_MODE"] = "off"; _progress(1.0, "done")
    return outs

def _apply_replace(imgs, rep, tag=""):
    """v87: swap a decoded 2K14 texture for the user's PNG (before encoding / saving).  slot = face_diffuse | material_map"""
    for slot, path in rep.items():
        new = Image.open(path); old = imgs.get(slot)
        mode = old.mode if old is not None else ("RGBA" if slot == "face_diffuse" else "RGB")
        has_a = "A" in new.getbands() or "transparency" in new.info
        new = new.convert(mode)
        if mode == "RGBA" and not has_a and old is not None and old.mode == "RGBA": new.putalpha(old.getchannel("A").resize(new.size, Image.BILINEAR))
        if old is not None and abs(new.size[0] / new.size[1] - old.size[0] / old.size[1]) > 0.05:
            print("   WARNING: replaced %s is %dx%d but the 2K14 one was %dx%d (different panel layout) - check the result" % (slot, new.size[0], new.size[1], old.size[0], old.size[1]))
        imgs[slot] = new; print("   TEXTURE REPLACED: %s <- %s (%dx%d, %s)" % (slot, os.path.basename(path), new.size[0], new.size[1], mode))

def _ask_replace(folder, pick):
    """v87: interactive 'replace texture?' step, asked for every selected IFF before anything is saved"""
    pngs = sorted(f for f in os.listdir(folder) if f.lower().endswith(".png"))
    for f in pick:
        rep = {}; first = True
        while True:
            q = "\n  [%s]  Palitan ang texture bago i-save?  (y = oo / Enter = hindi, keep): " if first else "\n  [%s]  Palitan pa ang ibang texture?  (y = oo / Enter = hindi, tapos na): "
            if input(q % f).strip().lower() not in ("y", "yes", "oo", "o"): break
            first = False
            print("    1) face diffuse\n    2) material map")
            s_ = input("    Alin ang papalitan?  [1/2]: ").strip()
            if s_ not in ("1", "2"): print("    hindi valid - 1 o 2 lang"); first = True; continue
            slot = {"1": "face_diffuse", "2": "material_map"}[s_]
            if pngs:
                print("    PNG sa folder:")
                for i, n in enumerate(pngs, 1): print("     %d) %s" % (i, n))
            c = input("    Piliin ang PNG (numero o buong path): ").strip().strip("\"'")
            path = pngs[int(c) - 1] if c.isdigit() and 1 <= int(c) <= len(pngs) else c
            if not os.path.isabs(path): path = os.path.join(folder, path)
            try: Image.open(path).verify()
            except Exception as e: print("    hindi mabuksan ang PNG (%s) - ulitin" % e); first = True; continue
            rep[slot] = path; print("    OK: %s <- %s" % (slot, os.path.basename(path)))
        if rep: REPLACE[os.path.splitext(f)[0]] = rep
        else: print("    keep - walang papalitan")

def port_one(iff14, template, outdir):
    _progress(0.0, "reading textures")
    imgs = extract_textures(iff14, os.path.join(outdir, "textures"))
    _rp = dict(REPLACE_ALL); _rp.update(REPLACE.get(os.path.splitext(os.path.basename(iff14))[0], {}))
    if _rp: _apply_replace(imgs, _rp)
    _progress(0.04, "building mesh")
    return port_iff(iff14, template, outdir, imgs)

def batch(iffs, outdir, template=None):
    os.makedirs(outdir, exist_ok=True); _old = sys.stdout; ui = _Ui(_old); PROG["ui"] = ui
    verbose = os.environ.get("CF_VERBOSE", "0") == "1"; logp = os.path.join(outdir, "cf_port_log.txt")
    sys.stdout = _Tee(logp, _old, ui, verbose)
    try: res = _batch(iffs, outdir, template, ui)
    finally:
        sys.stdout.flush(); sys.stdout = _old
    ui.show(1.0 if res else 0.0, "done"); ui.say("")
    for n, ok, m in res:
        if ok: ui.say("  OK    %s  ->  %s" % (n, "  +  ".join(os.path.basename(x) for x in m)))
        else: ui.say("  FAIL  %s  :  %s" % (n, m))
    w = list(dict.fromkeys(ui.warn))
    if w: ui.say("  %d warning(s):" % len(w)); [ui.say("    - " + x) for x in w[:6]]
    ui.say("  output : %s\n  log    : %s" % (os.path.abspath(outdir), os.path.abspath(logp)))
    PROG["ui"] = None
    return res

def _batch(iffs, outdir, template=None, ui=None):
    files = [os.path.abspath(p) for p in iffs if os.path.isfile(p)]
    if not files: sys.exit("no IFF to port")
    tpl = find_template(os.path.dirname(files[0]), template, exclude=files); res = []
    if ui is not None: ui.n = len(files)
    for fi, f in enumerate(files):
        n = os.path.splitext(os.path.basename(f))[0]; print("\n=================== %s ===================" % n)
        if ui is not None: ui.fi = fi
        try: res.append((n, True, port_one(f, tpl, os.path.join(outdir, n))))
        except (Exception, SystemExit) as e: res.append((n, False, "%s: %s" % (type(e).__name__, e)))
    return res

def interactive():
    folder = _here(); os.chdir(folder)
    srcs = []
    for f in sorted(os.listdir(folder)):
        if not f.lower().endswith(".iff"): continue
        try: classify_template(os.path.join(folder, f)); continue            # a 2K20 base (container), not a 2K14 source
        except (SystemExit, Exception): srcs.append(f)
    print("\n  CF PORT  2K14 -> 2K20\n")
    if not srcs: sys.exit("  Walang 2K14 IFF sa folder:\n  %s" % folder)
    for i, f in enumerate(srcs, 1): print("  %d) %s" % (i, f))
    c = input("\n  Piliin (hal. 1 3)  [Enter = lahat]: ").replace(",", " ").split()
    pick = [srcs[int(x) - 1] for x in c if x.isdigit() and 1 <= int(x) <= len(srcs)] or srcs
    print("\n  Output:\n   1) SD + HD x2\n   2) SD + HD x4 (1024)\n   3) SD + HD native (resolution ng 2K14)\n   4) SD + HD 2048  (face + body map 2048)\n   5) SD + HD 4096  (face + body map 4096, mabigat / mabagal)")
    a = input("\n  Piliin  [Enter = 2]: ").strip()
    globals()["OUT_MODE"] = int(a) if a in ("1", "2", "3") else 2; globals()["HD_FACTOR"] = {1: 2, 2: 4, 3: 1}[globals()["OUT_MODE"]]
    globals()["HD_SIZE"] = {"4": 2048, "5": 4096}.get(a, 0)
    print("\n  Kulay ng balat:\n   1) NATIVE: eksaktong kulay ng 2K14, walang adjustment, patay ang tint ng game sa mukha\n   2) Tint match: mukha sumusunod sa body + green/brightness fix (v81+)\n   3) TONE MATCH (v94): material map = face diffuse, iisang skintone na hinila sa 2K20 base tones, HD tats hindi ginagalaw")
    a = input("\n  Piliin  [Enter = 3]: ").strip(); globals()["NATIVE"] = (a == "1"); globals()["TONE_ON"] = a not in ("1", "2")
    _ask_replace(folder, pick)
    print()
    batch([os.path.join(folder, f) for f in pick], os.path.join(folder, "out"), None)

def main():
    if len(sys.argv) == 1: return interactive()
    ap = argparse.ArgumentParser(description="2K14 -> 2K20 CF 1:1 port")
    ap.add_argument("iff14", nargs="+", help="2K14 CF IFF file(s)"); ap.add_argument("-t", "--template", help="any 2K20 SD CF IFF (container)"); ap.add_argument("-o", default="out")
    ap.add_argument("--textures-only", action="store_true", help="only export the textures as PNG")
    ap.add_argument("--allow-etc1", action="store_true", help="v79: also allow ETC1-style (individual/differential) blocks; default = ETC2 only (planar/T/H)"); ap.add_argument("--sd-only", action="store_true"); ap.add_argument("--hd-only", action="store_true")
    ap.add_argument("--skin-sd", default="off", choices=["off", "chroma", "match", "alpha0"]); ap.add_argument("--skin-hd", default="off", choices=["off", "chroma", "match", "alpha0"])
    ap.add_argument("--skin-k", type=float, default=None, help="skin fix strength 0..1 (default 1.0)"); ap.add_argument("--no-exact", action="store_true", help="old fit + neck blend instead of verbatim 2K14 vertices")
    ap.add_argument("--native", action="store_true", help="v78: face = EXACT 2K14 colours and the game skin tint switched off for it (face alpha = 0); body = exact 2K14 colours; no colour adjustment at all"); ap.add_argument("--tint-mode", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--no-tint", action="store_true", help="v75: switch the face/body tint match off"); ap.add_argument("--tint-k", type=float, default=None, help="0..1 how far the skin chroma moves to the 2K20 base (default 0.6)"); ap.add_argument("--tint-match", type=float, default=None, help="0..1 body chroma -> face chroma (default 0.85)"); ap.add_argument("--out-mode", type=int, default=None, choices=[1, 2, 3], help="1 = SD & HD x2 | 2 = SD & HD x4 (default) | 3 = SD & HD native 2K14 resolution"); ap.add_argument("--tint-l", type=float, default=None, help="0..1 body brightness -> face brightness (default 0.9)")
    ap.add_argument("--unify", default=None, choices=["relative", "face", "base", "off"], help="v72: body skin (material_map) follows the face skin (default) / the 2K20 base face / off")
    ap.add_argument("--unify-k", type=float, default=None, help="colour match strength 0..1 (default 1)"); ap.add_argument("--unify-l", type=float, default=None, help="brightness match strength 0..1 (default 1)")
    ap.add_argument("--max-tex", type=int, default=None, help="v80: largest texture slot (default 512; 0 = no limit)"); ap.add_argument("--no-face-body", action="store_true", help="v80: old tint logic instead of face -> body match")
    ap.add_argument("--face-k", type=float, default=None); ap.add_argument("--face-l", type=float, default=None); ap.add_argument("--tattoo-sharp", type=float, default=None); ap.add_argument("--no-lod1-hair", action="store_true"); ap.add_argument("--face-target", default=None, help="v86: face skin Lab target L,a,b e.g. 38,16,21 (tan)"); ap.add_argument("--face-green", type=float, default=None, help="v81: green strength (default 1, 0 = off)"); ap.add_argument("--face-bright", type=float, default=None, help="v81: brightness strength (default 1, 0 = off)")
    ap.add_argument("--replace-face", default=None, help="v87: PNG that replaces face_diffuse before saving"); ap.add_argument("--replace-material", default=None, help="v87: PNG that replaces material_map before saving")
    ap.add_argument("--no-tone", action="store_true", help="v94: off = old v93 skin logic"); ap.add_argument("--tone-k", type=float, default=None, help="v94: 0..1 colour pull of the skin to the 2K20 base tones (default 0.6)")
    ap.add_argument("--tone-l", type=float, default=None, help="v94: 0..1 brightness pull to the 2K20 base tones (default 0 = keep the player's lightness)"); ap.add_argument("--tone-ref", default=None, help="v94: folder with your own base material map PNGs (skin tone palette)")
    ap.add_argument("--hd-size", type=int, default=None, choices=[1024, 2048, 4096], help="v94: HD slot size of face_diffuse + material_map (others up to 1024 / native)")
    r = ap.parse_args()
    g_ = globals()
    if r.no_tone: g_["TONE_ON"] = False
    if r.tone_k is not None: g_["TONE_K"] = r.tone_k
    if r.tone_l is not None: g_["TONE_L"] = r.tone_l
    if r.tone_ref: g_["TONE_REF_DIR"] = r.tone_ref
    if r.hd_size: g_["HD_SIZE"] = r.hd_size
    if r.replace_face: REPLACE_ALL["face_diffuse"] = r.replace_face
    if r.replace_material: REPLACE_ALL["material_map"] = r.replace_material
    if r.max_tex is not None: g_["MAX_TEX"] = r.max_tex; g_["MAT_CAP"] = r.max_tex or 4096
    if r.no_face_body: g_["FACE_TO_BODY"] = False
    if r.face_k is not None: g_["FACE_K"] = r.face_k
    if r.face_l is not None: g_["FACE_L"] = r.face_l
    if r.tattoo_sharp is not None: g_["TATTOO_SHARP"] = r.tattoo_sharp
    if r.face_green is not None: g_["FACE_GREEN"] = r.face_green; g_["TONE_FACE_GREEN"] = r.face_green
    if r.face_bright is not None: g_["FACE_BRIGHT"] = r.face_bright
    if r.face_target: g_["FACE_TARGET"] = r.face_target
    if r.no_lod1_hair: g_["LOD1_HAIR"] = False
    if r.allow_etc1: globals()["ETC2_ONLY"] = False; globals()["ENC_MODES"] = ("etc1", "planar", "T", "H")
    if r.no_tint: globals()["TINT_ON"] = False
    if r.native: globals()["TINT_ON"] = False; globals()["NATIVE"] = True
    if r.tint_k is not None: globals()["TINT_K"] = r.tint_k
    if r.tint_match is not None: globals()["TINT_MATCH"] = r.tint_match
    if r.out_mode: globals()["OUT_MODE"] = r.out_mode
    if r.tint_l is not None: globals()["TINT_L"] = r.tint_l
    globals()["HD_FACTOR"] = {1: 2, 2: 4, 3: 1}.get(globals()["OUT_MODE"], 4)
    if r.unify: globals()["SKIN_UNIFY"] = r.unify
    if r.unify_k is not None: globals()["UNIFY_K"] = r.unify_k
    if r.unify_l is not None: globals()["UNIFY_L"] = r.unify_l
    g = globals(); g["SKIN_SD"] = r.skin_sd; g["SKIN_HD"] = r.skin_hd; g["MAKE_SD"] = not r.hd_only; g["MAKE_HD"] = not r.sd_only
    if r.skin_k is not None: g["SKIN_K"] = r.skin_k
    if r.no_exact: g["EXACT"] = False
    if r.textures_only:
        for f in r.iff14: extract_textures(f, os.path.join(r.o, os.path.splitext(os.path.basename(f))[0]))
    else: batch(r.iff14, r.o, r.template)

if __name__ == "__main__":
    main()
